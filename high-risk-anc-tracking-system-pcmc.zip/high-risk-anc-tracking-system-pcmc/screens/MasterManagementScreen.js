// screens/MasterManagementScreen.js

import React, {
  useEffect,
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { Picker } from "@react-native-picker/picker";
import * as Location from "expo-location";

import {
  getAllZones,
  registerZoneMaster,
  registerHospitalMaster,
  registerStaffMaster,
  registerAshaMaster,
} from "../api/api";

import { useAuth } from "../App";

function SectionCard({
  title,
  subtitle,
  children,
}) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>
        {title}
      </Text>

      {subtitle ? (
        <Text style={styles.sectionSubtitle}>
          {subtitle}
        </Text>
      ) : null}

      <View style={styles.sectionBody}>
        {children}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = "default",
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>
        {label}
      </Text>

      <TextInput
        value={
          value === null ||
          value === undefined
            ? ""
            : String(value)
        }
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#94a3b8"
        keyboardType={keyboardType}
        style={styles.input}
      />
    </View>
  );
}

function PickerField({
  label,
  value,
  onChange,
  items,
  placeholder = "Select",
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>
        {label}
      </Text>

      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={value}
          onValueChange={onChange}
          style={styles.picker}
        >
          <Picker.Item
            label={placeholder}
            value=""
          />

          {items.map((item) => (
            <Picker.Item
              key={String(item)}
              label={String(item)}
              value={item}
            />
          ))}
        </Picker>
      </View>
    </View>
  );
}

function normalizeText(value) {
  return String(value || "")
    .trim()
    .toLowerCase();
}

function extractZoneArray(response) {
  let result =
    response?.data ??
    response;

  if (
    result &&
    typeof result === "object" &&
    result.data !== undefined
  ) {
    result = result.data;
  }

  if (
    result &&
    typeof result === "object" &&
    result.zones !== undefined
  ) {
    result = result.zones;
  }

  if (typeof result === "string") {
    try {
      result = JSON.parse(result);
    } catch (error) {
      result = [];
    }
  }

  if (!Array.isArray(result)) {
    return [];
  }

  return result;
}

function getZoneName(item) {
  if (typeof item === "string") {
    return item.trim();
  }

  return String(
    item?.zoneName ||
      item?.Zone ||
      item?.zone ||
      item?.Name ||
      item?.name ||
      item?.["Zone Name"] ||
      ""
  ).trim();
}

function getZoneStatus(item) {
  if (typeof item === "string") {
    return "active";
  }

  return normalizeText(
    item?.status ||
      item?.Status ||
      item?.["Zone Status"] ||
      "Active"
  );
}

export default function MasterManagementScreen({
  navigation,
}) {
  const { user } = useAuth();

  const [activeTab, setActiveTab] =
    useState("Zone");

  const [zones, setZones] =
    useState([]);

  const [loadingZones, setLoadingZones] =
    useState(false);

  const [saving, setSaving] =
    useState(false);

  const [gettingLocation, setGettingLocation] =
    useState(false);

  const [error, setError] =
    useState("");

  // =========================
  // ZONE
  // =========================

  const [zoneName, setZoneName] =
    useState("");

  const [zoneDescription, setZoneDescription] =
    useState("");

  // =========================
  // HOSPITAL
  // =========================

  const [hospitalName, setHospitalName] =
    useState("");

  const [hospitalAddress, setHospitalAddress] =
    useState("");

  const [hospitalZone, setHospitalZone] =
    useState("");

  const [hospitalCode, setHospitalCode] =
    useState("");

  const [hospitalLocation, setHospitalLocation] =
    useState("");

  // =========================
  // STAFF
  // =========================

  const [staffName, setStaffName] =
    useState("");

  const [staffMobile, setStaffMobile] =
    useState("");

  const [staffEmail, setStaffEmail] =
    useState("");

  const [staffZone, setStaffZone] =
    useState("");

  const [staffHospital, setStaffHospital] =
    useState("");

  // =========================
  // ASHA
  // =========================

  const [ashaName, setAshaName] =
    useState("");

  const [ashaMobile, setAshaMobile] =
    useState("");

  const [ashaArea, setAshaArea] =
    useState("");

  const [ashaZone, setAshaZone] =
    useState("");

  const [ashaHospital, setAshaHospital] =
    useState("");

  // =====================================================
  // LOAD ZONES
  // =====================================================

  const loadZones = async () => {
    setLoadingZones(true);
    setError("");

    try {
      console.log(
        "MASTER MANAGEMENT: Loading zones..."
      );

      const response =
        await getAllZones();

      console.log(
        "MASTER MANAGEMENT getAllZones RESPONSE:",
        response
      );

      const data =
        extractZoneArray(response);

      console.log(
        "MASTER MANAGEMENT parsed zones:",
        data
      );

      const activeZoneNames = data
        .filter((item) => {
          const status =
            getZoneStatus(item);

          return (
            status === "active" ||
            status === ""
          );
        })
        .map(getZoneName)
        .filter(Boolean);

      const uniqueZones = [
        ...new Set(
          activeZoneNames
        ),
      ];

      console.log(
        "MASTER MANAGEMENT active zones:",
        uniqueZones
      );

      setZones(uniqueZones);

      if (uniqueZones.length === 0) {
        setError(
          "No Active Zones found. Please check Zone Master data and Status."
        );
      }
    } catch (apiError) {
      console.log(
        "MASTER MANAGEMENT loadZones ERROR:",
        apiError
      );

      setError(
        apiError?.message ||
          "Unable to load active zones."
      );
    } finally {
      setLoadingZones(false);
    }
  };

  useEffect(() => {
    loadZones();
  }, []);

  // =====================================================
  // RESET FORMS
  // =====================================================

  function resetZoneForm() {
    setZoneName("");
    setZoneDescription("");
  }

  function resetHospitalForm() {
    setHospitalName("");
    setHospitalAddress("");
    setHospitalZone("");
    setHospitalCode("");
    setHospitalLocation("");
  }

  function resetStaffForm() {
    setStaffName("");
    setStaffMobile("");
    setStaffEmail("");
    setStaffZone("");
    setStaffHospital("");
  }

  function resetAshaForm() {
    setAshaName("");
    setAshaMobile("");
    setAshaArea("");
    setAshaZone("");
    setAshaHospital("");
  }

  // =====================================================
  // GET CURRENT LOCATION
  // =====================================================

  async function getHospitalLocation() {
    if (gettingLocation) {
      return;
    }

    setGettingLocation(true);

    try {
      const permissionResponse =
        await Location.requestForegroundPermissionsAsync();

      if (
        permissionResponse.status !==
        "granted"
      ) {
        Alert.alert(
          "Location Permission",
          "Please allow location permission to capture the hospital GPS location."
        );

        return;
      }

      const location =
        await Location.getCurrentPositionAsync(
          {
            accuracy:
              Location.Accuracy.High,
          }
        );

      const latitude =
        location?.coords?.latitude;

      const longitude =
        location?.coords?.longitude;

      if (
        latitude === undefined ||
        longitude === undefined
      ) {
        throw new Error(
          "Unable to read current GPS coordinates."
        );
      }

      const mapsUrl =
        "https://www.google.com/maps?q=" +
        latitude +
        "," +
        longitude;

      setHospitalLocation(
        mapsUrl
      );

      Alert.alert(
        "Location Captured",
        "Hospital current location has been captured successfully."
      );
    } catch (apiError) {
      Alert.alert(
        "Location Error",
        apiError?.message ||
          "Unable to get current location."
      );
    } finally {
      setGettingLocation(false);
    }
  }

  // =====================================================
  // SAVE ZONE
  // =====================================================

  async function saveZone() {
    if (!zoneName.trim()) {
      Alert.alert(
        "Zone Required",
        "Please enter the zone name."
      );
      return;
    }

    setSaving(true);

    try {
      const response =
        await registerZoneMaster({
          zone:
            zoneName.trim(),

          Zone:
            zoneName.trim(),

          zoneName:
            zoneName.trim(),

          description:
            zoneDescription.trim(),

          Description:
            zoneDescription.trim(),

          status: "Active",

          Status: "Active",

          createdBy:
            user?.username ||
            "System",
        });

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to register zone."
        );
      }

      Alert.alert(
        "Saved",
        "Zone has been registered successfully."
      );

      resetZoneForm();

      await loadZones();
    } catch (apiError) {
      Alert.alert(
        "Save Failed",
        apiError?.message ||
          "Unable to register zone."
      );
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // SAVE HOSPITAL
  // =====================================================

  async function saveHospital() {
    if (!hospitalName.trim()) {
      Alert.alert(
        "Hospital Required",
        "Please enter the hospital name."
      );
      return;
    }

    if (!hospitalZone) {
      Alert.alert(
        "Zone Required",
        "Please select the hospital zone."
      );
      return;
    }

    if (!hospitalAddress.trim()) {
      Alert.alert(
        "Address Required",
        "Please enter the hospital address."
      );
      return;
    }

    setSaving(true);

    try {
      const response =
        await registerHospitalMaster({
          hospitalName:
            hospitalName.trim(),

          "Hospital Name":
            hospitalName.trim(),

          hospitalAddress:
            hospitalAddress.trim(),

          "Hospital Address":
            hospitalAddress.trim(),

          address:
            hospitalAddress.trim(),

          zone:
            hospitalZone,

          Zone:
            hospitalZone,

          hospitalCode:
            hospitalCode.trim(),

          "Hospital Code":
            hospitalCode.trim(),

          googleLocation:
            hospitalLocation.trim(),

          "Google Location":
            hospitalLocation.trim(),

          status: "Active",

          Status: "Active",

          createdBy:
            user?.username ||
            "System",
        });

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to register hospital."
        );
      }

      Alert.alert(
        "Saved",
        "Hospital has been registered successfully."
      );

      resetHospitalForm();
    } catch (apiError) {
      Alert.alert(
        "Save Failed",
        apiError?.message ||
          "Unable to register hospital."
      );
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // SAVE STAFF
  // =====================================================

  async function saveStaff() {
    const cleanMobile =
      staffMobile.replace(
        /\D/g,
        ""
      );

    if (!staffName.trim()) {
      Alert.alert(
        "Staff Name Required",
        "Please enter the staff nurse name."
      );
      return;
    }

    if (!staffZone) {
      Alert.alert(
        "Zone Required",
        "Please select the staff zone."
      );
      return;
    }

    if (!staffHospital.trim()) {
      Alert.alert(
        "Hospital Required",
        "Please enter the assigned hospital."
      );
      return;
    }

    if (
      cleanMobile &&
      cleanMobile.length !== 10
    ) {
      Alert.alert(
        "Invalid Mobile",
        "Staff mobile must contain 10 digits."
      );
      return;
    }

    setSaving(true);

    try {
      const response =
        await registerStaffMaster({
          staffName:
            staffName.trim(),

          "Staff Name":
            staffName.trim(),

          staffMobile:
            cleanMobile,

          "Staff Mobile":
            cleanMobile,

          staffEmail:
            staffEmail.trim(),

          "Staff Email":
            staffEmail.trim(),

          zone:
            staffZone,

          Zone:
            staffZone,

          hospitalName:
            staffHospital.trim(),

          "Hospital Name":
            staffHospital.trim(),

          status: "Active",

          Status: "Active",

          createdBy:
            user?.username ||
            "System",
        });

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to register staff nurse."
        );
      }

      Alert.alert(
        "Saved",
        "Staff nurse has been registered successfully."
      );

      resetStaffForm();
    } catch (apiError) {
      Alert.alert(
        "Save Failed",
        apiError?.message ||
          "Unable to register staff nurse."
      );
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // SAVE ASHA
  // =====================================================

  async function saveAsha() {
    const cleanMobile =
      ashaMobile.replace(
        /\D/g,
        ""
      );

    if (!ashaName.trim()) {
      Alert.alert(
        "ASHA Name Required",
        "Please enter the ASHA name."
      );
      return;
    }

    if (!ashaZone) {
      Alert.alert(
        "Zone Required",
        "Please select the ASHA zone."
      );
      return;
    }

    if (
      cleanMobile &&
      cleanMobile.length !== 10
    ) {
      Alert.alert(
        "Invalid Mobile",
        "ASHA mobile must contain 10 digits."
      );
      return;
    }

    setSaving(true);

    try {
      const response =
        await registerAshaMaster({
          ashaName:
            ashaName.trim(),

          "ASHA Name":
            ashaName.trim(),

          ashaMobile:
            cleanMobile,

          "ASHA Mobile":
            cleanMobile,

          ashaArea:
            ashaArea.trim(),

          "ASHA Area":
            ashaArea.trim(),

          zone:
            ashaZone,

          Zone:
            ashaZone,

          hospitalName:
            ashaHospital.trim(),

          "Hospital Name":
            ashaHospital.trim(),

          status: "Active",

          Status: "Active",

          createdBy:
            user?.username ||
            "System",
        });

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to register ASHA."
        );
      }

      Alert.alert(
        "Saved",
        "ASHA has been registered successfully."
      );

      resetAshaForm();
    } catch (apiError) {
      Alert.alert(
        "Save Failed",
        apiError?.message ||
          "Unable to register ASHA."
      );
    } finally {
      setSaving(false);
    }
  }

  const tabs = [
    "Zone",
    "Hospital",
    "Staff Nurse",
    "ASHA",
  ];

  // =====================================================
  // ACCESS CONTROL
  // =====================================================

  if (
    user?.role !== "Admin" &&
    user?.role !== "Super Admin"
  ) {
    return (
      <View
        style={
          styles.accessContainer
        }
      >
        <Text
          style={
            styles.accessIcon
          }
        >
          🔒
        </Text>

        <Text
          style={
            styles.accessTitle
          }
        >
          Admin Access Required
        </Text>

        <Text
          style={
            styles.accessText
          }
        >
          Master Management is available
          only to Admin and Super Admin
          users.
        </Text>

        <Pressable
          style={
            styles.backToDashboard
          }
          onPress={() =>
            navigation.goBack()
          }
        >
          <Text
            style={
              styles.backToDashboardText
            }
          >
            Back
          </Text>
        </Pressable>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={
        Platform.OS === "ios"
          ? "padding"
          : undefined
      }
    >
      {/* =====================================================
          HEADER
      ===================================================== */}

      <View style={styles.header}>
        <Pressable
          style={styles.backButton}
          onPress={() =>
            navigation.goBack()
          }
        >
          <Text style={styles.backText}>
            ‹
          </Text>
        </Pressable>

        <View
          style={styles.headerText}
        >
          <Text
            style={styles.headerTitle}
          >
            Master Management
          </Text>

          <Text
            style={
              styles.headerSubtitle
            }
          >
            Zones, hospitals, staff and ASHA masters
          </Text>
        </View>
      </View>

      {/* =====================================================
          TABS
      ===================================================== */}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={
          false
        }
        style={styles.tabScroll}
        contentContainerStyle={
          styles.tabContent
        }
      >
        {tabs.map((tab) => (
          <Pressable
            key={tab}
            onPress={() =>
              setActiveTab(tab)
            }
            style={[
              styles.tab,
              activeTab === tab &&
                styles.activeTab,
            ]}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === tab &&
                  styles.activeTabText,
              ]}
            >
              {tab}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* =====================================================
          ERROR
      ===================================================== */}

      {error ? (
        <View
          style={
            styles.errorBanner
          }
        >
          <Text
            style={
              styles.errorText
            }
          >
            {error}
          </Text>

          <Pressable
            style={
              styles.retryButton
            }
            onPress={loadZones}
          >
            <Text
              style={
                styles.retryButtonText
              }
            >
              Retry
            </Text>
          </Pressable>
        </View>
      ) : null}

      {/* =====================================================
          ZONE LOADING
      ===================================================== */}

      {loadingZones ? (
        <View
          style={
            styles.zoneLoading
          }
        >
          <ActivityIndicator
            size="small"
            color="#2563eb"
          />

          <Text
            style={
              styles.zoneLoadingText
            }
          >
            Loading active zones...
          </Text>
        </View>
      ) : null}

      {/* =====================================================
          MAIN CONTENT
      ===================================================== */}

      <ScrollView
        contentContainerStyle={
          styles.content
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={
          false
        }
      >
        {/* =====================================================
            ZONE TAB
        ===================================================== */}

        {activeTab === "Zone" ? (
          <SectionCard
            title="Register Zone"
            subtitle="Create a new active PCMC ANC tracking zone"
          >
            <Field
              label="Zone Name *"
              value={zoneName}
              onChangeText={
                setZoneName
              }
              placeholder="Example: Jijamata"
            />

            <Field
              label="Description"
              value={
                zoneDescription
              }
              onChangeText={
                setZoneDescription
              }
              placeholder="Enter zone description"
            />

            <Pressable
              onPress={saveZone}
              disabled={saving}
              style={[
                styles.saveButton,
                saving &&
                  styles.disabledButton,
              ]}
            >
              {saving ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.saveText
                  }
                >
                  Register Zone
                </Text>
              )}
            </Pressable>

            <View
              style={
                styles.listCard
              }
            >
              <View
                style={
                  styles.listHeaderRow
                }
              >
                <Text
                  style={
                    styles.listTitle
                  }
                >
                  Active Zones
                </Text>

                <Pressable
                  onPress={loadZones}
                  disabled={
                    loadingZones
                  }
                  style={
                    styles.refreshButton
                  }
                >
                  <Text
                    style={
                      styles.refreshButtonText
                    }
                  >
                    ↻ Refresh
                  </Text>
                </Pressable>
              </View>

              {zones.length === 0 ? (
                <Text
                  style={
                    styles.noData
                  }
                >
                  No active zones found.
                </Text>
              ) : (
                zones.map((zone) => (
                  <View
                    key={zone}
                    style={
                      styles.listRow
                    }
                  >
                    <View
                      style={
                        styles.dot
                      }
                    />

                    <Text
                      style={
                        styles.listRowText
                      }
                    >
                      {zone}
                    </Text>
                  </View>
                ))
              )}
            </View>
          </SectionCard>
        ) : null}

        {/* =====================================================
            HOSPITAL TAB
        ===================================================== */}

        {activeTab ===
        "Hospital" ? (
          <SectionCard
            title="Register Hospital"
            subtitle="Add a hospital or UPHC to the master"
          >
            <Field
              label="Hospital Name *"
              value={
                hospitalName
              }
              onChangeText={
                setHospitalName
              }
              placeholder="Hospital / UPHC name"
            />

            <PickerField
              label="Zone *"
              value={
                hospitalZone
              }
              onChange={
                setHospitalZone
              }
              items={zones}
              placeholder="Select zone"
            />

            <Field
              label="Hospital Address *"
              value={
                hospitalAddress
              }
              onChangeText={
                setHospitalAddress
              }
              placeholder="Complete hospital address"
            />

            {/* =================================================
                GET LOCATION
            ================================================= */}

            <View
              style={
                styles.locationSection
              }
            >
              <Text
                style={
                  styles.label
                }
              >
                Hospital Google Location
              </Text>

              <Pressable
                onPress={
                  getHospitalLocation
                }
                disabled={
                  gettingLocation
                }
                style={[
                  styles.locationButton,
                  gettingLocation &&
                    styles.disabledButton,
                ]}
              >
                {gettingLocation ? (
                  <View
                    style={
                      styles.locationButtonInner
                    }
                  >
                    <ActivityIndicator
                      color="#ffffff"
                      size="small"
                    />

                    <Text
                      style={
                        styles.locationButtonText
                      }
                    >
                      Getting Location...
                    </Text>
                  </View>
                ) : (
                  <View
                    style={
                      styles.locationButtonInner
                    }
                  >
                    <Text
                      style={
                        styles.locationIcon
                      }
                    >
                      📍
                    </Text>

                    <Text
                      style={
                        styles.locationButtonText
                      }
                    >
                      Get Current Location
                    </Text>
                  </View>
                )}
              </Pressable>

              {hospitalLocation ? (
                <View
                  style={
                    styles.locationSuccessBox
                  }
                >
                  <Text
                    style={
                      styles.locationSuccessTitle
                    }
                  >
                    ✓ Location Captured
                  </Text>

                  <Text
                    style={
                      styles.locationSuccessText
                    }
                    numberOfLines={2}
                  >
                    {hospitalLocation}
                  </Text>
                </View>
              ) : (
                <Text
                  style={
                    styles.locationHint
                  }
                >
                  Press the button to capture
                  the current GPS location.
                </Text>
              )}
            </View>

            <Field
              label="Hospital Code"
              value={
                hospitalCode
              }
              onChangeText={
                setHospitalCode
              }
              placeholder="Optional code"
            />

            <Pressable
              onPress={
                saveHospital
              }
              disabled={saving}
              style={[
                styles.saveButton,
                saving &&
                  styles.disabledButton,
              ]}
            >
              {saving ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.saveText
                  }
                >
                  Register Hospital
                </Text>
              )}
            </Pressable>
          </SectionCard>
        ) : null}

        {/* =====================================================
            STAFF TAB
        ===================================================== */}

        {activeTab ===
        "Staff Nurse" ? (
          <SectionCard
            title="Register Staff Nurse"
            subtitle="Add staff linked to a zone and hospital"
          >
            <Field
              label="Staff Nurse Name *"
              value={
                staffName
              }
              onChangeText={
                setStaffName
              }
              placeholder="Enter staff nurse name"
            />

            <PickerField
              label="Zone *"
              value={
                staffZone
              }
              onChange={(value) => {
                setStaffZone(
                  value
                );

                setStaffHospital(
                  ""
                );
              }}
              items={zones}
              placeholder="Select zone"
            />

            <Field
              label="Hospital / UPHC *"
              value={
                staffHospital
              }
              onChangeText={
                setStaffHospital
              }
              placeholder="Enter assigned hospital"
            />

            <Field
              label="Mobile"
              value={
                staffMobile
              }
              onChangeText={(
                value
              ) =>
                setStaffMobile(
                  value
                    .replace(
                      /\D/g,
                      ""
                    )
                    .slice(
                      0,
                      10
                    )
                )
              }
              placeholder="10-digit mobile"
              keyboardType="phone-pad"
            />

            <Field
              label="Email"
              value={
                staffEmail
              }
              onChangeText={
                setStaffEmail
              }
              placeholder="Email address"
              keyboardType="email-address"
            />

            <Pressable
              onPress={saveStaff}
              disabled={saving}
              style={[
                styles.saveButton,
                saving &&
                  styles.disabledButton,
              ]}
            >
              {saving ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.saveText
                  }
                >
                  Register Staff Nurse
                </Text>
              )}
            </Pressable>
          </SectionCard>
        ) : null}

        {/* =====================================================
            ASHA TAB
        ===================================================== */}

        {activeTab === "ASHA" ? (
          <SectionCard
            title="Register ASHA"
            subtitle="Add community health worker information"
          >
            <Field
              label="ASHA Name *"
              value={
                ashaName
              }
              onChangeText={
                setAshaName
              }
              placeholder="Enter ASHA name"
            />

            <PickerField
              label="Zone *"
              value={
                ashaZone
              }
              onChange={
                setAshaZone
              }
              items={zones}
              placeholder="Select zone"
            />

            <Field
              label="Assigned Hospital"
              value={
                ashaHospital
              }
              onChangeText={
                setAshaHospital
              }
              placeholder="Hospital / UPHC"
            />

            <Field
              label="Mobile"
              value={
                ashaMobile
              }
              onChangeText={(
                value
              ) =>
                setAshaMobile(
                  value
                    .replace(
                      /\D/g,
                      ""
                    )
                    .slice(
                      0,
                      10
                    )
                )
              }
              placeholder="10-digit mobile"
              keyboardType="phone-pad"
            />

            <Field
              label="Area / Village"
              value={
                ashaArea
              }
              onChangeText={
                setAshaArea
              }
              placeholder="Assigned area or village"
            />

            <Pressable
              onPress={saveAsha}
              disabled={saving}
              style={[
                styles.saveButton,
                saving &&
                  styles.disabledButton,
              ]}
            >
              {saving ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.saveText
                  }
                >
                  Register ASHA
                </Text>
              )}
            </Pressable>
          </SectionCard>
        ) : null}

        <View
          style={
            styles.bottomSpace
          }
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f4f8",
  },

  accessContainer: {
    flex: 1,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },

  accessIcon: {
    fontSize: 46,
  },

  accessTitle: {
    marginTop: 14,
    color: "#1e293b",
    fontSize: 20,
    fontWeight: "800",
  },

  accessText: {
    marginTop: 8,
    color: "#64748b",
    fontSize: 13,
    lineHeight: 19,
    textAlign: "center",
  },

  backToDashboard: {
    marginTop: 20,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    backgroundColor: "#2563eb",
  },

  backToDashboardText: {
    color: "#ffffff",
    fontWeight: "800",
  },

  header: {
    backgroundColor: "#1a365d",
    paddingTop:
      Platform.OS === "android"
        ? 36
        : 54,
    paddingHorizontal: 18,
    paddingBottom: 18,
    flexDirection: "row",
    alignItems: "center",
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor:
      "rgba(255,255,255,0.14)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },

  backText: {
    color: "#ffffff",
    fontSize: 32,
    lineHeight: 34,
  },

  headerText: {
    flex: 1,
  },

  headerTitle: {
    color: "#ffffff",
    fontSize: 21,
    fontWeight: "800",
  },

  headerSubtitle: {
    color: "#dbeafe",
    fontSize: 12,
    marginTop: 3,
  },

  tabScroll: {
    maxHeight: 60,
    backgroundColor: "#ffffff",
  },

  tabContent: {
    paddingHorizontal: 12,
    alignItems: "center",
  },

  tab: {
    paddingHorizontal: 15,
    paddingVertical: 11,
    marginRight: 7,
    borderRadius: 12,
  },

  activeTab: {
    backgroundColor: "#eff6ff",
  },

  tabText: {
    color: "#64748b",
    fontSize: 12,
    fontWeight: "700",
  },

  activeTabText: {
    color: "#1d4ed8",
  },

  errorBanner: {
    margin: 14,
    marginBottom: 0,
    backgroundColor: "#fee2e2",
    borderWidth: 1,
    borderColor: "#fecaca",
    borderRadius: 12,
    padding: 11,
  },

  errorText: {
    color: "#991b1b",
    fontSize: 12,
    lineHeight: 18,
  },

  retryButton: {
    alignSelf: "flex-start",
    marginTop: 9,
    paddingHorizontal: 13,
    paddingVertical: 7,
    backgroundColor: "#ffffff",
    borderRadius: 9,
    borderWidth: 1,
    borderColor: "#fecaca",
  },

  retryButtonText: {
    color: "#991b1b",
    fontSize: 12,
    fontWeight: "800",
  },

  zoneLoading: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
  },

  zoneLoadingText: {
    marginLeft: 8,
    color: "#64748b",
    fontSize: 12,
  },

  content: {
    padding: 16,
    paddingBottom: 40,
  },

  card: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 17,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    elevation: 2,
  },

  sectionTitle: {
    color: "#1e293b",
    fontSize: 18,
    fontWeight: "800",
  },

  sectionSubtitle: {
    color: "#64748b",
    fontSize: 12,
    marginTop: 4,
    lineHeight: 18,
  },

  sectionBody: {
    marginTop: 16,
  },

  field: {
    marginBottom: 14,
  },

  label: {
    color: "#334155",
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 7,
  },

  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 12,
    paddingHorizontal: 13,
    backgroundColor: "#ffffff",
    color: "#1e293b",
    fontSize: 14,
  },

  pickerContainer: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 12,
    backgroundColor: "#ffffff",
    overflow: "hidden",
  },

  picker: {
    height: 50,
    color: "#1e293b",
  },

  // =====================================================
  // LOCATION STYLES
  // =====================================================

  locationSection: {
    marginBottom: 14,
  },

  locationButton: {
    minHeight: 50,
    borderRadius: 13,
    backgroundColor: "#0f766e",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 14,
  },

  locationButtonInner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },

  locationIcon: {
    fontSize: 18,
    marginRight: 8,
  },

  locationButtonText: {
    color: "#ffffff",
    fontSize: 13,
    fontWeight: "800",
  },

  locationSuccessBox: {
    marginTop: 9,
    padding: 11,
    borderRadius: 12,
    backgroundColor: "#ecfdf5",
    borderWidth: 1,
    borderColor: "#a7f3d0",
  },

  locationSuccessTitle: {
    color: "#047857",
    fontSize: 12,
    fontWeight: "800",
  },

  locationSuccessText: {
    color: "#065f46",
    fontSize: 11,
    lineHeight: 16,
    marginTop: 4,
  },

  locationHint: {
    color: "#94a3b8",
    fontSize: 11,
    marginTop: 7,
    lineHeight: 16,
  },

  saveButton: {
    minHeight: 52,
    borderRadius: 14,
    backgroundColor: "#2563eb",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 3,
  },

  saveText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "800",
  },

  disabledButton: {
    opacity: 0.65,
  },

  listCard: {
    marginTop: 18,
    backgroundColor: "#f8fafc",
    borderRadius: 15,
    padding: 13,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },

  listHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },

  listTitle: {
    color: "#1e293b",
    fontSize: 13,
    fontWeight: "800",
  },

  refreshButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 9,
    backgroundColor: "#eff6ff",
    borderWidth: 1,
    borderColor: "#bfdbfe",
  },

  refreshButtonText: {
    color: "#2563eb",
    fontSize: 11,
    fontWeight: "800",
  },

  listRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },

  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#16a34a",
    marginRight: 9,
  },

  listRowText: {
    color: "#475569",
    fontSize: 13,
  },

  noData: {
    color: "#94a3b8",
    fontSize: 12,
    paddingVertical: 8,
  },

  bottomSpace: {
    height: 40,
  },
});