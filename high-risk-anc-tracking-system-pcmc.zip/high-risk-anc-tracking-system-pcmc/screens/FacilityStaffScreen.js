// screens/FacilityStaffScreen.js

import React, {
  useCallback,
  useEffect,
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import * as Location from "expo-location";

import {
  getMyFacilityStaffData,
  updateMyFacilityStaffData,
} from "../api/api";

import { useAuth } from "../App";

function SectionCard({
  title,
  subtitle,
  children,
}) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>
        {title}
      </Text>

      {subtitle ? (
        <Text style={styles.sectionSubtitle}>
          {subtitle}
        </Text>
      ) : null}

      <View style={styles.sectionBody}>
        {children}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = "default",
  multiline = false,
  editable = true,
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>
        {label}
      </Text>

      <TextInput
        value={
          value === undefined ||
          value === null
            ? ""
            : String(value)
        }
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#94a3b8"
        keyboardType={keyboardType}
        multiline={multiline}
        editable={editable}
        textAlignVertical={
          multiline
            ? "top"
            : "center"
        }
        style={[
          styles.input,
          multiline &&
            styles.textArea,
          !editable &&
            styles.disabledInput,
        ]}
      />
    </View>
  );
}

function getValue(data, keys) {
  for (const key of keys) {
    if (
      data &&
      data[key] !== undefined &&
      data[key] !== null
    ) {
      return data[key];
    }
  }

  return "";
}

export default function FacilityStaffScreen({
  navigation,
}) {
  const { user } = useAuth();

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [gettingLocation, setGettingLocation] =
    useState(false);

  const [error, setError] =
    useState("");

  const [facilityName, setFacilityName] =
    useState("");

  const [facilityAddress, setFacilityAddress] =
    useState("");

  const [zone, setZone] =
    useState("");

  const [googleLocation, setGoogleLocation] =
    useState("");

  const [staffNurse, setStaffNurse] =
    useState("");

  const [staffMobile, setStaffMobile] =
    useState("");

  const [staffEmail, setStaffEmail] =
    useState("");

  const [ashaName, setAshaName] =
    useState("");

  const [ashaMobile, setAshaMobile] =
    useState("");

  const [ashaArea, setAshaArea] =
    useState("");

  const [originalData, setOriginalData] =
    useState(null);

  const username =
    user?.username || "";

  // =====================================================
  // LOAD FACILITY DATA
  // =====================================================

  const loadFacilityData =
    useCallback(async () => {
      setLoading(true);
      setError("");

      try {
        console.log(
          "FACILITY STAFF: Loading facility data for:",
          username
        );

        const response =
          await getMyFacilityStaffData(
            username
          );

        console.log(
          "FACILITY STAFF RESPONSE:",
          response
        );

        const result =
          response?.data ?? response;

        let data =
          result?.data ||
          result?.record ||
          result;

        if (
          Array.isArray(data)
        ) {
          data =
            data[0] || {};
        }

        if (
          result &&
          result.success === false
        ) {
          throw new Error(
            result.message ||
              "Unable to load facility details."
          );
        }

        if (
          !data ||
          typeof data !== "object"
        ) {
          data = {};
        }

        console.log(
          "FACILITY STAFF RECORD:",
          data
        );

        setOriginalData(data);

        setFacilityName(
          getValue(data, [
            "Facility Name",
            "facilityName",
            "Hospital Name",
            "hospitalName",
          ])
        );

        setFacilityAddress(
          getValue(data, [
            "Facility Address",
            "facilityAddress",
            "Address",
            "address",
          ])
        );

        setZone(
          getValue(data, [
            "Zone",
            "zone",
          ]) ||
            user?.zone ||
            ""
        );

        // Existing Google Location
        setGoogleLocation(
          String(
            getValue(data, [
              "Google Location",
              "googleLocation",
              "GoogleLocation",
              "Location",
              "location",
            ]) || ""
          )
        );

        setStaffNurse(
          getValue(data, [
            "Staff Nurse",
            "staffNurse",
            "Staff Name",
            "staffName",
          ])
        );

        setStaffMobile(
          String(
            getValue(data, [
              "Staff Mobile",
              "staffMobile",
              "Staff Contact",
              "staffContact",
            ]) || ""
          )
        );

        setStaffEmail(
          getValue(data, [
            "Staff Email",
            "staffEmail",
            "Email",
          ])
        );

        setAshaName(
          getValue(data, [
            "ASHA Name",
            "ashaName",
          ])
        );

        setAshaMobile(
          String(
            getValue(data, [
              "ASHA Mobile",
              "ashaMobile",
              "ASHA Contact",
              "ashaContact",
            ]) || ""
          )
        );

        setAshaArea(
          getValue(data, [
            "ASHA Area",
            "ashaArea",
            "Area",
          ])
        );
      } catch (apiError) {
        console.log(
          "FACILITY STAFF LOAD ERROR:",
          apiError
        );

        setError(
          apiError?.message ||
            "Unable to load facility and staff details."
        );
      } finally {
        setLoading(false);
      }
    }, [
      username,
      user?.zone,
    ]);

  useEffect(() => {
    loadFacilityData();
  }, [loadFacilityData]);

  // =====================================================
  // GET CURRENT LOCATION
  // =====================================================

  async function getFacilityLocation() {
    if (gettingLocation) {
      return;
    }

    setGettingLocation(true);
    setError("");

    try {
      const permission =
        await Location.requestForegroundPermissionsAsync();

      console.log(
        "LOCATION PERMISSION:",
        permission
      );

      if (
        permission.status !==
        "granted"
      ) {
        Alert.alert(
          "Location Permission Required",
          "Please allow location permission to capture your facility location."
        );

        return;
      }

      const currentLocation =
        await Location.getCurrentPositionAsync(
          {
            accuracy:
              Location.Accuracy.High,
          }
        );

      const latitude =
        currentLocation?.coords?.latitude;

      const longitude =
        currentLocation?.coords?.longitude;

      if (
        latitude === undefined ||
        longitude === undefined
      ) {
        throw new Error(
          "GPS coordinates could not be read."
        );
      }

      const mapsUrl =
        "https://www.google.com/maps?q=" +
        latitude +
        "," +
        longitude;

      setGoogleLocation(
        mapsUrl
      );

      Alert.alert(
        "Location Captured",
        "Current facility location has been captured successfully."
      );
    } catch (locationError) {
      console.log(
        "FACILITY LOCATION ERROR:",
        locationError
      );

      Alert.alert(
        "Location Error",
        locationError?.message ||
          "Unable to get current location."
      );
    } finally {
      setGettingLocation(false);
    }
  }

  // =====================================================
  // VALIDATE FORM
  // =====================================================

  function validateForm() {
    const cleanStaffMobile =
      staffMobile.replace(
        /\D/g,
        ""
      );

    const cleanAshaMobile =
      ashaMobile.replace(
        /\D/g,
        ""
      );

    if (!facilityName.trim()) {
      return (
        "Facility / hospital name is required."
      );
    }

    if (!facilityAddress.trim()) {
      return (
        "Facility address is required."
      );
    }

    if (!staffNurse.trim()) {
      return (
        "Staff nurse name is required."
      );
    }

    if (
      staffMobile.trim() &&
      cleanStaffMobile.length !== 10
    ) {
      return (
        "Staff nurse mobile must contain 10 digits."
      );
    }

    if (
      ashaMobile.trim() &&
      cleanAshaMobile.length !== 10
    ) {
      return (
        "ASHA mobile must contain 10 digits."
      );
    }

    return "";
  }

  // =====================================================
  // SAVE / UPDATE
  // =====================================================

  async function handleSave() {
    const validation =
      validateForm();

    if (validation) {
      Alert.alert(
        "Check Details",
        validation
      );
      return;
    }

    setSaving(true);
    setError("");

    try {
      const cleanStaffMobile =
        staffMobile.replace(
          /\D/g,
          ""
        );

      const cleanAshaMobile =
        ashaMobile.replace(
          /\D/g,
          ""
        );

      const payload = {
        ...(originalData || {}),

        username,

        zone:
          zone ||
          user?.zone ||
          "",

        userZone:
          user?.zone || "",

        facilityName:
          facilityName.trim(),

        facilityAddress:
          facilityAddress.trim(),

        googleLocation:
          googleLocation.trim(),

        staffNurse:
          staffNurse.trim(),

        staffMobile:
          cleanStaffMobile,

        staffEmail:
          staffEmail.trim(),

        ashaName:
          ashaName.trim(),

        ashaMobile:
          cleanAshaMobile,

        ashaArea:
          ashaArea.trim(),

        "Facility Name":
          facilityName.trim(),

        "Facility Address":
          facilityAddress.trim(),

        "Google Location":
          googleLocation.trim(),

        "Staff Nurse":
          staffNurse.trim(),

        "Staff Mobile":
          cleanStaffMobile,

        "Staff Email":
          staffEmail.trim(),

        "ASHA Name":
          ashaName.trim(),

        "ASHA Mobile":
          cleanAshaMobile,

        "ASHA Area":
          ashaArea.trim(),
      };

      console.log(
        "FACILITY STAFF UPDATE PAYLOAD:",
        payload
      );

      const response =
        await updateMyFacilityStaffData(
          payload
        );

      console.log(
        "FACILITY STAFF UPDATE RESPONSE:",
        response
      );

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to save facility details."
        );
      }

      Alert.alert(
        "Saved Successfully",
        "Facility, location and staff details have been updated."
      );

      await loadFacilityData();
    } catch (apiError) {
      console.log(
        "FACILITY STAFF SAVE ERROR:",
        apiError
      );

      setError(
        apiError?.message ||
          "Unable to save facility details."
      );

      Alert.alert(
        "Save Failed",
        apiError?.message ||
          "Unable to save facility details."
      );
    } finally {
      setSaving(false);
    }
  }

  // =====================================================
  // LOADING
  // =====================================================

  if (loading) {
    return (
      <View
        style={
          styles.loadingContainer
        }
      >
        <View
          style={
            styles.loadingCard
          }
        >
          <ActivityIndicator
            size="large"
            color="#2563eb"
          />

          <Text
            style={
              styles.loadingTitle
            }
          >
            Loading Facility Details
          </Text>

          <Text
            style={
              styles.loadingText
            }
          >
            Please wait...
          </Text>
        </View>
      </View>
    );
  }

  // =====================================================
  // SCREEN
  // =====================================================

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={
        Platform.OS === "ios"
          ? "padding"
          : undefined
      }
    >
      {/* HEADER */}

      <View style={styles.header}>
        <Pressable
          style={
            styles.backButton
          }
          onPress={() =>
            navigation.goBack()
          }
        >
          <Text
            style={
              styles.backText
            }
          >
            ‹
          </Text>
        </Pressable>

        <View
          style={
            styles.headerText
          }
        >
          <Text
            style={
              styles.headerTitle
            }
          >
            Facility & Staff
          </Text>

          <Text
            style={
              styles.headerSubtitle
            }
          >
            Manage your assigned facility information
          </Text>
        </View>
      </View>

      {/* ERROR */}

      {error ? (
        <View
          style={
            styles.errorBanner
          }
        >
          <Text
            style={
              styles.errorText
            }
          >
            {error}
          </Text>
        </View>
      ) : null}

      <ScrollView
        contentContainerStyle={
          styles.content
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={
          false
        }
      >
        {/* USER PROFILE */}

        <View
          style={
            styles.profileBanner
          }
        >
          <View
            style={
              styles.profileIcon
            }
          >
            <Text
              style={
                styles.profileIconText
              }
            >
              🏥
            </Text>
          </View>

          <View
            style={
              styles.profileInfo
            }
          >
            <Text
              style={
                styles.profileTitle
              }
            >
              {user?.username ||
                "User"}
            </Text>

            <Text
              style={
                styles.profileSubtitle
              }
            >
              {user?.role ||
                "User"}{" "}
              •{" "}
              {user?.zone ||
                zone ||
                "Zone"}
            </Text>
          </View>
        </View>

        {/* =================================================
            FACILITY INFORMATION
        ================================================= */}

        <SectionCard
          title="Facility Information"
          subtitle="Details of your assigned hospital / UPHC"
        >
          <Field
            label="Facility / Hospital Name *"
            value={
              facilityName
            }
            onChangeText={
              setFacilityName
            }
            placeholder="Enter facility name"
          />

          <Field
            label="Zone"
            value={zone}
            onChangeText={
              setZone
            }
            placeholder="Zone"
            editable={false}
          />

          <Field
            label="Facility Address *"
            value={
              facilityAddress
            }
            onChangeText={
              setFacilityAddress
            }
            placeholder="Enter complete facility address"
            multiline
          />

          {/* =================================================
              GOOGLE LOCATION
          ================================================= */}

          <View
            style={
              styles.locationSection
            }
          >
            <Text
              style={
                styles.label
              }
            >
              Facility Google Location
            </Text>

            <Pressable
              onPress={
                getFacilityLocation
              }
              disabled={
                gettingLocation
              }
              style={[
                styles.locationButton,
                gettingLocation &&
                  styles.disabledButton,
              ]}
            >
              {gettingLocation ? (
                <View
                  style={
                    styles.locationButtonInner
                  }
                >
                  <ActivityIndicator
                    color="#ffffff"
                    size="small"
                  />

                  <Text
                    style={
                      styles.locationButtonText
                    }
                  >
                    Getting Location...
                  </Text>
                </View>
              ) : (
                <View
                  style={
                    styles.locationButtonInner
                  }
                >
                  <Text
                    style={
                      styles.locationIcon
                    }
                  >
                    📍
                  </Text>

                  <Text
                    style={
                      styles.locationButtonText
                    }
                  >
                    Get Current Location
                  </Text>
                </View>
              )}
            </Pressable>

            {googleLocation ? (
              <View
                style={
                  styles.locationSuccessBox
                }
              >
                <View
                  style={
                    styles.locationSuccessHeader
                  }
                >
                  <Text
                    style={
                      styles.locationSuccessTitle
                    }
                  >
                    ✓ Location Available
                  </Text>

                  <Pressable
                    onPress={
                      getFacilityLocation
                    }
                    disabled={
                      gettingLocation
                    }
                  >
                    <Text
                      style={
                        styles.locationUpdateText
                      }
                    >
                      Update
                    </Text>
                  </Pressable>
                </View>

                <Text
                  style={
                    styles.locationSuccessText
                  }
                  numberOfLines={3}
                >
                  {googleLocation}
                </Text>
              </View>
            ) : (
              <Text
                style={
                  styles.locationHint
                }
              >
                No location saved yet. Press
                "Get Current Location" to capture
                the facility GPS location.
              </Text>
            )}
          </View>
        </SectionCard>

        {/* =================================================
            STAFF NURSE
        ================================================= */}

        <SectionCard
          title="Staff Nurse"
          subtitle="Primary staff information for ANC tracking"
        >
          <Field
            label="Staff Nurse Name *"
            value={
              staffNurse
            }
            onChangeText={
              setStaffNurse
            }
            placeholder="Enter staff nurse name"
          />

          <Field
            label="Staff Mobile"
            value={
              staffMobile
            }
            onChangeText={(value) =>
              setStaffMobile(
                value
                  .replace(
                    /\D/g,
                    ""
                  )
                  .slice(
                    0,
                    10
                  )
              )
            }
            placeholder="10-digit mobile number"
            keyboardType="phone-pad"
          />

          <Field
            label="Staff Email"
            value={
              staffEmail
            }
            onChangeText={
              setStaffEmail
            }
            placeholder="staff@example.com"
            keyboardType="email-address"
          />
        </SectionCard>

        {/* =================================================
            ASHA
        ================================================= */}

        <SectionCard
          title="ASHA Information"
          subtitle="Community-level ANC follow-up support"
        >
          <Field
            label="ASHA Name"
            value={
              ashaName
            }
            onChangeText={
              setAshaName
            }
            placeholder="Enter ASHA name"
          />

          <Field
            label="ASHA Mobile"
            value={
              ashaMobile
            }
            onChangeText={(value) =>
              setAshaMobile(
                value
                  .replace(
                    /\D/g,
                    ""
                  )
                  .slice(
                    0,
                    10
                  )
              )
            }
            placeholder="10-digit mobile number"
            keyboardType="phone-pad"
          />

          <Field
            label="ASHA Area / Village"
            value={
              ashaArea
            }
            onChangeText={
              setAshaArea
            }
            placeholder="Enter assigned area or village"
          />
        </SectionCard>

        {/* SAVE */}

        <Pressable
          onPress={
            handleSave
          }
          disabled={saving}
          style={[
            styles.saveButton,
            saving &&
              styles.disabledButton,
          ]}
        >
          {saving ? (
            <View
              style={
                styles.saveButtonInner
              }
            >
              <ActivityIndicator
                color="#ffffff"
              />

              <Text
                style={
                  styles.saveText
                }
              >
                Saving...
              </Text>
            </View>
          ) : (
            <Text
              style={
                styles.saveText
              }
            >
              Save Facility & Staff Details
            </Text>
          )}
        </Pressable>

        {/* NOTE */}

        <View
          style={
            styles.noteCard
          }
        >
          <Text
            style={
              styles.noteTitle
            }
          >
            Access Note
          </Text>

          <Text
            style={
              styles.noteText
            }
          >
            Your facility information is linked
            to your assigned user account and
            zone. Location is stored as a Google
            Maps link and can be updated whenever
            required.
          </Text>
        </View>

        <View
          style={
            styles.bottomSpace
          }
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f4f8",
  },

  loadingContainer: {
    flex: 1,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },

  loadingCard: {
    width: "100%",
    maxWidth: 380,
    backgroundColor: "#ffffff",
    borderRadius: 22,
    padding: 30,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },

  loadingTitle: {
    marginTop: 16,
    color: "#1e293b",
    fontSize: 17,
    fontWeight: "800",
  },

  loadingText: {
    marginTop: 6,
    color: "#64748b",
    fontSize: 13,
  },

  header: {
    backgroundColor: "#1a365d",
    paddingTop:
      Platform.OS === "android"
        ? 36
        : 54,
    paddingHorizontal: 18,
    paddingBottom: 18,
    flexDirection: "row",
    alignItems: "center",
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor:
      "rgba(255,255,255,0.14)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },

  backText: {
    color: "#ffffff",
    fontSize: 32,
    lineHeight: 34,
  },

  headerText: {
    flex: 1,
  },

  headerTitle: {
    color: "#ffffff",
    fontSize: 21,
    fontWeight: "800",
  },

  headerSubtitle: {
    color: "#dbeafe",
    fontSize: 12,
    marginTop: 3,
  },

  errorBanner: {
    margin: 14,
    marginBottom: 0,
    backgroundColor: "#fee2e2",
    borderColor: "#fecaca",
    borderWidth: 1,
    borderRadius: 12,
    padding: 11,
  },

  errorText: {
    color: "#991b1b",
    fontSize: 12,
    lineHeight: 18,
  },

  content: {
    padding: 16,
    paddingBottom: 40,
  },

  profileBanner: {
    backgroundColor: "#2563eb",
    borderRadius: 20,
    padding: 15,
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 14,
  },

  profileIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor:
      "rgba(255,255,255,0.14)",
    justifyContent: "center",
    alignItems: "center",
  },

  profileIconText: {
    fontSize: 25,
  },

  profileInfo: {
    marginLeft: 12,
    flex: 1,
  },

  profileTitle: {
    color: "#ffffff",
    fontSize: 17,
    fontWeight: "800",
  },

  profileSubtitle: {
    marginTop: 4,
    color: "#dbeafe",
    fontSize: 12,
  },

  card: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 17,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    elevation: 2,
  },

  sectionTitle: {
    color: "#1e293b",
    fontSize: 17,
    fontWeight: "800",
  },

  sectionSubtitle: {
    color: "#64748b",
    fontSize: 12,
    marginTop: 4,
    lineHeight: 18,
  },

  sectionBody: {
    marginTop: 15,
  },

  field: {
    marginBottom: 14,
  },

  label: {
    color: "#334155",
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 7,
  },

  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 12,
    paddingHorizontal: 13,
    backgroundColor: "#ffffff",
    color: "#1e293b",
    fontSize: 14,
  },

  textArea: {
    minHeight: 95,
    paddingTop: 12,
  },

  disabledInput: {
    backgroundColor: "#f1f5f9",
    color: "#64748b",
  },

  // =====================================================
  // LOCATION
  // =====================================================

  locationSection: {
    marginBottom: 14,
  },

  locationButton: {
    minHeight: 50,
    borderRadius: 13,
    backgroundColor: "#0f766e",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 14,
  },

  locationButtonInner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },

  locationIcon: {
    fontSize: 18,
    marginRight: 8,
  },

  locationButtonText: {
    color: "#ffffff",
    fontSize: 13,
    fontWeight: "800",
  },

  locationSuccessBox: {
    marginTop: 9,
    padding: 11,
    borderRadius: 12,
    backgroundColor: "#ecfdf5",
    borderWidth: 1,
    borderColor: "#a7f3d0",
  },

  locationSuccessHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  locationSuccessTitle: {
    color: "#047857",
    fontSize: 12,
    fontWeight: "800",
  },

  locationUpdateText: {
    color: "#2563eb",
    fontSize: 11,
    fontWeight: "800",
  },

  locationSuccessText: {
    color: "#065f46",
    fontSize: 11,
    lineHeight: 16,
    marginTop: 5,
  },

  locationHint: {
    color: "#94a3b8",
    fontSize: 11,
    marginTop: 7,
    lineHeight: 16,
  },

  // =====================================================
  // SAVE
  // =====================================================

  saveButton: {
    minHeight: 53,
    borderRadius: 14,
    backgroundColor: "#15803d",
    justifyContent: "center",
    alignItems: "center",
  },

  saveButtonInner: {
    flexDirection: "row",
    alignItems: "center",
  },

  saveText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "800",
    marginLeft: 9,
  },

  disabledButton: {
    opacity: 0.65,
  },

  // =====================================================
  // NOTE
  // =====================================================

  noteCard: {
    marginTop: 14,
    backgroundColor: "#eff6ff",
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: "#bfdbfe",
  },

  noteTitle: {
    color: "#1d4ed8",
    fontSize: 13,
    fontWeight: "800",
  },

  noteText: {
    marginTop: 5,
    color: "#475569",
    fontSize: 12,
    lineHeight: 18,
  },

  bottomSpace: {
    height: 40,
  },
});
