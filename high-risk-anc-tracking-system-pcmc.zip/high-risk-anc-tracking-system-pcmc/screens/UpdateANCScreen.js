//screens/UpdateANCScreens.js
import React, {
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import DateTimePicker from "@react-native-community/datetimepicker";

import {
  getANCRecordByMobile,
  updateANCRecord,
} from "../api/api";

import { useAuth } from "../App";

const HIGH_RISK_OPTIONS = [
  "None / कोणताही उच्च जोखीम घटक नाही",
  "Anemia",
  "Pregnancy Induced Hypertension (PIH) / Hypertension (HTN)",
  "Gestational Diabetes Mellitus (GDM) / Diabetes Mellitus (DM)",
  "Hypothyroidism / Thyroid Disorders",
  "Gestational Thrombocytopenia",
  "Previous LSCS (Cesarean Section)",
  "History of Recurrent Abortions or Miscarriages",
  "History of Ectopic Pregnancy",
  "Previous Intrauterine Death (IUD) / Stillbirth",
  "History of Neonatal or Infant Death",
  "History of Preterm / Premature Delivery",
  "History of Postpartum Hemorrhage (PPH)",
  "History of Home Deliveries",
  "Cervical Incompetence / Cervical Stitch",
  "Multi-parity / Multigravida",
  "Multiple Pregnancy (Twins / Triplets)",
  "Low-Lying Placenta / Placenta Previa",
  "Breech Presentation / Abnormal Lie",
  "Fetal Growth Restriction (IUGR)",
  "Elderly Gravida / Elderly Primi",
  "Teenage Pregnancy",
  "Short Stature",
  "Rh Negative Blood Groups (A-, B-, AB-, O- negative)",
  "Rh Incompatibility",
  "Allergy to Iron Sucrose / Medications",
  "Other",
];

const FREQUENCIES = [
  "Daily",
  "Weekly",
  "Fortnightly",
  "Monthly",
  "Not Needed",
];

function getValue(record, keys) {
  for (const key of keys) {
    if (
      record &&
      record[key] !== undefined &&
      record[key] !== null
    ) {
      return record[key];
    }
  }

  return "";
}

function parseDate(value) {
  if (!value) {
    return new Date();
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return new Date();
  }

  return date;
}

function formatDate(value) {
  if (!value) {
    return "";
  }

  const date = parseDate(value);

  return `${String(
    date.getDate()
  ).padStart(2, "0")}/${String(
    date.getMonth() + 1
  ).padStart(2, "0")}/${date.getFullYear()}`;
}

function SectionCard({
  title,
  subtitle,
  children,
}) {
  return (
    <View style={styles.card}>
      <Text style={styles.sectionTitle}>
        {title}
      </Text>

      {subtitle ? (
        <Text style={styles.sectionSubtitle}>
          {subtitle}
        </Text>
      ) : null}

      <View style={styles.sectionBody}>
        {children}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = "default",
  editable = true,
  multiline = false,
}) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>
        {label}
      </Text>

      <TextInput
        value={
          value === null ||
          value === undefined
            ? ""
            : String(value)
        }
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#94a3b8"
        keyboardType={keyboardType}
        editable={editable}
        multiline={multiline}
        textAlignVertical={
          multiline ? "top" : "center"
        }
        style={[
          styles.input,
          !editable &&
            styles.inputDisabled,
          multiline && styles.textArea,
        ]}
      />
    </View>
  );
}

function DateField({
  label,
  value,
  onChange,
}) {
  const [open, setOpen] =
    useState(false);

  return (
    <View style={styles.field}>
      <Text style={styles.label}>
        {label}
      </Text>

      <Pressable
        style={styles.dateInput}
        onPress={() => setOpen(true)}
      >
        <Text
          style={[
            styles.dateText,
            !value &&
              styles.placeholderText,
          ]}
        >
          {value
            ? formatDate(value)
            : "Select date"}
        </Text>

        <Text style={styles.dateIcon}>
          📅
        </Text>
      </Pressable>

      {open ? (
        <DateTimePicker
          value={parseDate(value)}
          mode="date"
          display={
            Platform.OS === "ios"
              ? "spinner"
              : "default"
          }
          onChange={(
            event,
            selectedDate
          ) => {
            setOpen(false);

            if (
              event?.type ===
                "dismissed" ||
              !selectedDate
            ) {
              return;
            }

            onChange(selectedDate);
          }}
        />
      ) : null}
    </View>
  );
}

function ChoiceChip({
  label,
  selected,
  onPress,
}) {
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.chip,
        selected &&
          styles.chipSelected,
      ]}
    >
      <Text
        style={[
          styles.chipText,
          selected &&
            styles.chipTextSelected,
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export default function UpdateANCScreen({
  navigation,
}) {
  const { user } = useAuth();

  const [mobile, setMobile] =
    useState("");

  const [record, setRecord] =
    useState(null);

  const [searching, setSearching] =
    useState(false);

  const [saving, setSaving] =
    useState(false);

  const [error, setError] =
    useState("");

  const [patientName, setPatientName] =
    useState("");

  const [age, setAge] =
    useState("");

  const [address, setAddress] =
    useState("");

  const [village, setVillage] =
    useState("");

  const [taluka, setTaluka] =
    useState("");

  const [district, setDistrict] =
    useState("Pune");

  const [contact1, setContact1] =
    useState("");

  const [contact2, setContact2] =
    useState("");

  const [aadhaar, setAadhaar] =
    useState("");

  const [rchNumber, setRchNumber] =
    useState("");

  const [lmp, setLmp] =
    useState(null);

  const [edd, setEdd] =
    useState(null);

  const [gpal, setGpal] =
    useState("");

  const [highRisk, setHighRisk] =
    useState("");

  const [highRiskOther, setHighRiskOther] =
    useState("");

  const [pastHistory, setPastHistory] =
    useState("");

  const [pastHistoryOther, setPastHistoryOther] =
    useState("");

  const [firstVisitDate, setFirstVisitDate] =
    useState(null);

  const [followupFrequency, setFollowupFrequency] =
    useState("Weekly");

  const isOtherRisk =
    String(highRisk).trim() === "Other";

  const isOtherPastHistory =
    String(pastHistory).trim()
      .toLowerCase() === "other";

  function clearForm() {
    setRecord(null);
    setPatientName("");
    setAge("");
    setAddress("");
    setVillage("");
    setTaluka("");
    setDistrict("Pune");
    setContact1("");
    setContact2("");
    setAadhaar("");
    setRchNumber("");
    setLmp(null);
    setEdd(null);
    setGpal("");
    setHighRisk("");
    setHighRiskOther("");
    setPastHistory("");
    setPastHistoryOther("");
    setFirstVisitDate(null);
    setFollowupFrequency("Weekly");
  }

  function populateForm(data) {
    setPatientName(
      getValue(data, [
        "Patient Name",
        "patientName",
        "name",
      ])
    );

    setAge(
      String(
        getValue(data, [
          "Age",
          "age",
        ]) || ""
      )
    );

    setAddress(
      getValue(data, [
        "Address",
        "address",
      ])
    );

    setVillage(
      getValue(data, [
        "Village",
        "village",
      ])
    );

    setTaluka(
      getValue(data, [
        "Taluka",
        "taluka",
      ])
    );

    setDistrict(
      getValue(data, [
        "District",
        "district",
      ]) || "Pune"
    );

    setContact1(
      String(
        getValue(data, [
          "Contact 1",
          "contact1",
          "Mobile",
        ]) || ""
      )
    );

    setContact2(
      String(
        getValue(data, [
          "Contact 2",
          "contact2",
        ]) || ""
      )
    );

    setAadhaar(
      String(
        getValue(data, [
          "Aadhaar",
          "aadhaar",
        ]) || ""
      )
    );

    setRchNumber(
      String(
        getValue(data, [
          "RCH Number",
          "rchNumber",
          "RCH",
        ]) || ""
      )
    );

    setLmp(
      parseDate(
        getValue(data, [
          "LMP",
          "lmp",
        ])
      )
    );

    setEdd(
      parseDate(
        getValue(data, [
          "EDD",
          "edd",
        ])
      )
    );

    setGpal(
      getValue(data, [
        "GPAL",
        "gpal",
      ])
    );

    setHighRisk(
      getValue(data, [
        "High Risk",
        "highRisk",
      ])
    );

    setHighRiskOther(
      getValue(data, [
        "High Risk Other",
        "highRiskOther",
      ])
    );

    setPastHistory(
      getValue(data, [
        "Past History",
        "pastHistory",
      ])
    );

    setPastHistoryOther(
      getValue(data, [
        "Past History Other",
        "pastHistoryOther",
      ])
    );

    setFirstVisitDate(
      parseDate(
        getValue(data, [
          "First Visit Date",
          "firstVisitDate",
        ])
      )
    );

    setFollowupFrequency(
      getValue(data, [
        "Followup Frequency",
        "followupFrequency",
      ]) || "Weekly"
    );
  }

  async function searchRecord() {
    const cleanMobile =
      mobile.replace(/\D/g, "");

    setError("");

    if (
      cleanMobile.length !== 10
    ) {
      setError(
        "Please enter a valid 10-digit mobile number."
      );
      return;
    }

    setSearching(true);
    setRecord(null);

    try {
      const response =
        await getANCRecordByMobile(
          cleanMobile
        );

      const result =
        response?.data ?? response;

      if (!result) {
        throw new Error(
          "No ANC record found for this mobile number."
        );
      }

      let foundRecord =
        result?.record ||
        result?.data ||
        result;

      if (
        Array.isArray(foundRecord)
      ) {
        foundRecord =
          foundRecord[0];
      }

      if (
        foundRecord?.success === false
      ) {
        throw new Error(
          foundRecord.message ||
            "ANC record was not found."
        );
      }

      if (
        !foundRecord ||
        typeof foundRecord !==
          "object"
      ) {
        throw new Error(
          "No ANC record found for this mobile number."
        );
      }

      setRecord(foundRecord);
      populateForm(foundRecord);
    } catch (apiError) {
      clearForm();

      setMobile(cleanMobile);

      setError(
        apiError?.message ||
          "Unable to find ANC record."
      );
    } finally {
      setSearching(false);
    }
  }

  function validateForm() {
    const cleanMobile =
      contact1.replace(/\D/g, "");

    const numericAge =
      Number(age);

    if (!patientName.trim()) {
      return "Patient name is required.";
    }

    if (
      !Number.isFinite(numericAge) ||
      numericAge < 10 ||
      numericAge > 60
    ) {
      return "Age must be between 10 and 60 years.";
    }

    if (
      cleanMobile.length !== 10
    ) {
      return "Contact 1 must contain exactly 10 digits.";
    }

    if (
      aadhaar.trim() &&
      !/^\d{12}$/.test(
        aadhaar.trim()
      )
    ) {
      return "Aadhaar must contain exactly 12 digits.";
    }

    if (!lmp) {
      return "LMP is required.";
    }

    if (!edd) {
      return "EDD is required.";
    }

    if (lmp > edd) {
      return "LMP cannot be after EDD.";
    }

    if (!highRisk) {
      return "Please select the high-risk status.";
    }

    if (
      isOtherRisk &&
      !highRiskOther.trim()
    ) {
      return "Please specify the other high-risk factor.";
    }

    if (
      isOtherPastHistory &&
      !pastHistoryOther.trim()
    ) {
      return "Please specify other past history.";
    }

    if (!firstVisitDate) {
      return "First visit date is required.";
    }

    return "";
  }

  async function handleUpdate() {
    if (!record) {
      Alert.alert(
        "Find Record",
        "Please search for an ANC record first."
      );
      return;
    }

    const validation =
      validateForm();

    if (validation) {
      Alert.alert(
        "Check Details",
        validation
      );
      return;
    }

    setSaving(true);
    setError("");

    try {
      const sr = getValue(record, [
        "SR",
        "sr",
        "Sr",
      ]);

      const zone = getValue(record, [
        "Zone",
        "zone",
      ]);

      const hospitalName =
        getValue(record, [
          "Hospital Name",
          "hospitalName",
          "hospital",
        ]);

      const staffNurse =
        getValue(record, [
          "Staff Nurse",
          "staffNurse",
        ]);

      const ashaName =
        getValue(record, [
          "ASHA Name",
          "ashaName",
        ]);

      const payload = {
        sr,

        Zone: zone,
        zone,

        "Hospital Name":
          hospitalName,
        hospitalName,

        "Staff Nurse":
          staffNurse,
        staffNurse,

        "ASHA Name":
          ashaName,
        ashaName,

        "Patient Name":
          patientName.trim(),
        patientName:
          patientName.trim(),

        Age: Number(age),

        Address:
          address.trim(),
        address:
          address.trim(),

        Village:
          village.trim(),
        village:
          village.trim(),

        Taluka:
          taluka.trim(),
        taluka:
          taluka.trim(),

        District:
          district.trim(),
        district:
          district.trim(),

        "Contact 1":
          contact1.replace(/\D/g, ""),
        contact1:
          contact1.replace(/\D/g, ""),

        "Contact 2":
          contact2.replace(/\D/g, ""),
        contact2:
          contact2.replace(/\D/g, ""),

        Aadhaar:
          aadhaar.trim(),
        aadhaar:
          aadhaar.trim(),

        "RCH Number":
          rchNumber.trim(),
        rchNumber:
          rchNumber.trim(),

        LMP:
          lmp.toISOString(),

        EDD:
          edd.toISOString(),

        GPAL:
          gpal.trim(),

        "High Risk":
          highRisk,

        "High Risk Other":
          isOtherRisk
            ? highRiskOther.trim()
            : "",

        "Past History":
          pastHistory.trim(),

        "Past History Other":
          isOtherPastHistory
            ? pastHistoryOther.trim()
            : "",

        "First Visit Date":
          firstVisitDate.toISOString(),

        "Followup Frequency":
          followupFrequency,

        username:
          user?.username || "",

        role:
          user?.role || "",

        userZone:
          user?.zone || "",
      };

      const response =
        await updateANCRecord(
          payload
        );

      const result =
        response?.data ?? response;

      if (
        !result ||
        result.success === false
      ) {
        throw new Error(
          result?.message ||
            "Unable to update ANC record."
        );
      }

      Alert.alert(
        "Record Updated",
        "ANC record has been updated successfully.",
        [
          {
            text: "OK",
            onPress: async () => {
              try {
                const refreshed =
                  await getANCRecordByMobile(
                    contact1.replace(
                      /\D/g,
                      ""
                    )
                  );

                const refreshedResult =
                  refreshed?.data ??
                  refreshed;

                let refreshedRecord =
                  refreshedResult?.record ||
                  refreshedResult?.data ||
                  refreshedResult;

                if (
                  Array.isArray(
                    refreshedRecord
                  )
                ) {
                  refreshedRecord =
                    refreshedRecord[0];
                }

                if (
                  refreshedRecord &&
                  typeof refreshedRecord ===
                    "object"
                ) {
                  setRecord(
                    refreshedRecord
                  );
                  populateForm(
                    refreshedRecord
                  );
                }
              } catch (error) {
                console.log(
                  "Unable to refresh record:",
                  error
                );
              }
            },
          },
        ]
      );
    } catch (apiError) {
      setError(
        apiError?.message ||
          "Unable to update ANC record."
      );

      Alert.alert(
        "Update Failed",
        apiError?.message ||
          "Unable to update ANC record."
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={
        Platform.OS === "ios"
          ? "padding"
          : undefined
      }
    >
      <View style={styles.header}>
        <Pressable
          style={styles.backButton}
          onPress={() =>
            navigation.goBack()
          }
        >
          <Text style={styles.backText}>
            ‹
          </Text>
        </Pressable>

        <View style={styles.headerText}>
          <Text style={styles.headerTitle}>
            Update ANC Record
          </Text>

          <Text style={styles.headerSubtitle}>
            Search by registered mobile number
          </Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={
          styles.content
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <SectionCard
          title="Find ANC Record"
          subtitle="Enter the registered contact number"
        >
          <View style={styles.searchRow}>
            <TextInput
              value={mobile}
              onChangeText={(value) =>
                setMobile(
                  value
                    .replace(
                      /\D/g,
                      ""
                    )
                    .slice(0, 10)
                )
              }
              placeholder="10-digit mobile number"
              placeholderTextColor="#94a3b8"
              keyboardType="phone-pad"
              style={styles.searchInput}
              maxLength={10}
            />

            <Pressable
              onPress={searchRecord}
              disabled={searching}
              style={[
                styles.searchButton,
                searching &&
                  styles.disabledButton,
              ]}
            >
              {searching ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.buttonText
                  }
                >
                  Search
                </Text>
              )}
            </Pressable>
          </View>

          {error ? (
            <View style={styles.errorBox}>
              <Text
                style={styles.errorText}
              >
                {error}
              </Text>
            </View>
          ) : null}
        </SectionCard>

        {record ? (
          <>
            <View style={styles.recordBanner}>
              <View
                style={styles.recordIcon}
              >
                <Text
                  style={
                    styles.recordIconText
                  }
                >
                  ✓
                </Text>
              </View>

              <View
                style={styles.recordInfo}
              >
                <Text
                  style={
                    styles.recordPatient
                  }
                >
                  {getValue(record, [
                    "Patient Name",
                    "patientName",
                    "name",
                  ]) ||
                    "Patient"}
                </Text>

                <Text
                  style={
                    styles.recordHospital
                  }
                >
                  {getValue(record, [
                    "Hospital Name",
                    "hospitalName",
                  ]) ||
                    "Hospital"}
                </Text>
              </View>
            </View>

            <SectionCard
              title="ANC Registration"
              subtitle="Update patient registration information"
            >
              <Field
                label="Patient Name *"
                value={patientName}
                onChangeText={
                  setPatientName
                }
                placeholder="Enter patient name"
              />

              <Field
                label="Age *"
                value={age}
                onChangeText={(value) =>
                  setAge(
                    value
                      .replace(
                        /\D/g,
                        ""
                      )
                      .slice(0, 2)
                  )
                }
                placeholder="Age"
                keyboardType="number-pad"
              />

              <Field
                label="Address"
                value={address}
                onChangeText={
                  setAddress
                }
                placeholder="Enter address"
                multiline
              />

              <Field
                label="Village"
                value={village}
                onChangeText={
                  setVillage
                }
                placeholder="Enter village"
              />

              <Field
                label="Taluka"
                value={taluka}
                onChangeText={
                  setTaluka
                }
                placeholder="Enter taluka"
              />

              <Field
                label="District"
                value={district}
                onChangeText={
                  setDistrict
                }
                placeholder="District"
              />

              <Field
                label="Contact 1 *"
                value={contact1}
                onChangeText={(value) =>
                  setContact1(
                    value
                      .replace(
                        /\D/g,
                        ""
                      )
                      .slice(0, 10)
                  )
                }
                placeholder="10-digit mobile"
                keyboardType="phone-pad"
              />

              <Field
                label="Contact 2"
                value={contact2}
                onChangeText={(value) =>
                  setContact2(
                    value
                      .replace(
                        /\D/g,
                        ""
                      )
                      .slice(0, 10)
                  )
                }
                placeholder="Alternate mobile"
                keyboardType="phone-pad"
              />

              <Field
                label="Aadhaar"
                value={aadhaar}
                onChangeText={(value) =>
                  setAadhaar(
                    value
                      .replace(
                        /\D/g,
                        ""
                      )
                      .slice(0, 12)
                  )
                }
                placeholder="12-digit Aadhaar"
                keyboardType="number-pad"
              />

              <Field
                label="RCH Number"
                value={rchNumber}
                onChangeText={
                  setRchNumber
                }
                placeholder="RCH number"
              />

              <DateField
                label="LMP *"
                value={lmp}
                onChange={setLmp}
              />

              <DateField
                label="EDD *"
                value={edd}
                onChange={setEdd}
              />

              <Field
                label="GPAL"
                value={gpal}
                onChangeText={setGpal}
                placeholder="Example: G2 P1 A0 L1"
              />
            </SectionCard>

            <SectionCard
              title="High-Risk Information"
              subtitle="Update high-risk and past-history details"
            >
              <Text style={styles.label}>
                High-Risk Status *
              </Text>

              <View style={styles.chipWrap}>
                {HIGH_RISK_OPTIONS.map(
                  (item) => (
                    <ChoiceChip
                      key={item}
                      label={item}
                      selected={
                        highRisk === item
                      }
                      onPress={() =>
                        setHighRisk(
                          item
                        )
                      }
                    />
                  )
                )}
              </View>

              {isOtherRisk ? (
                <Field
                  label="Other High-Risk Factor *"
                  value={highRiskOther}
                  onChangeText={
                    setHighRiskOther
                  }
                  placeholder="Specify high-risk factor"
                  multiline
                />
              ) : null}

              <Field
                label="Past History"
                value={pastHistory}
                onChangeText={
                  setPastHistory
                }
                placeholder="Enter relevant past history"
                multiline
              />

              {isOtherPastHistory ? (
                <Field
                  label="Other Past History *"
                  value={
                    pastHistoryOther
                  }
                  onChangeText={
                    setPastHistoryOther
                  }
                  placeholder="Specify other past history"
                  multiline
                />
              ) : null}

              <DateField
                label="First Visit Date *"
                value={firstVisitDate}
                onChange={
                  setFirstVisitDate
                }
              />
            </SectionCard>

            <SectionCard
              title="Follow-up Plan"
              subtitle="Choose how frequently this ANC should be followed"
            >
              <Text style={styles.label}>
                Follow-up Frequency
              </Text>

              <View style={styles.chipWrap}>
                {FREQUENCIES.map(
                  (item) => (
                    <ChoiceChip
                      key={item}
                      label={item}
                      selected={
                        followupFrequency ===
                        item
                      }
                      onPress={() =>
                        setFollowupFrequency(
                          item
                        )
                      }
                    />
                  )
                )}
              </View>
            </SectionCard>

            <Pressable
              onPress={handleUpdate}
              disabled={saving}
              style={[
                styles.updateButton,
                saving &&
                  styles.disabledButton,
              ]}
            >
              {saving ? (
                <ActivityIndicator
                  color="#ffffff"
                />
              ) : (
                <Text
                  style={
                    styles.updateButtonText
                  }
                >
                  Update ANC Record
                </Text>
              )}
            </Pressable>

            <View
              style={styles.bottomSpace}
            />
          </>
        ) : (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyIcon}>
              🔎
            </Text>

            <Text style={styles.emptyTitle}>
              Search an ANC Record
            </Text>

            <Text style={styles.emptyText}>
              Enter the registered mobile number
              above to load the patient record for
              updating.
            </Text>
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f4f8",
  },

  header: {
    backgroundColor: "#1a365d",
    paddingTop:
      Platform.OS === "android"
        ? 36
        : 54,
    paddingHorizontal: 18,
    paddingBottom: 18,
    flexDirection: "row",
    alignItems: "center",
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor:
      "rgba(255,255,255,0.14)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },

  backText: {
    color: "#ffffff",
    fontSize: 32,
    lineHeight: 34,
  },

  headerText: {
    flex: 1,
  },

  headerTitle: {
    color: "#ffffff",
    fontSize: 21,
    fontWeight: "800",
  },

  headerSubtitle: {
    color: "#dbeafe",
    fontSize: 12,
    marginTop: 3,
  },

  content: {
    padding: 16,
    paddingBottom: 40,
  },

  card: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 17,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    elevation: 2,
  },

  sectionTitle: {
    color: "#1e293b",
    fontSize: 17,
    fontWeight: "800",
  },

  sectionSubtitle: {
    marginTop: 4,
    color: "#64748b",
    fontSize: 12,
    lineHeight: 18,
  },

  sectionBody: {
    marginTop: 15,
  },

  searchRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  searchInput: {
    flex: 1,
    height: 50,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 13,
    paddingHorizontal: 13,
    color: "#1e293b",
    backgroundColor: "#ffffff",
    fontSize: 14,
    marginRight: 9,
  },

  searchButton: {
    height: 50,
    paddingHorizontal: 18,
    borderRadius: 13,
    backgroundColor: "#2563eb",
    justifyContent: "center",
    alignItems: "center",
  },

  buttonText: {
    color: "#ffffff",
    fontSize: 13,
    fontWeight: "800",
  },

  errorBox: {
    marginTop: 12,
    backgroundColor: "#fee2e2",
    borderWidth: 1,
    borderColor: "#fecaca",
    borderRadius: 12,
    padding: 11,
  },

  errorText: {
    color: "#991b1b",
    fontSize: 12,
    lineHeight: 18,
  },

  recordBanner: {
    backgroundColor: "#1d4ed8",
    borderRadius: 18,
    padding: 14,
    marginBottom: 14,
    flexDirection: "row",
    alignItems: "center",
  },

  recordIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor:
      "rgba(255,255,255,0.15)",
    justifyContent: "center",
    alignItems: "center",
  },

  recordIconText: {
    color: "#ffffff",
    fontSize: 23,
    fontWeight: "800",
  },

  recordInfo: {
    marginLeft: 12,
    flex: 1,
  },

  recordPatient: {
    color: "#ffffff",
    fontSize: 17,
    fontWeight: "800",
  },

  recordHospital: {
    color: "#dbeafe",
    fontSize: 12,
    marginTop: 3,
  },

  field: {
    marginBottom: 14,
  },

  label: {
    color: "#334155",
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 7,
  },

  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 12,
    paddingHorizontal: 13,
    backgroundColor: "#ffffff",
    color: "#1e293b",
    fontSize: 14,
  },

  inputDisabled: {
    backgroundColor: "#f1f5f9",
    color: "#64748b",
  },

  textArea: {
    minHeight: 90,
    paddingTop: 12,
  },

  dateInput: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 12,
    paddingHorizontal: 13,
    backgroundColor: "#ffffff",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  dateText: {
    color: "#1e293b",
    fontSize: 14,
  },

  placeholderText: {
    color: "#94a3b8",
  },

  dateIcon: {
    fontSize: 17,
  },

  chipWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 5,
  },

  chip: {
    borderWidth: 1,
    borderColor: "#cbd5e1",
    backgroundColor: "#f8fafc",
    borderRadius: 18,
    paddingVertical: 9,
    paddingHorizontal: 12,
  },

  chipSelected: {
    borderColor: "#2563eb",
    backgroundColor: "#eff6ff",
  },

  chipText: {
    color: "#475569",
    fontSize: 11,
    lineHeight: 15,
  },

  chipTextSelected: {
    color: "#1d4ed8",
    fontWeight: "700",
  },

  updateButton: {
    minHeight: 52,
    borderRadius: 14,
    backgroundColor: "#15803d",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 3,
  },

  updateButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "800",
  },

  disabledButton: {
    opacity: 0.65,
  },

  emptyCard: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 28,
    marginTop: 20,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },

  emptyIcon: {
    fontSize: 40,
  },

  emptyTitle: {
    marginTop: 12,
    color: "#1e293b",
    fontSize: 17,
    fontWeight: "800",
  },

  emptyText: {
    marginTop: 7,
    color: "#64748b",
    fontSize: 13,
    lineHeight: 19,
    textAlign: "center",
  },

  bottomSpace: {
    height: 40,
  },
});
 
