// screens/DashboardScreen.js

import React, {
  useCallback,
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  useFocusEffect,
} from "@react-navigation/native";

import {
  getANCData,
  getReportSummary,
} from "../api/api";

import {
  useAuth,
} from "../App";

/* =========================================================
   SUMMARY CARD
   ========================================================= */

function SummaryCard({
  icon,
  title,
  value,
  subtitle,
}) {
  return (
    <View style={styles.summaryCard}>
      <View style={styles.summaryIcon}>
        <Text style={styles.summaryIconText}>
          {icon}
        </Text>
      </View>

      <Text style={styles.summaryTitle}>
        {title}
      </Text>

      <Text style={styles.summaryValue}>
        {value}
      </Text>

      <Text style={styles.summarySubtitle}>
        {subtitle}
      </Text>
    </View>
  );
}

/* =========================================================
   MODULE CARD
   ========================================================= */

function ModuleCard({
  icon,
  title,
  subtitle,
  onPress,
}) {
  return (
    <Pressable
      onPress={onPress}
      style={styles.moduleCard}
    >
      <View style={styles.moduleIcon}>
        <Text style={styles.moduleIconText}>
          {icon}
        </Text>
      </View>

      <View style={styles.moduleText}>
        <Text style={styles.moduleTitle}>
          {title}
        </Text>

        <Text style={styles.moduleSubtitle}>
          {subtitle}
        </Text>
      </View>

      <Text style={styles.moduleArrow}>
        ›
      </Text>
    </Pressable>
  );
}

/* =========================================================
   TIMEOUT HELPERS
   ========================================================= */

function wait(milliseconds) {
  return new Promise(function (resolve) {
    setTimeout(resolve, milliseconds);
  });
}

async function withTimeout(
  promise,
  milliseconds
) {
  return Promise.race([
    promise,

    wait(milliseconds).then(
      function () {
        throw new Error(
          "Dashboard data request timed out."
        );
      }
    ),
  ]);
}

/* =========================================================
   DATA HELPERS
   ========================================================= */

function getValue(
  record,
  keys
) {
  if (!record) {
    return "";
  }

  for (
    var i = 0;
    i < keys.length;
    i++
  ) {
    var key = keys[i];

    if (
      record[key] !== undefined &&
      record[key] !== null &&
      String(
        record[key]
      ).trim() !== ""
    ) {
      return record[key];
    }
  }

  return "";
}

function isHighRisk(record) {
  var value = String(
    getValue(record, [
      "High Risk",
      "highRisk",
    ])
  )
    .trim()
    .toLowerCase();

  if (!value) {
    return false;
  }

  if (
    value.indexOf("none") !== -1 ||
    value.indexOf(
      "no high risk"
    ) !== -1 ||
    value.indexOf(
      "कोणताही उच्च जोखीम घटक नाही"
    ) !== -1
  ) {
    return false;
  }

  return true;
}

function hasOutcome(record) {
  var outcome = String(
    getValue(record, [
      "Outcome",
      "outcome",
    ])
  ).trim();

  return outcome !== "";
}

function calculateDashboardStats(
  records
) {
  var list = Array.isArray(records)
    ? records
    : [];

  var total =
    list.length;

  var highRisk =
    list.filter(
      function (record) {
        return isHighRisk(record);
      }
    ).length;

  var outcomes =
    list.filter(
      function (record) {
        return hasOutcome(record);
      }
    ).length;

  var pending =
    list.filter(
      function (record) {
        return !hasOutcome(record);
      }
    ).length;

  return {
    total: total,
    highRisk: highRisk,
    outcomes: outcomes,
    pending: pending,
  };
}

/* =========================================================
   DATE HELPERS
   ========================================================= */

function getValidDate(
  value
) {
  if (!value) {
    return null;
  }

  var date =
    new Date(value);

  if (
    isNaN(
      date.getTime()
    )
  ) {
    return null;
  }

  return date;
}

function calculatePriorityStats(
  recordList
) {
  var list =
    Array.isArray(
      recordList
    )
      ? recordList
      : [];

  var today =
    new Date();

  today.setHours(
    0,
    0,
    0,
    0
  );

  var sevenDaysDate =
    new Date(today);

  sevenDaysDate.setDate(
    today.getDate() + 7
  );

  var thirtyDaysDate =
    new Date(today);

  thirtyDaysDate.setDate(
    today.getDate() + 30
  );

  var activeCount = 0;
  var within7 = 0;
  var within30 = 0;

  list.forEach(
    function (record) {
      var outcome =
        String(
          getValue(
            record,
            [
              "Outcome",
              "outcome",
            ]
          )
        ).trim();

      var isActive =
        outcome === "";

      if (!isActive) {
        return;
      }

      activeCount++;

      var eddValue =
        getValue(
          record,
          [
            "EDD",
            "edd",
          ]
        );

      var edd =
        getValidDate(
          eddValue
        );

      if (!edd) {
        return;
      }

      edd.setHours(
        0,
        0,
        0,
        0
      );

      if (
        edd >= today &&
        edd <= sevenDaysDate
      ) {
        within7++;
      }

      if (
        edd >= today &&
        edd <= thirtyDaysDate
      ) {
        within30++;
      }
    }
  );

  return {
    activeCount:
      activeCount,
    within7:
      within7,
    within30:
      within30,
  };
}

/* =========================================================
   DASHBOARD SCREEN
   ========================================================= */

export default function DashboardScreen({
  navigation,
}) {
  const {
    user,
    logout,
  } = useAuth();

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");

  const [
    records,
    setRecords,
  ] = useState([]);

  const [
    reportData,
    setReportData,
  ] = useState(null);

  const role =
    user &&
    user.role
      ? user.role
      : "User";

  const zone =
    user &&
    user.zone
      ? user.zone
      : "";

  const assignedHospital =
    user &&
    (
      user.assignedHospital ||
      user.assignedPHC
    )
      ? (
          user.assignedHospital ||
          user.assignedPHC
        )
      : "";

  const isSuperAdmin =
    role === "Super Admin";

  const isAdmin =
    role === "Admin" ||
    role === "Super Admin";

  /*
   * Reporting scope shown on dashboard.
   *
   * Super Admin -> All Zones
   * Admin       -> Own Zone
   * User        -> Assigned Facility
   */
  const reportingScope =
    isSuperAdmin
      ? "All Zones"
      : role === "Admin"
      ? zone ||
        "Assigned Zone"
      : assignedHospital ||
        zone ||
        "Assigned Facility";

  /* =======================================================
     LOAD DASHBOARD
     ======================================================= */

  const loadDashboard =
    useCallback(
      async function (
        showLoader
      ) {
        if (showLoader) {
          setLoading(true);
        }

        setError("");

        try {
          /*
           * IMPORTANT ACCESS LOGIC
           *
           * Super Admin -> All zones
           * Admin       -> Own zone only
           * User        -> Own zone
           *
           * The previous code used isAdmin here,
           * which incorrectly sent "All" for Admin.
           */

          var requestZone =
            isSuperAdmin
              ? "All"
              : zone;

          console.log(
            "DASHBOARD USER:",
            user &&
              user.username
          );

          console.log(
            "DASHBOARD ROLE:",
            role
          );

          console.log(
            "DASHBOARD ZONE:",
            requestZone
          );

          console.log(
            "DASHBOARD ASSIGNED FACILITY:",
            assignedHospital
          );

          /* =================================================
             ANC DATA
             ================================================= */

          var loadedRecords = [];
          var ancLoaded =
            false;

          try {
            /*
             * Pass assigned facility as the third argument
             * so User-level filtering can also be applied.
             */

            loadedRecords =
              await withTimeout(
                getANCData(
                  requestZone,
                  role,
                  assignedHospital
                ),
                12000
              );

            /*
             * Some API functions may return the records
             * directly. Others may return an object containing
             * records. Handle both cases.
             */

            if (
              Array.isArray(
                loadedRecords
              )
            ) {
              ancLoaded = true;

              setRecords(
                loadedRecords
              );
            } else if (
              loadedRecords &&
              Array.isArray(
                loadedRecords.data
              )
            ) {
              ancLoaded = true;

              setRecords(
                loadedRecords.data
              );

              loadedRecords =
                loadedRecords.data;
            } else if (
              loadedRecords &&
              Array.isArray(
                loadedRecords.records
              )
            ) {
              ancLoaded = true;

              setRecords(
                loadedRecords.records
              );

              loadedRecords =
                loadedRecords.records;
            } else {
              setRecords([]);
            }
          } catch (
            ancError
          ) {
            console.log(
              "ANC DATA ERROR:",
              ancError
            );

            setRecords([]);
          }

          /* =================================================
             REPORT DATA
             ================================================= */

          try {
            var loadedReport =
              await withTimeout(
                getReportSummary(
                  requestZone,
                  role,
                  assignedHospital
                ),
                12000
              );

            if (
              loadedReport
            ) {
              setReportData(
                loadedReport
              );
            }
          } catch (
            reportError
          ) {
            console.log(
              "REPORT DATA ERROR:",
              reportError
            );

            setReportData(
              null
            );
          }

          if (!ancLoaded) {
            throw new Error(
              "Unable to load ANC records from Google Apps Script."
            );
          }

          console.log(
            "ANC RECORD COUNT:",
            Array.isArray(
              loadedRecords
            )
              ? loadedRecords.length
              : 0
          );
        } catch (
          apiError
        ) {
          console.log(
            "DASHBOARD ERROR:",
            apiError
          );

          setError(
            apiError &&
            apiError.message
              ? apiError.message
              : "Unable to load dashboard data."
          );
        } finally {
          setLoading(false);
          setRefreshing(false);
        }
      },
      [
        isSuperAdmin,
        role,
        zone,
        assignedHospital,
        user &&
          user.username,
      ]
    );

  /* =======================================================
     REFRESH WHEN SCREEN OPENS
     ======================================================= */

  useFocusEffect(
    useCallback(
      function () {
        loadDashboard(
          true
        );
      },
      [
        loadDashboard,
      ]
    )
  );

  /* =======================================================
     REFRESH
     ======================================================= */

  function refreshDashboard() {
    setRefreshing(true);

    loadDashboard(
      false
    );
  }

  /* =======================================================
     LOGOUT
     ======================================================= */

  function handleLogout() {
    Alert.alert(
      "Logout",
      "Do you want to logout?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Logout",
          style: "destructive",
          onPress:
            logout,
        },
      ]
    );
  }

  /* =======================================================
     STATS
     ======================================================= */

  var calculated =
    calculateDashboardStats(
      records
    );

  var registeredCount =
    calculated.total;

  var highRiskCount =
    calculated.highRisk;

  var pendingCount =
    calculated.pending;

  var outcomeCount =
    calculated.outcomes;

  var priorityStats =
    calculatePriorityStats(
      records
    );

  var within7Days =
    priorityStats.within7;

  var within30Days =
    priorityStats.within30;

  var activeTrimester =
    priorityStats.activeCount;

  /* =======================================================
     LOADING
     ======================================================= */

  if (loading) {
    return (
      <View
        style={
          styles.loadingContainer
        }
      >
        <View
          style={
            styles.loadingCard
          }
        >
          <ActivityIndicator
            size="large"
            color="#2563eb"
          />

          <Text
            style={
              styles.loadingTitle
            }
          >
            Loading Dashboard
          </Text>

          <Text
            style={
              styles.loadingText
            }
          >
            Connecting to PCMC ANC records...
          </Text>
        </View>
      </View>
    );
  }

  /* =======================================================
     MAIN SCREEN
     ======================================================= */

  return (
    <View
      style={
        styles.container
      }
    >
      <ScrollView
        showsVerticalScrollIndicator={
          false
        }
        refreshControl={
          <RefreshControl
            refreshing={
              refreshing
            }
            onRefresh={
              refreshDashboard
            }
          />
        }
        contentContainerStyle={
          styles.content
        }
      >
        {/* =================================================
            HEADER
            ================================================= */}

        <View
          style={
            styles.header
          }
        >
          <View
            style={
              styles.headerInner
            }
          >
            <View
              style={
                styles.headerTop
              }
            >
              <View
                style={
                  styles.headerText
                }
              >
                <Text
                  style={
                    styles.welcomeText
                  }
                >
                  High Risk ANC
                </Text>

                <Text
                  style={
                    styles.headerTitle
                  }
                >
                  Dashboard
                </Text>

                <Text
                  style={
                    styles.headerSubtitle
                  }
                >
                  PCMC Health Department
                </Text>
              </View>

              <Pressable
                style={
                  styles.logoutButton
                }
                onPress={
                  handleLogout
                }
              >
                <Text
                  style={
                    styles.logoutText
                  }
                >
                  Logout
                </Text>
              </Pressable>
            </View>

            {/* USER BANNER */}

            <View
              style={
                styles.userBanner
              }
            >
              <View
                style={
                  styles.userAvatar
                }
              >
                <Text
                  style={
                    styles.avatarText
                  }
                >
                  {String(
                    (
                      user &&
                      user.username
                    ) ||
                      "U"
                  )
                    .charAt(0)
                    .toUpperCase()}
                </Text>
              </View>

              <View
                style={
                  styles.userInfo
                }
              >
                <Text
                  style={
                    styles.username
                  }
                >
                  {
                    (
                      user &&
                      user.username
                    ) ||
                    "User"
                  }
                </Text>

                <Text
                  style={
                    styles.userRole
                  }
                >
                  {role} •{" "}
                  {
                    reportingScope
                  }
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* =================================================
            ERROR
            ================================================= */}

        {error ? (
          <View
            style={
              styles.errorCard
            }
          >
            <Text
              style={
                styles.errorIcon
              }
            >
              !
            </Text>

            <View
              style={
                styles.errorContent
              }
            >
              <Text
                style={
                  styles.errorTitle
                }
              >
                Dashboard data warning
              </Text>

              <Text
                style={
                  styles.errorMessage
                }
              >
                {error}
              </Text>

              <Pressable
                onPress={
                  function () {
                    loadDashboard(
                      true
                    );
                  }
                }
              >
                <Text
                  style={
                    styles.retryText
                  }
                >
                  Retry
                </Text>
              </Pressable>
            </View>
          </View>
        ) : null}

        {/* =================================================
            PAGE CONTENT
            ================================================= */}

        <View
          style={
            styles.pageContent
          }
        >
          {/* LIVE BANNER */}

          <View
            style={
              styles.liveBanner
            }
          >
            <View
              style={
                styles.liveDot
              }
            />

            <Text
              style={
                styles.liveText
              }
            >
              Live ANC data •{" "}
              {registeredCount} records loaded
            </Text>
          </View>

          {/* =================================================
              SUMMARY
              ================================================= */}

          <View
            style={
              styles.summaryGrid
            }
          >
            <SummaryCard
              icon="👩"
              title="Registered ANC"
              value={
                registeredCount
              }
              subtitle="Total ANC records"
            />

            <SummaryCard
              icon="⚠"
              title="High Risk"
              value={
                highRiskCount
              }
              subtitle="High-risk cases"
            />

            <SummaryCard
              icon="📅"
              title="Pending"
              value={
                pendingCount
              }
              subtitle="No outcome recorded"
            />

            <SummaryCard
              icon="✓"
              title="Outcomes"
              value={
                outcomeCount
              }
              subtitle="Completed outcomes"
            />
          </View>

          {/* =================================================
              PRIORITY MONITOR
              ================================================= */}

          <View
            style={
              styles.priorityCard
            }
          >
            <View
              style={
                styles.priorityHeader
              }
            >
              <View
                style={
                  styles.priorityHeaderText
                }
              >
                <Text
                  style={
                    styles.priorityTitle
                  }
                >
                  Priority Monitor
                </Text>

                <Text
                  style={
                    styles.prioritySubtitle
                  }
                >
                  Upcoming ANC milestones
                </Text>
              </View>

              <View
                style={
                  styles.priorityIconBox
                }
              >
                <Text
                  style={
                    styles.priorityIcon
                  }
                >
                  📌
                </Text>
              </View>
            </View>

            <View
              style={
                styles.priorityRow
              }
            >
              <View
                style={
                  styles.priorityItem
                }
              >
                <View
                  style={
                    styles.priorityNumberBox
                  }
                >
                  <Text
                    style={
                      styles.priorityNumber
                    }
                  >
                    {within7Days}
                  </Text>
                </View>

                <Text
                  style={
                    styles.priorityLabel
                  }
                >
                  EDD within 7 days
                </Text>
              </View>

              <View
                style={
                  styles.priorityDivider
                }
              />

              <View
                style={
                  styles.priorityItem
                }
              >
                <View
                  style={
                    styles.priorityNumberBox
                  }
                >
                  <Text
                    style={
                      styles.priorityNumber
                    }
                  >
                    {within30Days}
                  </Text>
                </View>

                <Text
                  style={
                    styles.priorityLabel
                  }
                >
                  EDD within 30 days
                </Text>
              </View>

              <View
                style={
                  styles.priorityDivider
                }
              />

              <View
                style={
                  styles.priorityItem
                }
              >
                <View
                  style={
                    styles.priorityNumberBox
                  }
                >
                  <Text
                    style={
                      styles.priorityNumber
                    }
                  >
                    {activeTrimester}
                  </Text>
                </View>

                <Text
                  style={
                    styles.priorityLabel
                  }
                >
                  Active ANC
                </Text>
              </View>
            </View>
          </View>

          {/* =================================================
              QUICK ACTIONS
              ================================================= */}

          <Text
            style={
              styles.sectionHeading
            }
          >
            Quick Actions
          </Text>

          <ModuleCard
            icon="➕"
            title="ANC Registration"
            subtitle="Register a new high-risk ANC patient"
            onPress={
              function () {
                navigation.navigate(
                  "Registration"
                );
              }
            }
          />

          <ModuleCard
            icon="📞"
            title="ANC Follow-up"
            subtitle="Record patient calls, visits and outcomes"
            onPress={
              function () {
                navigation.navigate(
                  "Followup"
                );
              }
            }
          />

          <ModuleCard
            icon="✏"
            title="Update ANC Record"
            subtitle="Search and update an existing registration"
            onPress={
              function () {
                navigation.navigate(
                  "UpdateANC"
                );
              }
            }
          />

          {/* ADMIN MODULES */}

          {isAdmin ? (
            <>
              <ModuleCard
                icon="⚙"
                title="Master Management"
                subtitle="Manage zones, hospitals, staff and ASHA"
                onPress={
                  function () {
                    navigation.navigate(
                      "MasterManagement"
                    );
                  }
                }
              />

              <ModuleCard
                icon="📊"
                title="Reports"
                subtitle="View the 14 ANC management reports"
                onPress={
                  function () {
                    navigation.navigate(
                      "Reports"
                    );
                  }
                }
              />
            </>
          ) : (
            <ModuleCard
              icon="🏥"
              title="Facility & Staff"
              subtitle="View and update your assigned facility details"
              onPress={
                function () {
                  navigation.navigate(
                    "FacilityStaff"
                  );
                }
              }
            />
          )}

          {/* =================================================
              FOOTER
              ================================================= */}

          <View
            style={
              styles.bottomNote
            }
          >
            <Text
              style={
                styles.bottomNoteText
              }
            >
              Pull down to refresh the dashboard.
            </Text>

            <Text
              style={
                styles.versionText
              }
            >
              High Risk ANC Tracking System • PCMC
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

/* =========================================================
   STYLES
   ========================================================= */

const styles =
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor:
        "#f0f4f8",
    },

    content: {
      paddingBottom: 40,
      alignItems:
        "center",
    },

    pageContent: {
      width: "100%",
      maxWidth: 700,
      paddingHorizontal: 15,
      alignSelf:
        "center",
    },

    /* =====================================================
       LOADING
       ===================================================== */

    loadingContainer: {
      flex: 1,
      backgroundColor:
        "#f0f4f8",
      justifyContent:
        "center",
      alignItems:
        "center",
      padding: 24,
    },

    loadingCard: {
      width: "100%",
      maxWidth: 430,
      backgroundColor:
        "#ffffff",
      borderRadius: 24,
      padding: 32,
      alignItems:
        "center",
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    loadingTitle: {
      marginTop: 18,
      color: "#1e293b",
      fontSize: 20,
      fontWeight: "800",
    },

    loadingText: {
      marginTop: 8,
      color: "#64748b",
      fontSize: 13,
      textAlign:
        "center",
    },

    /* =====================================================
       HEADER
       ===================================================== */

    header: {
      width: "100%",
      maxWidth: 900,
      backgroundColor:
        "#1a365d",
      paddingTop:
        Platform.OS ===
        "android"
          ? 36
          : 24,
      paddingHorizontal: 18,
      paddingBottom: 22,
      borderBottomLeftRadius:
        28,
      borderBottomRightRadius:
        28,
    },

    headerInner: {
      width: "100%",
      maxWidth: 700,
      alignSelf:
        "center",
    },

    headerTop: {
      flexDirection:
        "row",
      alignItems:
        "flex-start",
    },

    headerText: {
      flex: 1,
    },

    welcomeText: {
      color: "#bfdbfe",
      fontSize: 11,
      fontWeight: "700",
      letterSpacing: 0.6,
      textTransform:
        "uppercase",
    },

    headerTitle: {
      color: "#ffffff",
      fontSize: 28,
      fontWeight: "900",
      marginTop: 2,
    },

    headerSubtitle: {
      color: "#dbeafe",
      fontSize: 12,
      marginTop: 4,
    },

    logoutButton: {
      backgroundColor:
        "rgba(255,255,255,0.12)",
      borderRadius: 12,
      paddingVertical: 9,
      paddingHorizontal: 12,
    },

    logoutText: {
      color: "#ffffff",
      fontSize: 11,
      fontWeight: "800",
    },

    /* =====================================================
       USER
       ===================================================== */

    userBanner: {
      marginTop: 18,
      borderRadius: 17,
      backgroundColor:
        "rgba(255,255,255,0.10)",
      padding: 12,
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    userAvatar: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor:
        "#2563eb",
      justifyContent:
        "center",
      alignItems:
        "center",
    },

    avatarText: {
      color: "#ffffff",
      fontSize: 17,
      fontWeight: "900",
    },

    userInfo: {
      marginLeft: 11,
      flex: 1,
      minWidth: 0,
    },

    username: {
      color: "#ffffff",
      fontSize: 14,
      fontWeight: "800",
    },

    userRole: {
      color: "#dbeafe",
      fontSize: 11,
      marginTop: 3,
    },

    /* =====================================================
       LIVE
       ===================================================== */

    liveBanner: {
      width: "100%",
      paddingVertical: 10,
      paddingHorizontal: 12,
      backgroundColor:
        "#ecfdf5",
      borderRadius: 12,
      borderWidth: 1,
      borderColor:
        "#bbf7d0",
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    liveDot: {
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor:
        "#16a34a",
      marginRight: 8,
    },

    liveText: {
      flex: 1,
      color: "#166534",
      fontSize: 11,
      fontWeight: "700",
    },

    /* =====================================================
       ERROR
       ===================================================== */

    errorCard: {
      width: "100%",
      maxWidth: 700,
      paddingHorizontal: 15,
      marginTop: 14,
    },

    errorContent: {
      backgroundColor:
        "#fff7ed",
      borderWidth: 1,
      borderColor:
        "#fed7aa",
      borderRadius: 16,
      padding: 13,
      flexDirection:
        "row",
    },

    errorIcon: {
      width: 32,
      height: 32,
      borderRadius: 16,
      backgroundColor:
        "#f97316",
      color: "#ffffff",
      textAlign:
        "center",
      lineHeight: 32,
      fontSize: 18,
      fontWeight: "900",
    },

    errorTitle: {
      color: "#9a3412",
      fontSize: 13,
      fontWeight: "800",
    },

    errorMessage: {
      color: "#7c2d12",
      fontSize: 11,
      lineHeight: 17,
      marginTop: 3,
    },

    retryText: {
      color: "#c2410c",
      fontSize: 12,
      fontWeight: "900",
      marginTop: 6,
    },

    /* =====================================================
       SUMMARY
       ===================================================== */

    summaryGrid: {
      width: "100%",
      paddingTop: 15,
      flexDirection:
        "row",
      flexWrap:
        "wrap",
      justifyContent:
        "space-between",
    },

    summaryCard: {
      width: "48.2%",
      backgroundColor:
        "#ffffff",
      borderRadius: 18,
      padding: 14,
      marginBottom: 11,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    summaryIcon: {
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor:
        "#eff6ff",
      justifyContent:
        "center",
      alignItems:
        "center",
    },

    summaryIconText: {
      fontSize: 17,
    },

    summaryTitle: {
      color: "#64748b",
      fontSize: 10,
      fontWeight: "700",
      marginTop: 9,
    },

    summaryValue: {
      color: "#1e293b",
      fontSize: 25,
      fontWeight: "900",
      marginTop: 2,
    },

    summarySubtitle: {
      color: "#94a3b8",
      fontSize: 9,
      marginTop: 2,
    },

    /* =====================================================
       PRIORITY MONITOR
       ===================================================== */

    priorityCard: {
      width: "100%",
      backgroundColor:
        "#ffffff",
      borderRadius: 20,
      padding: 16,
      borderWidth: 1,
      borderColor:
        "#dbe5ef",
      marginBottom: 4,
    },

    priorityHeader: {
      flexDirection:
        "row",
      alignItems:
        "center",
      justifyContent:
        "space-between",
      paddingBottom: 12,
      borderBottomWidth: 1,
      borderBottomColor:
        "#eef2f7",
    },

    priorityHeaderText: {
      flex: 1,
      minWidth: 0,
    },

    priorityTitle: {
      color: "#1e293b",
      fontSize: 17,
      fontWeight: "900",
    },

    prioritySubtitle: {
      marginTop: 3,
      color: "#64748b",
      fontSize: 10,
      lineHeight: 15,
    },

    priorityIconBox: {
      width: 42,
      height: 42,
      borderRadius: 14,
      backgroundColor:
        "#eff6ff",
      alignItems:
        "center",
      justifyContent:
        "center",
      marginLeft: 10,
    },

    priorityIcon: {
      fontSize: 20,
    },

    priorityRow: {
      width: "100%",
      marginTop: 14,
      flexDirection:
        "row",
      alignItems:
        "stretch",
      minHeight: 96,
    },

    priorityItem: {
      flex: 1,
      alignItems:
        "center",
      justifyContent:
        "center",
      paddingHorizontal: 5,
    },

    priorityNumberBox: {
      minWidth: 54,
      minHeight: 50,
      paddingHorizontal: 10,
      borderRadius: 14,
      backgroundColor:
        "#eff6ff",
      alignItems:
        "center",
      justifyContent:
        "center",
    },

    priorityNumber: {
      color: "#2563eb",
      fontSize: 24,
      fontWeight: "900",
      textAlign:
        "center",
    },

    priorityLabel: {
      marginTop: 8,
      color: "#475569",
      fontSize: 10,
      lineHeight: 14,
      fontWeight: "700",
      textAlign:
        "center",
      maxWidth: 95,
    },

    priorityDivider: {
      width: 1,
      alignSelf:
        "center",
      height: 58,
      backgroundColor:
        "#e2e8f0",
    },

    /* =====================================================
       QUICK ACTIONS
       ===================================================== */

    sectionHeading: {
      width: "100%",
      marginTop: 20,
      marginBottom: 9,
      color: "#1e293b",
      fontSize: 18,
      fontWeight: "900",
    },

    moduleCard: {
      width: "100%",
      marginBottom: 10,
      minHeight: 72,
      backgroundColor:
        "#ffffff",
      borderRadius: 17,
      padding: 12,
      flexDirection:
        "row",
      alignItems:
        "center",
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    moduleIcon: {
      width: 46,
      height: 46,
      borderRadius: 15,
      backgroundColor:
        "#eff6ff",
      justifyContent:
        "center",
      alignItems:
        "center",
    },

    moduleIconText: {
      fontSize: 21,
    },

    moduleText: {
      flex: 1,
      marginLeft: 12,
      minWidth: 0,
    },

    moduleTitle: {
      color: "#1e293b",
      fontSize: 14,
      fontWeight: "800",
    },

    moduleSubtitle: {
      color: "#64748b",
      fontSize: 10,
      lineHeight: 15,
      marginTop: 3,
    },

    moduleArrow: {
      color: "#94a3b8",
      fontSize: 28,
      marginLeft: 6,
    },

    /* =====================================================
       FOOTER
       ===================================================== */

    bottomNote: {
      width: "100%",
      marginTop: 13,
      alignItems:
        "center",
      paddingBottom: 5,
    },

    bottomNoteText: {
      color: "#94a3b8",
      fontSize: 10,
      textAlign:
        "center",
    },

    versionText: {
      marginTop: 5,
      color: "#cbd5e1",
      fontSize: 9,
      textAlign:
        "center",
    },
  });
