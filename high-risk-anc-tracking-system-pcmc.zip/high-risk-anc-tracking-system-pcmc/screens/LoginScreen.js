// screens/LoginScreen.js

import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
  StatusBar,
} from "react-native";

import { MaterialCommunityIcons } from "@expo/vector-icons";

import { useAuth } from "../App";

import { authenticateUser } from "../api/api";

import { COLORS, APP_INFO } from "../constants/theme";


export default function LoginScreen({ navigation }) {

  const { login } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);


  /* =====================================================
     CLEAR ERROR
     ===================================================== */

  useEffect(() => {

    if (!errorMessage) {
      return undefined;
    }

    const timer = setTimeout(() => {
      setErrorMessage("");
    }, 4000);

    return () => clearTimeout(timer);

  }, [errorMessage]);


  /* =====================================================
     LOGIN
     ===================================================== */

  const handleLogin = async () => {

    const cleanUsername = String(username || "").trim();
    const cleanPassword = String(password || "");

    if (!cleanUsername) {
      setErrorMessage("Please enter Username.");
      return;
    }

    if (!cleanPassword) {
      setErrorMessage("Please enter Password.");
      return;
    }

    setLoading(true);
    setErrorMessage("");

    try {

      const response = await authenticateUser(
        cleanUsername,
        cleanPassword
      );

      const result = response && response.data;

      if (
        !result ||
        !result.success ||
        !result.user
      ) {

        setErrorMessage(
          (result && result.message) ||
          (response && response.message) ||
          "Invalid username or password."
        );

        return;
      }

      const user = result.user;

      await login(user);

      navigation.replace("Dashboard");

    } catch (error) {

      console.log("LOGIN ERROR:", error);

      setErrorMessage(
        (error && error.message) ||
        "Unable to login. Please check your internet connection."
      );

    } finally {

      setLoading(false);

    }
  };


  /* =====================================================
     FORGOT PASSWORD
     ===================================================== */

  const openForgotPassword = () => {
    navigation.navigate("ForgotPassword");
  };


  /* =====================================================
     SCREEN
     ===================================================== */

  return (
    <SafeAreaView style={styles.container}>

      <StatusBar
        barStyle="light-content"
        backgroundColor={COLORS.secondary}
      />

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={
          Platform.OS === "ios"
            ? "padding"
            : undefined
        }
      >

        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >

          {/* =================================================
              BRAND AREA
              ================================================= */}

          <View style={styles.brandSection}>

            <View style={styles.logoCircle}>

              <Image
                source={require("../assets/pcmc-logo.png")}
                style={styles.logoImage}
                resizeMode="contain"
              />

            </View>


            <Text style={styles.title}>
              {APP_INFO.title}
            </Text>


            <View style={styles.onlineBadge}>

              <View style={styles.onlineDot} />

              <Text style={styles.onlineText}>
                Online System
              </Text>

            </View>

          </View>


          {/* =================================================
              LOGIN CARD
              ================================================= */}

          <View style={styles.card}>

            {/* CARD ICON */}

            <View style={styles.cardIcon}>

              <MaterialCommunityIcons
                name="shield-account"
                size={30}
                color={COLORS.primary}
              />

            </View>


            {/* LOGIN TITLE */}

            <Text style={styles.cardTitle}>
              System Login
            </Text>


            <Text style={styles.cardSubtitle}>
              Login using your registered credentials
            </Text>


            {/* =================================================
                ERROR MESSAGE
                ================================================= */}

            {errorMessage ? (

              <View style={styles.errorBox}>

                <MaterialCommunityIcons
                  name="alert-circle"
                  size={20}
                  color={COLORS.danger}
                />

                <Text style={styles.errorText}>
                  {errorMessage}
                </Text>

              </View>

            ) : null}


            {/* =================================================
                USERNAME
                ================================================= */}

            <Text style={styles.label}>
              Username
            </Text>


            <View style={styles.inputWrapper}>

              <MaterialCommunityIcons
                name="account-outline"
                size={21}
                color="#64748b"
                style={styles.inputIcon}
              />

              <TextInput
                style={styles.input}
                placeholder="Enter Username"
                placeholderTextColor="#94a3b8"
                autoCapitalize="none"
                autoCorrect={false}
                value={username}
                onChangeText={setUsername}
                editable={!loading}
                returnKeyType="next"
              />

            </View>


            {/* =================================================
                PASSWORD
                ================================================= */}

            <Text style={styles.label}>
              Password
            </Text>


            <View style={styles.inputWrapper}>

              <MaterialCommunityIcons
                name="lock-outline"
                size={21}
                color="#64748b"
                style={styles.inputIcon}
              />


              <TextInput
                style={styles.inputPassword}
                placeholder="Enter Password"
                placeholderTextColor="#94a3b8"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
                editable={!loading}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />


              <TouchableOpacity
                style={styles.eyeButton}
                onPress={() => {
                  setShowPassword(!showPassword);
                }}
                disabled={loading}
              >

                <MaterialCommunityIcons
                  name={
                    showPassword
                      ? "eye-off-outline"
                      : "eye-outline"
                  }
                  size={21}
                  color="#64748b"
                />

              </TouchableOpacity>

            </View>


            {/* =================================================
                LOGIN BUTTON
                ================================================= */}

            <TouchableOpacity
              activeOpacity={0.85}
              style={[
                styles.loginButton,
                loading
                  ? styles.loginButtonDisabled
                  : null,
              ]}
              onPress={handleLogin}
              disabled={loading}
            >

              {loading ? (

                <ActivityIndicator
                  size="small"
                  color="#ffffff"
                />

              ) : (

                <>

                  <MaterialCommunityIcons
                    name="login"
                    size={21}
                    color="#ffffff"
                  />

                  <Text style={styles.loginButtonText}>
                    Login
                  </Text>

                </>

              )}

            </TouchableOpacity>


            {/* =================================================
                FORGOT PASSWORD
                ================================================= */}

            <TouchableOpacity
              style={styles.forgotButton}
              onPress={openForgotPassword}
              disabled={loading}
            >

              <MaterialCommunityIcons
                name="key-outline"
                size={18}
                color={COLORS.primary}
              />

              <Text style={styles.forgotText}>
                Forgot / Reset Password?
              </Text>

            </TouchableOpacity>

          </View>


          {/* =================================================
              FOOTER
              ================================================= */}

          <View style={styles.footer}>

            <Text style={styles.footerText}>
              Pimpri Chinchwad Municipal Corporation
            </Text>

            <Text style={styles.footerSubText}>
              Health Department
            </Text>

            <Text style={styles.versionText}>
              Version {APP_INFO.version}
            </Text>

          </View>


        </ScrollView>

      </KeyboardAvoidingView>

    </SafeAreaView>
  );
}


/* =========================================================
   STYLES
   ========================================================= */

const styles = StyleSheet.create({

  /* =====================================================
     GENERAL
     ===================================================== */

  flex: {
    flex: 1,
  },

  container: {
    flex: 1,
    backgroundColor: COLORS.secondary,
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 28,
  },


  /* =====================================================
     BRAND
     ===================================================== */

  brandSection: {
  width: "100%",
  alignItems: "center",
  marginBottom: 24,
},

  logoCircle: {
    width: 82,
    height: 82,
    borderRadius: 41,

    backgroundColor: "rgba(255,255,255,0.14)",

    borderWidth: 1,

    borderColor: "rgba(255,255,255,0.28)",

    justifyContent: "center",

    alignItems: "center",

    marginBottom: 14,
  },

  logoImage: {
    width: 68,
    height: 68,
  },

  title: {
    fontSize: 25,
    fontWeight: "800",
    color: "#ffffff",
    textAlign: "center",
  },

  onlineBadge: {
    flexDirection: "row",
    alignItems: "center",

    marginTop: 12,

    backgroundColor: "rgba(255,255,255,0.12)",

    borderRadius: 20,

    paddingHorizontal: 12,

    paddingVertical: 6,
  },

  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,

    backgroundColor: "#4ade80",

    marginRight: 7,
  },

  onlineText: {
    color: "#e2e8f0",
    fontSize: 12,
    fontWeight: "700",
  },


  /* =====================================================
     LOGIN CARD
     ===================================================== */

  card: {
  width: "100%",
  maxWidth: 430,
  alignSelf: "center",

  backgroundColor: "#ffffff",

  borderRadius: 18,

  padding: 22,

  borderTopWidth: 5,

  borderTopColor: COLORS.primary,

  shadowColor: "#000",

  shadowOffset: {
    width: 0,
    height: 5,
  },

  shadowOpacity: 0.14,

  shadowRadius: 12,

  elevation: 8,
},

  cardIcon: {
    width: 56,
    height: 56,

    borderRadius: 28,

    backgroundColor: "#eff6ff",

    alignSelf: "center",

    justifyContent: "center",

    alignItems: "center",

    marginBottom: 10,
  },

  cardTitle: {
    fontSize: 21,

    fontWeight: "800",

    color: COLORS.textDark,

    textAlign: "center",
  },

  cardSubtitle: {
    fontSize: 13,

    color: "#64748b",

    textAlign: "center",

    marginTop: 5,

    marginBottom: 8,
  },


  /* =====================================================
     ERROR
     ===================================================== */

  errorBox: {
    flexDirection: "row",

    alignItems: "flex-start",

    backgroundColor: "#fef2f2",

    borderWidth: 1,

    borderColor: "#fecaca",

    borderRadius: 10,

    padding: 12,

    marginTop: 12,
  },

  errorText: {
    flex: 1,

    marginLeft: 8,

    color: COLORS.danger,

    fontSize: 13,

    fontWeight: "600",

    lineHeight: 19,
  },


  /* =====================================================
     FORM
     ===================================================== */

  label: {
    fontSize: 14,

    fontWeight: "700",

    color: COLORS.textLight,

    marginTop: 16,

    marginBottom: 7,
  },

  inputWrapper: {
    flexDirection: "row",

    alignItems: "center",

    borderWidth: 1,

    borderColor: COLORS.border,

    borderRadius: 10,

    backgroundColor: "#f8fafc",

    minHeight: 52,
  },

  inputIcon: {
    marginLeft: 13,
  },

  input: {
    flex: 1,

    fontSize: 15,

    color: COLORS.textDark,

    paddingHorizontal: 11,

    paddingVertical: 12,
  },

  inputPassword: {
    flex: 1,

    fontSize: 15,

    color: COLORS.textDark,

    paddingLeft: 11,

    paddingRight: 4,

    paddingVertical: 12,
  },

  eyeButton: {
    padding: 12,
  },


  /* =====================================================
     LOGIN BUTTON
     ===================================================== */

  loginButton: {
    marginTop: 24,

    minHeight: 54,

    borderRadius: 10,

    backgroundColor: COLORS.primary,

    flexDirection: "row",

    justifyContent: "center",

    alignItems: "center",

    shadowColor: COLORS.primary,

    shadowOffset: {
      width: 0,
      height: 4,
    },

    shadowOpacity: 0.22,

    shadowRadius: 7,

    elevation: 4,
  },

  loginButtonDisabled: {
    opacity: 0.65,
  },

  loginButtonText: {
    color: "#ffffff",

    fontSize: 16,

    fontWeight: "800",

    marginLeft: 8,
  },


  /* =====================================================
     FORGOT PASSWORD
     ===================================================== */

  forgotButton: {
    flexDirection: "row",

    justifyContent: "center",

    alignItems: "center",

    paddingVertical: 16,
  },

  forgotText: {
    color: COLORS.primary,

    fontSize: 14,

    fontWeight: "700",

    marginLeft: 6,
  },


  /* =====================================================
     FOOTER
     ===================================================== */

  footer: {
    alignItems: "center",

    paddingTop: 24,

    paddingBottom: 6,
  },

  footerText: {
    color: "#dbeafe",

    textAlign: "center",

    fontSize: 12,

    fontWeight: "600",
  },

  footerSubText: {
    color: "#bfdbfe",

    textAlign: "center",

    fontSize: 12,

    marginTop: 3,
  },

  versionText: {
    color: "#94a3b8",

    textAlign: "center",

    fontSize: 10,

    marginTop: 8,
  },

});