// screens/FollowupScreen.js

import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import DateTimePicker from "@react-native-community/datetimepicker";

import {
  useFocusEffect,
} from "@react-navigation/native";

import {
  getANCData,
  recordFollowupLog,
  updatePregnancyOutcome,
} from "../api/api";

import {
  useAuth,
} from "../App";


/* =========================================================
   FOLLOW-UP CONSTANTS
   ========================================================= */

const FOLLOWUP_MODES = [
  "Call",
  "Physical Visit",
];


const OUTCOMES = [
  "Abortion",
  "Delivery",
  "Still Birth or Intrauterine Death (IUD)",
];


const OUTCOME_PLACES = [
  "Govt Hospital",
  "Private Hospital",
];


/* =========================================================
   FREQUENCY PRIORITY
   ========================================================= */

const FREQUENCY_PRIORITY = {
  "daily": 1,
  "weekly": 2,
  "fortnightly": 3,
  "monthly": 4,
  "not needed": 5,
};


/* =========================================================
   DATE HELPERS
   ========================================================= */

function formatDisplayDate(value) {

  if (!value) {
    return "";
  }


  const date =
    new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return String(value);
  }


  const day =
    String(
      date.getDate()
    ).padStart(2, "0");


  const month =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");


  const year =
    date.getFullYear();


  return (
    day +
    "/" +
    month +
    "/" +
    year
  );
}


function toInputDate(value) {

  if (!value) {
    return new Date();
  }


  const date =
    new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return new Date();
  }


  return date;
}


/* =========================================================
   TEXT / VALUE HELPERS
   ========================================================= */

function normalizeText(value) {

  return String(
    value || ""
  )
    .trim()
    .toLowerCase();
}


function getRecordValue(
  record,
  keys
) {

  for (
    const key of keys
  ) {

    if (
      record &&
      record[key] !==
        undefined &&
      record[key] !==
        null &&
      String(
        record[key]
      ).trim() !== ""
    ) {

      return record[key];

    }

  }

  return "";
}


/* =========================================================
   FREQUENCY HELPERS
   ========================================================= */

function getFrequencyPriority(
  value
) {

  const normalized =
    normalizeText(
      value
    );


  return (
    FREQUENCY_PRIORITY[
      normalized
    ] || 99
  );
}


function getFrequencyLabel(
  value
) {

  const normalized =
    normalizeText(
      value
    );


  if (
    normalized ===
    "daily"
  ) {
    return "DAILY";
  }


  if (
    normalized ===
    "weekly"
  ) {
    return "WEEKLY";
  }


  if (
    normalized ===
    "fortnightly"
  ) {
    return "FORTNIGHTLY";
  }


  if (
    normalized ===
    "monthly"
  ) {
    return "MONTHLY";
  }


  if (
    normalized ===
    "not needed"
  ) {
    return "NOT NEEDED";
  }


  return (
    String(value || "UNKNOWN")
      .trim()
      .toUpperCase()
  );
}


function getEddTimestamp(
  record
) {

  const edd =
    getRecordValue(
      record,
      [
        "EDD",
        "edd",
      ]
    );


  if (!edd) {
    return Number.MAX_SAFE_INTEGER;
  }


  const date =
    new Date(edd);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return Number.MAX_SAFE_INTEGER;
  }


  date.setHours(
    0,
    0,
    0,
    0
  );


  return date.getTime();
}


/* =========================================================
   NORMALIZE ANC RECORD
   ========================================================= */

function normalizeRecord(
  record
) {

  return {
    ...record,

    sr:
      getRecordValue(
        record,
        [
          "SR",
          "sr",
          "Sr",
        ]
      ),

    patientName:
      getRecordValue(
        record,
        [
          "Patient Name",
          "patientName",
          "patient_name",
          "name",
        ]
      ),

    zone:
      getRecordValue(
        record,
        [
          "Zone",
          "zone",
        ]
      ),

    hospitalName:
      getRecordValue(
        record,
        [
          "Hospital Name",
          "hospitalName",
          "hospital",
        ]
      ),

    staffNurse:
      getRecordValue(
        record,
        [
          "Staff Nurse",
          "staffNurse",
          "staff",
        ]
      ),

    ashaName:
      getRecordValue(
        record,
        [
          "ASHA Name",
          "ashaName",
          "asha",
        ]
      ),

    contact1:
      getRecordValue(
        record,
        [
          "Contact 1",
          "contact1",
          "Mobile",
          "mobile",
          "Phone",
        ]
      ),

    contact2:
      getRecordValue(
        record,
        [
          "Contact 2",
          "contact2",
        ]
      ),

    rchNumber:
      getRecordValue(
        record,
        [
          "RCH Number",
          "rchNumber",
          "RCH",
        ]
      ),

    frequency:
      getRecordValue(
        record,
        [
          "Followup Frequency",
          "followupFrequency",
          "Frequency",
        ]
      ),

    lmp:
      getRecordValue(
        record,
        [
          "LMP",
          "lmp",
        ]
      ),

    edd:
      getRecordValue(
        record,
        [
          "EDD",
          "edd",
        ]
      ),

    highRisk:
      getRecordValue(
        record,
        [
          "High Risk",
          "highRisk",
        ]
      ),

    outcome:
      getRecordValue(
        record,
        [
          "Outcome",
          "outcome",
        ]
      ),

    outcomeDate:
      getRecordValue(
        record,
        [
          "Outcome Date",
          "outcomeDate",
        ]
      ),

    outcomePlace:
      getRecordValue(
        record,
        [
          "Outcome Place",
          "outcomePlace",
        ]
      ),

    outcomeHospital:
      getRecordValue(
        record,
        [
          "Outcome Hospital",
          "outcomeHospital",
        ]
      ),

    outcomeRemarks:
      getRecordValue(
        record,
        [
          "Outcome Remarks",
          "outcomeRemarks",
        ]
      ),
  };
}


/* =========================================================
   ACCESS FILTER
   ========================================================= */

function filterByUserAccess(
  records,
  user
) {

  const list =
    Array.isArray(records)
      ? records
      : [];


  if (!user) {
    return [];
  }


  const role =
    normalizeText(
      user.role
    );


  const zone =
    normalizeText(
      user.zone
    );


  const assignedHospital =
    normalizeText(
      user.assignedHospital
    );


  /*
    Super Admin
    → all ANC records
  */

  if (
    role ===
    "super admin"
  ) {

    return list;

  }


  /*
    Admin
    → same Zone
  */

  if (
    role ===
    "admin"
  ) {

    return list.filter(
      (
        record
      ) => {

        const recordZone =
          normalizeText(
            record.zone
          );


        return (
          recordZone ===
          zone
        );

      }
    );

  }


  /*
    User
    → assigned hospital only
  */

  if (
    role ===
    "user"
  ) {

    if (
      !assignedHospital
    ) {
      return [];
    }


    return list.filter(
      (
        record
      ) => {

        const recordHospital =
          normalizeText(
            record.hospitalName
          );


        return (
          recordHospital ===
          assignedHospital
        );

      }
    );

  }


  return [];
}


/* =========================================================
   SECTION CARD
   ========================================================= */

function SectionCard({
  title,
  subtitle,
  children,
}) {

  return (

    <View
      style={
        styles.sectionCard
      }
    >

      <Text
        style={
          styles.sectionTitle
        }
      >
        {title}
      </Text>


      {
        subtitle
          ? (
            <Text
              style={
                styles.sectionSubtitle
              }
            >
              {subtitle}
            </Text>
          )
          : null
      }


      <View
        style={
          styles.sectionContent
        }
      >
        {children}
      </View>

    </View>
  );
}


/* =========================================================
   INFO ROW
   ========================================================= */

function InfoRow({
  label,
  value,
}) {

  return (

    <View
      style={
        styles.infoRow
      }
    >

      <Text
        style={
          styles.infoLabel
        }
      >
        {label}
      </Text>


      <Text
        style={
          styles.infoValue
        }
      >
        {value || "—"}
      </Text>

    </View>
  );
}


/* =========================================================
   CHOICE BUTTON
   ========================================================= */

function ChoiceButton({
  label,
  selected,
  onPress,
}) {

  return (

    <Pressable
      onPress={
        onPress
      }
      style={[
        styles.choiceButton,
        selected &&
          styles.choiceButtonSelected,
      ]}
    >

      <View
        style={[
          styles.radioOuter,
          selected &&
            styles.radioOuterSelected,
        ]}
      >

        {
          selected
            ? (
              <View
                style={
                  styles.radioInner
                }
              />
            )
            : null
        }

      </View>


      <Text
        style={[
          styles.choiceText,
          selected &&
            styles.choiceTextSelected,
        ]}
      >
        {label}
      </Text>

    </Pressable>
  );
}


/* =========================================================
   DATE FIELD
   ========================================================= */

function DateField({
  label,
  value,
  onChange,
}) {

  const [
    open,
    setOpen,
  ] = useState(false);


  return (

    <View
      style={
        styles.fieldContainer
      }
    >

      <Text
        style={
          styles.fieldLabel
        }
      >
        {label}
      </Text>


      <Pressable
        style={
          styles.dateInput
        }
        onPress={() =>
          setOpen(true)
        }
      >

        <Text
          style={[
            styles.inputText,
            !value &&
              styles.placeholderText,
          ]}
        >
          {
            value
              ? formatDisplayDate(
                  value
                )
              : "Select date"
          }
        </Text>


        <Text
          style={
            styles.calendarIcon
          }
        >
          📅
        </Text>

      </Pressable>


      {
        open
          ? (
            <DateTimePicker
              value={
                toInputDate(
                  value
                )
              }
              mode="date"
              display={
                Platform.OS ===
                "ios"
                  ? "spinner"
                  : "default"
              }
              onChange={(
                event,
                selectedDate
              ) => {

                setOpen(
                  false
                );


                if (
                  event?.type ===
                    "dismissed" ||
                  !selectedDate
                ) {
                  return;
                }


                onChange(
                  selectedDate
                );

              }}
            />
          )
          : null
      }

    </View>
  );
}


/* =========================================================
   MAIN SCREEN
   ========================================================= */

export default function FollowupScreen({
  navigation,
}) {

  const {
    user,
  } = useAuth();


  const [
    records,
    setRecords,
  ] = useState([]);


  const [
    selectedRecord,
    setSelectedRecord,
  ] = useState(null);


  const [
    loading,
    setLoading,
  ] = useState(true);


  const [
    refreshing,
    setRefreshing,
  ] = useState(false);


  const [
    search,
    setSearch,
  ] = useState("");


  const [
    followupDate,
    setFollowupDate,
  ] = useState(
    new Date()
  );


  const [
    followupMode,
    setFollowupMode,
  ] = useState(
    "Call"
  );


  const [
    followupRemarks,
    setFollowupRemarks,
  ] = useState("");


  const [
    savingFollowup,
    setSavingFollowup,
  ] = useState(false);


  const [
    outcome,
    setOutcome,
  ] = useState("");


  const [
    outcomeDate,
    setOutcomeDate,
  ] = useState(
    new Date()
  );


  const [
    outcomePlace,
    setOutcomePlace,
  ] = useState("");


  const [
    outcomeHospital,
    setOutcomeHospital,
  ] = useState("");


  const [
    outcomeRemarks,
    setOutcomeRemarks,
  ] = useState("");


  const [
    savingOutcome,
    setSavingOutcome,
  ] = useState(false);


  const [
    error,
    setError,
  ] = useState("");


  const role =
    user?.role ||
    "User";


  const userZone =
    user?.zone ||
    "All";


  /* =======================================================
     LOAD DATA
     ======================================================= */

  const loadData =
    useCallback(
      async (
        showLoader = true
      ) => {

        if (
          showLoader
        ) {
          setLoading(
            true
          );
        }


        setError("");


        try {

          /*
            Backend request scope.
          */

          const requestZone =
            role ===
              "Super Admin"
              ? "All"
              : userZone;


          console.log(
            "FOLLOWUP USER:",
            user?.username
          );


          console.log(
            "FOLLOWUP ROLE:",
            role
          );


          console.log(
            "FOLLOWUP ZONE:",
            userZone
          );


          console.log(
            "FOLLOWUP ASSIGNED HOSPITAL:",
            user?.assignedHospital
          );


          console.log(
            "FOLLOWUP REQUEST ZONE:",
            requestZone
          );


          /*
            Get ANC records.
          */

          const data =
            await getANCData(
              requestZone,
              role
            );


          const normalized =
            Array.isArray(data)
              ? data.map(
                  normalizeRecord
                )
              : [];


          console.log(
            "FOLLOWUP TOTAL RECORDS:",
            normalized.length
          );


          /*
            Apply role-based
            frontend access control.
          */

          const accessible =
            filterByUserAccess(
              normalized,
              user
            );


          console.log(
            "FOLLOWUP ACCESSIBLE RECORDS:",
            accessible.length
          );


          /*
            Keep ONLY pending
            records.
          */

          const pending =
            accessible.filter(
              (
                record
              ) => {

                return (
                  normalizeText(
                    record.outcome
                  ) === ""
                );

              }
            );


          /*
            Sort:

            1. Daily
            2. Weekly
            3. Fortnightly
            4. Monthly
            5. Not Needed
            6. Unknown

            Same frequency:
            nearest EDD first.
          */

          pending.sort(
            (
              a,
              b
            ) => {

              const priorityA =
                getFrequencyPriority(
                  a.frequency
                );


              const priorityB =
                getFrequencyPriority(
                  b.frequency
                );


              if (
                priorityA !==
                priorityB
              ) {

                return (
                  priorityA -
                  priorityB
                );

              }


              const eddA =
                getEddTimestamp(
                  a
                );


              const eddB =
                getEddTimestamp(
                  b
                );


              return (
                eddA -
                eddB
              );

            }
          );


          setRecords(
            pending
          );


          setSelectedRecord(
            (
              current
            ) => {

              if (!current) {
                return null;
              }


              const currentSr =
                String(
                  current.sr ||
                  ""
                );


              const refreshed =
                pending.find(
                  (
                    item
                  ) =>
                    String(
                      item.sr ||
                      ""
                    ) ===
                    currentSr
                );


              return (
                refreshed ||
                null
              );

            }
          );

        } catch (
          apiError
        ) {

          console.log(
            "FOLLOWUP DATA ERROR:",
            apiError
          );


          setError(
            apiError?.message ||
            "Unable to load ANC follow-up data."
          );

        } finally {

          if (
            showLoader
          ) {
            setLoading(
              false
            );
          }


          setRefreshing(
            false
          );

        }

      },
      [
        role,
        userZone,
        user,
      ]
    );


  /* =======================================================
     LOAD WHEN SCREEN OPENS
     ======================================================= */

  useFocusEffect(
    useCallback(
      () => {

        loadData(
          true
        );

      },
      [
        loadData,
      ]
    )
  );


  /* =======================================================
     SELECTED RECORD EFFECT
     ======================================================= */

  useEffect(
    () => {

      if (
        !selectedRecord
      ) {
        return;
      }


      setOutcome(
        selectedRecord.outcome ||
        ""
      );


      setOutcomePlace(
        selectedRecord.outcomePlace ||
        ""
      );


      setOutcomeHospital(
        selectedRecord.outcomeHospital ||
        ""
      );


      setOutcomeRemarks(
        selectedRecord.outcomeRemarks ||
        ""
      );


      if (
        selectedRecord.outcomeDate
      ) {

        setOutcomeDate(
          toInputDate(
            selectedRecord.outcomeDate
          )
        );

      }

    },
    [
      selectedRecord,
    ]
  );


  /* =======================================================
     PENDING RECORDS
     ======================================================= */

  const pendingRecords =
    useMemo(
      () => {

        return records.filter(
          (
            record
          ) => {

            return (
              normalizeText(
                record.outcome
              ) === ""
            );

          }
        );

      },
      [
        records,
      ]
    );


  /* =======================================================
     SEARCHED RECORDS
     ======================================================= */

  const filteredRecords =
    useMemo(
      () => {

        const query =
          search
            .trim()
            .toLowerCase();


        if (!query) {
          return pendingRecords;
        }


        /*
          Search does not change
          the existing priority order.
        */

        return pendingRecords.filter(
          (
            record
          ) => {

            const searchable =
              [
                record.patientName,
                record.hospitalName,
                record.staffNurse,
                record.ashaName,
                record.contact1,
                record.contact2,
                record.rchNumber,
                record.frequency,
                record.highRisk,
                record.edd,
              ]
                .filter(
                  Boolean
                )
                .join(" ")
                .toLowerCase();


            return searchable.includes(
              query
            );

          }
        );

      },
      [
        pendingRecords,
        search,
      ]
    );


  /* =======================================================
     REFRESH
     ======================================================= */

  function handleRefresh() {

    setRefreshing(
      true
    );


    loadData(
      false
    );

  }


  /* =======================================================
     SELECT PATIENT
     ======================================================= */

  function selectPatient(
    record
  ) {

    setSelectedRecord(
      record
    );


    setFollowupRemarks(
      ""
    );


    setFollowupMode(
      "Call"
    );


    setFollowupDate(
      new Date()
    );


    setOutcome(
      record.outcome ||
      ""
    );


    setOutcomeDate(
      record.outcomeDate
        ? toInputDate(
            record.outcomeDate
          )
        : new Date()
    );


    setOutcomePlace(
      record.outcomePlace ||
      ""
    );


    setOutcomeHospital(
      record.outcomeHospital ||
      ""
    );


    setOutcomeRemarks(
      record.outcomeRemarks ||
      ""
    );

  }


  /* =======================================================
     CLEAR SELECTION
     ======================================================= */

  function clearSelection() {

    setSelectedRecord(
      null
    );


    setFollowupRemarks(
      ""
    );


    setOutcome(
      ""
    );


    setOutcomePlace(
      ""
    );


    setOutcomeHospital(
      ""
    );


    setOutcomeRemarks(
      ""
    );

  }


  /* =======================================================
     SAVE FOLLOW-UP
     ======================================================= */

  async function handleSaveFollowup() {

    if (
      !selectedRecord
    ) {

      Alert.alert(
        "Select Patient",
        "Please select an ANC patient first."
      );

      return;
    }


    const remarks =
      followupRemarks.trim();


    if (!remarks) {

      Alert.alert(
        "Remarks Required",
        "Please enter follow-up remarks."
      );

      return;
    }


    setSavingFollowup(
      true
    );


    try {

      const payload = {

        sr:
          selectedRecord.sr,

        patientName:
          selectedRecord.patientName,

        hospitalName:
          selectedRecord.hospitalName,

        staffNurse:
          selectedRecord.staffNurse,

        ashaName:
          selectedRecord.ashaName,

        contact1:
          selectedRecord.contact1,

        contact2:
          selectedRecord.contact2,

        rchNumber:
          selectedRecord.rchNumber,

        followupDate:
          followupDate.toISOString(),

        followupMode:
          followupMode,

        remarks:
          remarks,

        username:
          user?.username ||
          "",

        userRole:
          user?.role ||
          "",

        zone:
          selectedRecord.zone ||
          user?.zone ||
          "",

        assignedHospital:
          user?.assignedHospital ||
          "",

      };


      const response =
        await recordFollowupLog(
          payload
        );


      const result =
        response?.data ??
        response;


      if (
        !result ||
        result.success ===
          false
      ) {

        throw new Error(
          result?.message ||
          "Unable to save follow-up."
        );

      }


      Alert.alert(
        "Follow-up Saved",
        "Follow-up has been recorded successfully."
      );


      setFollowupRemarks(
        ""
      );


      await loadData(
        false
      );

    } catch (
      apiError
    ) {

      Alert.alert(
        "Save Failed",
        apiError?.message ||
        "Unable to save follow-up."
      );

    } finally {

      setSavingFollowup(
        false
      );

    }

  }


  /* =======================================================
     SAVE OUTCOME
     ======================================================= */

  async function handleSaveOutcome() {

    if (
      !selectedRecord
    ) {

      Alert.alert(
        "Select Patient",
        "Please select an ANC patient first."
      );

      return;
    }


    if (!outcome) {

      Alert.alert(
        "Outcome Required",
        "Please select the pregnancy outcome."
      );

      return;
    }


    if (!outcomePlace) {

      Alert.alert(
        "Place Required",
        "Please select Govt Hospital or Private Hospital."
      );

      return;
    }


    if (
      !outcomeHospital.trim()
    ) {

      Alert.alert(
        "Hospital Details Required",
        "Please enter the outcome hospital name/address."
      );

      return;
    }


    setSavingOutcome(
      true
    );


    try {

      const payload = {

        sr:
          selectedRecord.sr,

        patientName:
          selectedRecord.patientName,

        mobile:
          selectedRecord.contact1,

        outcome:
          outcome,

        outcomeDate:
          outcomeDate.toISOString(),

        outcomePlace:
          outcomePlace,

        outcomeHospital:
          outcomeHospital.trim(),

        outcomeRemarks:
          outcomeRemarks.trim(),

        username:
          user?.username ||
          "",

        userRole:
          user?.role ||
          "",

        zone:
          selectedRecord.zone ||
          user?.zone ||
          "",

        assignedHospital:
          user?.assignedHospital ||
          "",

      };


      const response =
        await updatePregnancyOutcome(
          payload
        );


      const result =
        response?.data ??
        response;


      if (
        !result ||
        result.success ===
          false
      ) {

        throw new Error(
          result?.message ||
          "Unable to update pregnancy outcome."
        );

      }


      Alert.alert(
        "Outcome Updated",
        "Pregnancy outcome has been updated successfully."
      );


      setOutcome(
        ""
      );


      setOutcomePlace(
        ""
      );


      setOutcomeHospital(
        ""
      );


      setOutcomeRemarks(
        ""
      );


      await loadData(
        false
      );


      setSelectedRecord(
        null
      );

    } catch (
      apiError
    ) {

      Alert.alert(
        "Update Failed",
        apiError?.message ||
        "Unable to update pregnancy outcome."
      );

    } finally {

      setSavingOutcome(
        false
      );

    }

  }


  /* =======================================================
     PATIENT CARD
     ======================================================= */

  const renderPatient =
    ({
      item,
    }) => {

      const isSelected =
        selectedRecord &&
        String(
          selectedRecord.sr ||
          ""
        ) ===
        String(
          item.sr ||
          ""
        );


      const frequencyLabel =
        getFrequencyLabel(
          item.frequency
        );


      return (

        <Pressable
          onPress={() =>
            selectPatient(
              item
            )
          }
          style={[
            styles.patientCard,
            isSelected &&
              styles.patientCardSelected,
          ]}
        >

          <View
            style={
              styles.patientHeader
            }
          >

            <View
              style={
                styles.patientNameWrap
              }
            >

              <Text
                style={
                  styles.patientName
                }
                numberOfLines={
                  1
                }
              >
                {
                  item.patientName ||
                  "Unnamed Patient"
                }
              </Text>


              <Text
                style={
                  styles.patientHospital
                }
              >
                {
                  item.hospitalName ||
                  "Hospital not available"
                }
              </Text>

            </View>


            <View
              style={[
                styles.frequencyBadge,
                getFrequencyPriority(
                  item.frequency
                ) === 1 &&
                  styles.frequencyDaily,
                getFrequencyPriority(
                  item.frequency
                ) === 2 &&
                  styles.frequencyWeekly,
                getFrequencyPriority(
                  item.frequency
                ) === 3 &&
                  styles.frequencyFortnightly,
                getFrequencyPriority(
                  item.frequency
                ) === 4 &&
                  styles.frequencyMonthly,
              ]}
            >

              <Text
                style={
                  styles.frequencyBadgeText
                }
              >
                {frequencyLabel}
              </Text>

            </View>

          </View>


          <View
            style={
              styles.patientMeta
            }
          >

            <Text
              style={
                styles.metaText
              }
            >
              📞{" "}
              {
                item.contact1 ||
                "No mobile"
              }
            </Text>


            <Text
              style={
                styles.metaText
              }
            >
              👩‍⚕️{" "}
              {
                item.staffNurse ||
                "No staff"
              }
            </Text>

          </View>


          <View
            style={
              styles.patientMeta
            }
          >

            <Text
              style={
                styles.metaText
              }
            >
              ASHA:{" "}
              {
                item.ashaName ||
                "—"
              }
            </Text>


            <Text
              style={
                styles.metaText
              }
            >
              EDD:{" "}
              {
                item.edd
                  ? formatDisplayDate(
                      item.edd
                    )
                  : "—"
              }
            </Text>

          </View>


          <View
            style={
              styles.patientMeta
            }
          >

            <Text
              style={
                styles.metaText
              }
            >
              RCH:{" "}
              {
                item.rchNumber ||
                "—"
              }
            </Text>


            <Text
              style={
                styles.metaText
              }
            >
              Frequency:{" "}
              {
                item.frequency ||
                "—"
              }
            </Text>

          </View>


          {
            item.highRisk
              ? (
                <View
                  style={
                    styles.riskStrip
                  }
                >

                  <Text
                    style={
                      styles.riskText
                    }
                  >
                    High Risk:{" "}
                    {item.highRisk}
                  </Text>

                </View>
              )
              : null
          }

        </Pressable>
      );
    };


  /* =======================================================
     LOADING
     ======================================================= */

  if (loading) {

    return (

      <View
        style={
          styles.loadingBox
        }
      >

        <ActivityIndicator
          size="large"
          color="#2563eb"
        />


        <Text
          style={
            styles.loadingText
          }
        >
          Loading ANC follow-up records...
        </Text>

      </View>
    );
  }


  /* =======================================================
     MAIN
     ======================================================= */

  return (

    <KeyboardAvoidingView
      style={
        styles.container
      }
      behavior={
        Platform.OS ===
        "ios"
          ? "padding"
          : undefined
      }
    >

      <View
        style={
          styles.header
        }
      >

        <View
          style={
            styles.headerTop
          }
        >

          <Pressable
            onPress={() =>
              navigation.goBack()
            }
            style={
              styles.backButton
            }
          >

            <Text
              style={
                styles.backButtonText
              }
            >
              ‹
            </Text>

          </Pressable>


          <View
            style={
              styles.headerTextWrap
            }
          >

            <Text
              style={
                styles.headerTitle
              }
            >
              ANC Follow-up
            </Text>


            <Text
              style={
                styles.headerSubtitle
              }
            >
              Daily → Weekly → Fortnightly → Monthly
            </Text>

          </View>


          <View
            style={
              styles.countBadge
            }
          >

            <Text
              style={
                styles.countNumber
              }
            >
              {
                pendingRecords.length
              }
            </Text>


            <Text
              style={
                styles.countLabel
              }
            >
              Pending
            </Text>

          </View>

        </View>


        <View
          style={
            styles.accessBanner
          }
        >

          <Text
            style={
              styles.accessBannerText
            }
          >

            {
              role ===
              "Super Admin"
                ? "Viewing all ANC facilities"
                : role ===
                  "Admin"
                ? "Viewing ANC records from your zone: " +
                  userZone
                : "Viewing ANC records from: " +
                  (
                    user?.assignedHospital ||
                    "Assigned Hospital"
                  )
            }

          </Text>

        </View>


        <View
          style={
            styles.searchBox
          }
        >

          <Text
            style={
              styles.searchIcon
            }
          >
            🔎
          </Text>


          <TextInput
            value={
              search
            }
            onChangeText={
              setSearch
            }
            placeholder="Search patient, mobile, staff, hospital..."
            placeholderTextColor="#94a3b8"
            style={
              styles.searchInput
            }
          />

        </View>

      </View>


      {
        error
          ? (
            <View
              style={
                styles.errorBanner
              }
            >

              <Text
                style={
                  styles.errorText
                }
              >
                {error}
              </Text>

            </View>
          )
          : null
      }


      {
        selectedRecord
          ? null
          : (
            <FlatList
              data={
                filteredRecords
              }

              keyExtractor={
                (
                  item,
                  index
                ) =>
                  String(
                    item.sr ||
                    item.contact1 ||
                    index
                  )
              }

              renderItem={
                renderPatient
              }

              refreshControl={
                <RefreshControl
                  refreshing={
                    refreshing
                  }
                  onRefresh={
                    handleRefresh
                  }
                />
              }

              ListHeaderComponent={
                <View
                  style={
                    styles.listHeader
                  }
                >

                  <Text
                    style={
                      styles.listTitle
                    }
                  >
                    Patients Requiring Follow-up
                  </Text>


                  <Text
                    style={
                      styles.listSubtitle
                    }
                  >
                    Follow-up priority is Daily, Weekly,
                    Fortnightly, Monthly and then Not Needed.
                    Within each group, nearest EDD appears first.
                  </Text>

                </View>
              }

              ListEmptyComponent={
                <View
                  style={
                    styles.emptyCard
                  }
                >

                  <Text
                    style={
                      styles.emptyIcon
                    }
                  >
                    ✓
                  </Text>


                  <Text
                    style={
                      styles.emptyTitle
                    }
                  >
                    No Pending Patients
                  </Text>


                  <Text
                    style={
                      styles.emptyText
                    }
                  >
                    There are currently no pending ANC
                    follow-up records for your access area.
                  </Text>

                </View>
              }

              contentContainerStyle={
                styles.listContent
              }

              showsVerticalScrollIndicator={
                false
              }
            />
          )
      }


      {
        selectedRecord
          ? (
            <ScrollView
              style={
                styles.detailScroll
              }
              contentContainerStyle={
                styles.detailContent
              }
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={
                false
              }
            >

              <View
                style={
                  styles.selectedBanner
                }
              >

                <View
                  style={
                    styles.selectedIcon
                  }
                >

                  <Text
                    style={
                      styles.selectedIconText
                    }
                  >
                    👩
                  </Text>

                </View>


                <View
                  style={
                    styles.selectedText
                  }
                >

                  <Text
                    style={
                      styles.selectedTitle
                    }
                  >
                    {
                      selectedRecord.patientName ||
                      "Patient"
                    }
                  </Text>


                  <Text
                    style={
                      styles.selectedSubtitle
                    }
                  >
                    {
                      selectedRecord.hospitalName ||
                      "Hospital"
                    }
                  </Text>

                </View>


                <Pressable
                  onPress={
                    clearSelection
                  }
                  style={
                    styles.clearButton
                  }
                >

                  <Text
                    style={
                      styles.clearButtonText
                    }
                  >
                    Back to List
                  </Text>

                </Pressable>

              </View>


              <SectionCard
                title="Patient Details"
                subtitle="Current ANC registration information"
              >

                <InfoRow
                  label="Contact 1"
                  value={
                    selectedRecord.contact1
                  }
                />


                <InfoRow
                  label="Contact 2"
                  value={
                    selectedRecord.contact2
                  }
                />


                <InfoRow
                  label="RCH Number"
                  value={
                    selectedRecord.rchNumber
                  }
                />


                <InfoRow
                  label="Staff Nurse"
                  value={
                    selectedRecord.staffNurse
                  }
                />


                <InfoRow
                  label="ASHA"
                  value={
                    selectedRecord.ashaName
                  }
                />


                <InfoRow
                  label="Follow-up Frequency"
                  value={
                    selectedRecord.frequency
                  }
                />


                <InfoRow
                  label="LMP"
                  value={
                    formatDisplayDate(
                      selectedRecord.lmp
                    )
                  }
                />


                <InfoRow
                  label="EDD"
                  value={
                    formatDisplayDate(
                      selectedRecord.edd
                    )
                  }
                />


                <InfoRow
                  label="High Risk"
                  value={
                    selectedRecord.highRisk
                  }
                />

              </SectionCard>


              <SectionCard
                title="Record Follow-up"
                subtitle="Document the current contact or visit"
              >

                <DateField
                  label="Follow-up Date"
                  value={
                    followupDate
                  }
                  onChange={
                    setFollowupDate
                  }
                />


                <Text
                  style={
                    styles.fieldLabel
                  }
                >
                  Follow-up Mode
                </Text>


                <View
                  style={
                    styles.choiceGroup
                  }
                >

                  {
                    FOLLOWUP_MODES.map(
                      (
                        mode
                      ) => (

                        <ChoiceButton
                          key={
                            mode
                          }
                          label={
                            mode
                          }
                          selected={
                            followupMode ===
                            mode
                          }
                          onPress={() =>
                            setFollowupMode(
                              mode
                            )
                          }
                        />

                      )
                    )
                  }

                </View>


                <View
                  style={
                    styles.fieldContainer
                  }
                >

                  <Text
                    style={
                      styles.fieldLabel
                    }
                  >
                    Remarks
                  </Text>


                  <TextInput
                    value={
                      followupRemarks
                    }
                    onChangeText={
                      setFollowupRemarks
                    }
                    placeholder="Enter follow-up findings, advice, referral or next action..."
                    placeholderTextColor="#94a3b8"
                    multiline
                    textAlignVertical="top"
                    style={[
                      styles.textArea,
                      {
                        minHeight: 110,
                      },
                    ]}
                  />

                </View>


                <Pressable
                  onPress={
                    handleSaveFollowup
                  }
                  disabled={
                    savingFollowup
                  }
                  style={[
                    styles.primaryButton,
                    savingFollowup &&
                      styles.disabledButton,
                  ]}
                >

                  {
                    savingFollowup
                      ? (
                        <ActivityIndicator
                          color="#ffffff"
                        />
                      )
                      : (
                        <Text
                          style={
                            styles.primaryButtonText
                          }
                        >
                          Save Follow-up
                        </Text>
                      )
                  }

                </Pressable>

              </SectionCard>


              <SectionCard
                title="Pregnancy Outcome"
                subtitle="Complete the ANC record when an outcome occurs"
              >

                <Text
                  style={
                    styles.fieldLabel
                  }
                >
                  Outcome
                </Text>


                <View
                  style={
                    styles.choiceGroup
                  }
                >

                  {
                    OUTCOMES.map(
                      (
                        item
                      ) => (

                        <ChoiceButton
                          key={
                            item
                          }
                          label={
                            item
                          }
                          selected={
                            outcome ===
                            item
                          }
                          onPress={() =>
                            setOutcome(
                              item
                            )
                          }
                        />

                      )
                    )
                  }

                </View>


                <DateField
                  label="Outcome Date"
                  value={
                    outcomeDate
                  }
                  onChange={
                    setOutcomeDate
                  }
                />


                <Text
                  style={
                    styles.fieldLabel
                  }
                >
                  Outcome Place
                </Text>


                <View
                  style={
                    styles.choiceGroup
                  }
                >

                  {
                    OUTCOME_PLACES.map(
                      (
                        item
                      ) => (

                        <ChoiceButton
                          key={
                            item
                          }
                          label={
                            item
                          }
                          selected={
                            outcomePlace ===
                            item
                          }
                          onPress={() =>
                            setOutcomePlace(
                              item
                            )
                          }
                        />

                      )
                    )
                  }

                </View>


                <View
                  style={
                    styles.fieldContainer
                  }
                >

                  <Text
                    style={
                      styles.fieldLabel
                    }
                  >
                    Hospital Name / Address
                  </Text>


                  <TextInput
                    value={
                      outcomeHospital
                    }
                    onChangeText={
                      setOutcomeHospital
                    }
                    placeholder="Enter hospital name and address"
                    placeholderTextColor="#94a3b8"
                    style={
                      styles.input
                    }
                  />

                </View>


                <View
                  style={
                    styles.fieldContainer
                  }
                >

                  <Text
                    style={
                      styles.fieldLabel
                    }
                  >
                    Outcome Remarks
                  </Text>


                  <TextInput
                    value={
                      outcomeRemarks
                    }
                    onChangeText={
                      setOutcomeRemarks
                    }
                    placeholder="Enter additional outcome details..."
                    placeholderTextColor="#94a3b8"
                    multiline
                    textAlignVertical="top"
                    style={[
                      styles.textArea,
                      {
                        minHeight: 100,
                      },
                    ]}
                  />

                </View>


                <Pressable
                  onPress={
                    handleSaveOutcome
                  }
                  disabled={
                    savingOutcome
                  }
                  style={[
                    styles.outcomeButton,
                    savingOutcome &&
                      styles.disabledButton,
                  ]}
                >

                  {
                    savingOutcome
                      ? (
                        <ActivityIndicator
                          color="#ffffff"
                        />
                      )
                      : (
                        <Text
                          style={
                            styles.primaryButtonText
                          }
                        >
                          Update Pregnancy Outcome
                        </Text>
                      )
                  }

                </Pressable>

              </SectionCard>


              <View
                style={
                  styles.bottomSpace
                }
              />

            </ScrollView>
          )
          : null
      }

    </KeyboardAvoidingView>
  );
}


/* =========================================================
   STYLES
   ========================================================= */

const styles =
  StyleSheet.create({

    container: {
      flex: 1,
      backgroundColor:
        "#f0f4f8",
    },


    /* =====================================================
       HEADER
       ===================================================== */

    header: {
      backgroundColor:
        "#1a365d",

      paddingTop:
        Platform.OS ===
        "android"
          ? 36
          : 54,

      paddingHorizontal:
        18,

      paddingBottom:
        16,

      borderBottomLeftRadius:
        24,

      borderBottomRightRadius:
        24,
    },


    headerTop: {
      flexDirection:
        "row",

      alignItems:
        "center",
    },


    backButton: {
      width: 42,

      height: 42,

      borderRadius: 21,

      backgroundColor:
        "rgba(255,255,255,0.14)",

      justifyContent:
        "center",

      alignItems:
        "center",

      marginRight:
        12,
    },


    backButtonText: {
      color:
        "#ffffff",

      fontSize: 32,

      lineHeight: 34,

      fontWeight: "300",
    },


    headerTextWrap: {
      flex: 1,

      minWidth: 0,
    },


    headerTitle: {
      color:
        "#ffffff",

      fontSize: 22,

      fontWeight: "800",
    },


    headerSubtitle: {
      color:
        "#dbeafe",

      fontSize: 11,

      marginTop: 3,

      lineHeight: 16,
    },


    countBadge: {
      backgroundColor:
        "#2563eb",

      minWidth: 64,

      paddingVertical: 8,

      paddingHorizontal: 10,

      borderRadius: 14,

      alignItems:
        "center",

      marginLeft: 8,
    },


    countNumber: {
      color:
        "#ffffff",

      fontSize: 18,

      fontWeight: "800",
    },


    countLabel: {
      color:
        "#dbeafe",

      fontSize: 10,

      fontWeight: "700",
    },


    accessBanner: {
      marginTop: 12,

      backgroundColor:
        "rgba(255,255,255,0.10)",

      borderRadius: 10,

      paddingVertical: 7,

      paddingHorizontal: 10,
    },


    accessBannerText: {
      color:
        "#dbeafe",

      fontSize: 10,

      fontWeight: "700",

      lineHeight: 15,
    },


    searchBox: {
      marginTop: 12,

      backgroundColor:
        "#ffffff",

      borderRadius: 14,

      flexDirection:
        "row",

      alignItems:
        "center",

      paddingHorizontal: 12,
    },


    searchIcon: {
      fontSize: 18,

      marginRight: 7,
    },


    searchInput: {
      flex: 1,

      minHeight: 48,

      fontSize: 14,

      color:
        "#1e293b",
    },


    /* =====================================================
       ERROR
       ===================================================== */

    errorBanner: {
      marginHorizontal: 16,

      marginTop: 12,

      padding: 12,

      borderRadius: 12,

      backgroundColor:
        "#fee2e2",

      borderWidth: 1,

      borderColor:
        "#fecaca",
    },


    errorText: {
      color:
        "#991b1b",

      fontSize: 13,

      lineHeight: 19,
    },


    /* =====================================================
       LOADING
       ===================================================== */

    loadingBox: {
      flex: 1,

      backgroundColor:
        "#f0f4f8",

      justifyContent:
        "center",

      alignItems:
        "center",

      padding: 24,
    },


    loadingText: {
      marginTop: 12,

      color:
        "#475569",

      fontSize: 14,

      textAlign:
        "center",
    },


    /* =====================================================
       LIST
       ===================================================== */

    listContent: {
      padding: 16,

      paddingBottom: 32,
    },


    listHeader: {
      marginBottom: 12,
    },


    listTitle: {
      fontSize: 18,

      fontWeight: "800",

      color:
        "#1e293b",
    },


    listSubtitle: {
      marginTop: 5,

      color:
        "#64748b",

      lineHeight: 19,

      fontSize: 13,
    },


    /* =====================================================
       PATIENT CARD
       ===================================================== */

    patientCard: {
      backgroundColor:
        "#ffffff",

      borderRadius: 18,

      padding: 15,

      marginBottom: 12,

      borderWidth: 1,

      borderColor:
        "#e2e8f0",

      elevation: 2,
    },


    patientCardSelected: {
      borderWidth: 2,

      borderColor:
        "#2563eb",
    },


    patientHeader: {
      flexDirection:
        "row",

      alignItems:
        "flex-start",
    },


    patientNameWrap: {
      flex: 1,

      paddingRight: 10,

      minWidth: 0,
    },


    patientName: {
      fontSize: 16,

      fontWeight: "800",

      color:
        "#1e293b",
    },


    patientHospital: {
      marginTop: 4,

      color:
        "#475569",

      fontSize: 12,

      lineHeight: 17,
    },


    /* =====================================================
       FREQUENCY BADGE
       ===================================================== */

    frequencyBadge: {
      minWidth: 72,

      paddingVertical: 5,

      paddingHorizontal: 7,

      borderRadius: 9,

      alignItems:
        "center",

      justifyContent:
        "center",

      backgroundColor:
        "#f1f5f9",
    },


    frequencyDaily: {
      backgroundColor:
        "#fee2e2",
    },


    frequencyWeekly: {
      backgroundColor:
        "#fef3c7",
    },


    frequencyFortnightly: {
      backgroundColor:
        "#dbeafe",
    },


    frequencyMonthly: {
      backgroundColor:
        "#dcfce7",
    },


    frequencyBadgeText: {
      color:
        "#475569",

      fontSize: 8,

      fontWeight: "900",

      textAlign:
        "center",
    },


    patientMeta: {
      marginTop: 10,

      flexDirection:
        "row",

      justifyContent:
        "space-between",

      gap: 8,
    },


    metaText: {
      flex: 1,

      color:
        "#475569",

      fontSize: 11,

      lineHeight: 17,
    },


    riskStrip: {
      marginTop: 10,

      borderRadius: 10,

      backgroundColor:
        "#fef2f2",

      paddingVertical: 7,

      paddingHorizontal: 9,
    },


    riskText: {
      color:
        "#b91c1c",

      fontSize: 11,

      fontWeight: "700",

      lineHeight: 16,
    },


    /* =====================================================
       EMPTY
       ===================================================== */

    emptyCard: {
      marginTop: 28,

      backgroundColor:
        "#ffffff",

      borderRadius: 20,

      padding: 26,

      alignItems:
        "center",

      borderWidth: 1,

      borderColor:
        "#e2e8f0",
    },


    emptyIcon: {
      width: 54,

      height: 54,

      borderRadius: 27,

      backgroundColor:
        "#dcfce7",

      color:
        "#15803d",

      fontSize: 28,

      textAlign:
        "center",

      lineHeight: 54,

      fontWeight: "800",
    },


    emptyTitle: {
      marginTop: 14,

      color:
        "#1e293b",

      fontSize: 17,

      fontWeight: "800",
    },


    emptyText: {
      marginTop: 7,

      textAlign:
        "center",

      color:
        "#64748b",

      lineHeight: 19,

      fontSize: 13,
    },


    /* =====================================================
       SELECTED PATIENT
       ===================================================== */

    detailScroll: {
      flex: 1,
    },


    detailContent: {
      padding: 16,

      paddingBottom: 40,
    },


    selectedBanner: {
      backgroundColor:
        "#1d4ed8",

      borderRadius: 18,

      padding: 14,

      flexDirection:
        "row",

      alignItems:
        "center",

      marginBottom: 12,
    },


    selectedIcon: {
      width: 44,

      height: 44,

      borderRadius: 22,

      backgroundColor:
        "rgba(255,255,255,0.16)",

      justifyContent:
        "center",

      alignItems:
        "center",
    },


    selectedIconText: {
      fontSize: 22,
    },


    selectedText: {
      flex: 1,

      marginLeft: 11,

      minWidth: 0,
    },


    selectedTitle: {
      color:
        "#ffffff",

      fontSize: 16,

      fontWeight: "800",
    },


    selectedSubtitle: {
      marginTop: 3,

      color:
        "#dbeafe",

      fontSize: 12,
    },


    clearButton: {
      paddingHorizontal: 11,

      paddingVertical: 8,

      borderRadius: 10,

      backgroundColor:
        "rgba(255,255,255,0.14)",

      marginLeft: 8,
    },


    clearButtonText: {
      color:
        "#ffffff",

      fontSize: 10,

      fontWeight: "700",
    },


    /* =====================================================
       SECTION
       ===================================================== */

    sectionCard: {
      backgroundColor:
        "#ffffff",

      borderRadius: 20,

      padding: 17,

      marginBottom: 14,

      borderWidth: 1,

      borderColor:
        "#e2e8f0",

      elevation: 2,
    },


    sectionTitle: {
      fontSize: 17,

      fontWeight: "800",

      color:
        "#1e293b",
    },


    sectionSubtitle: {
      marginTop: 4,

      color:
        "#64748b",

      fontSize: 12,

      lineHeight: 17,
    },


    sectionContent: {
      marginTop: 14,
    },


    /* =====================================================
       INFO
       ===================================================== */

    infoRow: {
      flexDirection:
        "row",

      paddingVertical: 8,

      borderBottomWidth: 1,

      borderBottomColor:
        "#f1f5f9",
    },


    infoLabel: {
      width: "40%",

      color:
        "#64748b",

      fontSize: 12,

      fontWeight: "600",
    },


    infoValue: {
      flex: 1,

      color:
        "#1e293b",

      fontSize: 12,

      fontWeight: "600",
    },


    /* =====================================================
       FORM
       ===================================================== */

    fieldContainer: {
      marginBottom: 14,
    },


    fieldLabel: {
      marginBottom: 7,

      color:
        "#334155",

      fontSize: 12,

      fontWeight: "800",
    },


    input: {
      minHeight: 48,

      borderWidth: 1,

      borderColor:
        "#cbd5e1",

      borderRadius: 12,

      paddingHorizontal: 13,

      backgroundColor:
        "#ffffff",

      color:
        "#1e293b",

      fontSize: 14,
    },


    textArea: {
      borderWidth: 1,

      borderColor:
        "#cbd5e1",

      borderRadius: 12,

      paddingHorizontal: 13,

      paddingTop: 12,

      backgroundColor:
        "#ffffff",

      color:
        "#1e293b",

      fontSize: 14,
    },


    dateInput: {
      minHeight: 48,

      borderWidth: 1,

      borderColor:
        "#cbd5e1",

      borderRadius: 12,

      paddingHorizontal: 13,

      backgroundColor:
        "#ffffff",

      flexDirection:
        "row",

      alignItems:
        "center",

      justifyContent:
        "space-between",
    },


    inputText: {
      color:
        "#1e293b",

      fontSize: 14,
    },


    placeholderText: {
      color:
        "#94a3b8",
    },


    calendarIcon: {
      fontSize: 17,
    },


    /* =====================================================
       CHOICES
       ===================================================== */

    choiceGroup: {
      marginBottom: 10,
    },


    choiceButton: {
      minHeight: 46,

      borderWidth: 1,

      borderColor:
        "#e2e8f0",

      borderRadius: 12,

      backgroundColor:
        "#f8fafc",

      flexDirection:
        "row",

      alignItems:
        "center",

      paddingHorizontal: 12,

      marginBottom: 8,
    },


    choiceButtonSelected: {
      borderColor:
        "#2563eb",

      backgroundColor:
        "#eff6ff",
    },


    radioOuter: {
      width: 20,

      height: 20,

      borderRadius: 10,

      borderWidth: 2,

      borderColor:
        "#94a3b8",

      justifyContent:
        "center",

      alignItems:
        "center",

      marginRight: 10,
    },


    radioOuterSelected: {
      borderColor:
        "#2563eb",
    },


    radioInner: {
      width: 10,

      height: 10,

      borderRadius: 5,

      backgroundColor:
        "#2563eb",
    },


    choiceText: {
      flex: 1,

      color:
        "#475569",

      fontSize: 13,

      lineHeight: 18,
    },


    choiceTextSelected: {
      color:
        "#1d4ed8",

      fontWeight: "700",
    },


    /* =====================================================
       BUTTONS
       ===================================================== */

    primaryButton: {
      minHeight: 50,

      borderRadius: 13,

      backgroundColor:
        "#2563eb",

      justifyContent:
        "center",

      alignItems:
        "center",

      marginTop: 3,
    },


    outcomeButton: {
      minHeight: 50,

      borderRadius: 13,

      backgroundColor:
        "#15803d",

      justifyContent:
        "center",

      alignItems:
        "center",

      marginTop: 3,
    },


    primaryButtonText: {
      color:
        "#ffffff",

      fontSize: 14,

      fontWeight: "800",
    },


    disabledButton: {
      opacity: 0.65,
    },


    bottomSpace: {
      height: 60,
    },

  });

