// screens/ReportsScreen.js

import React, {
  useCallback,
  useMemo,
  useState,
  useRef,
} from "react";

import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import {
  useFocusEffect,
} from "@react-navigation/native";

import {
  BarChart,
  PieChart,
} from "react-native-chart-kit";

import {
  getReportSummary,
  sendPendingFollowupEmailV2,
} from "../api/api";

import { useAuth } from "../App";

import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { captureRef } from "react-native-view-shot";

const REPORTS = [
  {
    id: "pendingFollowup",
    number: "1",
    title: "Pending Follow-up",
    subtitle: "Patients requiring follow-up",
  },
  {
    id: "staffPerformance",
    number: "2",
    title: "Staff Performance",
    subtitle: "ANC follow-up performance",
  },
  {
    id: "highRisk",
    number: "3",
    title: "High-Risk ANC",
    subtitle: "High-risk patient distribution",
  },
  {
    id: "uphcPerformance",
    number: "4",
    title: "UPHC Performance",
    subtitle: "Facility-level performance",
  },
  {
    id: "upcomingEdd",
    number: "5",
    title: "Upcoming EDD",
    subtitle: "EDD within 7 / 15 / 30 days",
  },
  {
    id: "trimester",
    number: "6",
    title: "Trimester",
    subtitle: "Active ANC by trimester",
  },
  {
    id: "registrationTrend",
    number: "7",
    title: "Registration Trend",
    subtitle: "ANC registrations by month",
  },
  {
    id: "highRiskNormal",
    number: "8",
    title: "High-Risk vs Normal",
    subtitle: "Risk comparison",
  },
  {
    id: "outcome",
    number: "9",
    title: "Outcome Distribution",
    subtitle: "Pregnancy outcomes",
  },
  {
    id: "zoneDistribution",
    number: "10",
    title: "Zone Distribution",
    subtitle: "ANC distribution by zone",
  },
  {
    id: "followupFrequency",
    number: "11",
    title: "Follow-up Frequency",
    subtitle: "Frequency distribution",
  },
  {
    id: "overdueEdd",
    number: "12",
    title: "Overdue EDD",
    subtitle: "Records with overdue EDD",
  },
  {
    id: "outcomePlace",
    number: "13",
    title: "Outcome Place",
    subtitle: "Government vs private",
  },
  {
    id: "dataQuality",
    number: "14",
    title: "Data Quality",
    subtitle: "Missing information checks",
  },
];

const CHART_WIDTH = 330;
const CHART_HEIGHT = 280;

const CHART_CONFIG = {
  backgroundColor: "#ffffff",
  backgroundGradientFrom: "#ffffff",
  backgroundGradientTo: "#ffffff",
  decimalPlaces: 0,

  color: function (opacity) {
    return "rgba(37, 99, 235, " + opacity + ")";
  },

  labelColor: function (opacity) {
    return "rgba(30, 41, 59, " + opacity + ")";
  },

  style: {
    borderRadius: 16,
  },

  propsForLabels: {
    fontSize: 9,
  },
};

const CHART_COLORS = [
  "#2563eb",
  "#16a34a",
  "#ea580c",
  "#7c3aed",
  "#0891b2",
  "#dc2626",
  "#ca8a04",
  "#0f766e",
  "#be123c",
  "#4f46e5",
  "#9333ea",
  "#0284c7",
];

function getObjectValue(
  object,
  keys,
  fallback = ""
) {
  if (!object) {
    return fallback;
  }

  for (const key of keys) {
    if (
      object[key] !== undefined &&
      object[key] !== null &&
      object[key] !== ""
    ) {
      return object[key];
    }
  }

  return fallback;
}

function asNumber(value) {
  const n = Number(value);

  return Number.isFinite(n)
    ? n
    : 0;
}

function getReportObject(
  reportData,
  keys
) {
  if (!reportData) {
    return {};
  }

  for (const key of keys) {
    if (
      reportData[key] !== undefined &&
      reportData[key] !== null
    ) {
      return reportData[key];
    }
  }

  return {};
}

function normalizeRows(value) {
  if (Array.isArray(value)) {
    return value;
  }

  if (
    value &&
    typeof value === "object"
  ) {
    const candidates = [
      value.rows,
      value.data,
      value.items,
      value.records,
      value.list,
      value.details,
    ];

    for (const candidate of candidates) {
      if (Array.isArray(candidate)) {
        return candidate;
      }
    }
  }

  return [];
}

function cleanChartLabel(
  value,
  maxLength = 16
) {
  const text =
    value === undefined ||
    value === null ||
    value === ""
      ? "Unknown"
      : String(value);

  const clean =
    text
      .replace(/\s+/g, " ")
      .trim();

  if (clean.length <= maxLength) {
    return clean;
  }

  return (
    clean.slice(
      0,
      maxLength - 1
    ) + "..."
  );
}

function SummaryCard({
  label,
  value,
  detail,
}) {
  return (
    <View style={styles.summaryCard}>
      <Text style={styles.summaryLabel}>
        {label}
      </Text>

      <Text style={styles.summaryValue}>
        {value}
      </Text>

      {detail ? (
        <Text style={styles.summaryDetail}>
          {detail}
        </Text>
      ) : null}
    </View>
  );
}

function ReportTable({
  rows,
  columns,
}) {
  if (
    !Array.isArray(rows) ||
    rows.length === 0
  ) {
    return (
      <View style={styles.noDataBox}>
        <Text style={styles.noDataText}>
          No data available for this report.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={
        false
      }
    >
      <View>
        <View style={styles.tableHeader}>
          {columns.map((column) => (
            <Text
              key={column.key}
              style={[
                styles.tableCell,
                styles.tableHeaderCell,
                {
                  width:
                    column.width ||
                    150,
                },
              ]}
            >
              {column.label}
            </Text>
          ))}
        </View>

        {rows.map((row, index) => (
          <View
            key={String(
              row?.rowIndex ??
                row?.id ??
                index
            )}
            style={styles.tableRow}
          >
            {columns.map((column) => (
              <Text
                key={column.key}
                style={[
                  styles.tableCell,
                  {
                    width:
                      column.width ||
                      150,
                  },
                ]}
              >
                {String(
                  getObjectValue(
                    row,
                    column.keys ||
                      [column.key],
                    "—"
                  )
                )}
              </Text>
            ))}
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

function SectionTitle({
  title,
  subtitle,
}) {
  return (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionHeadingTitle}>
        {title}
      </Text>

      {subtitle ? (
        <Text
          style={
            styles.sectionHeadingSubtitle
          }
        >
          {subtitle}
        </Text>
      ) : null}
    </View>
  );
}

/* =========================================================
   BAR CHART
   ========================================================= */

function SafeBarChart({
  labels,
  values,
  title,
  captureTargetRef,
}) {
  const sourceLabels =
    labels.length
      ? labels
      : ["No Data"];

  const safeValues =
    values.length
      ? values
      : [0];

  const displayLabels =
    sourceLabels.map(function (label) {
      return cleanChartLabel(
        label,
        15
      );
    });

  const barWidth =
    displayLabels.length <= 4
      ? 82
      : displayLabels.length <= 8
      ? 70
      : 60;

  const chartWidth =
    Math.max(
      CHART_WIDTH,
      displayLabels.length *
        barWidth +
        90
    );

  const chartHeight =
    displayLabels.length > 8
      ? 320
      : 285;

  const showValues =
    displayLabels.length <= 8;

  /*
   * IMPORTANT:
   * The ref is attached to this INNER VIEW,
   * not to the visible horizontal ScrollView.
   *
   * Therefore captureRef captures the full chart width.
   */

  return (
    <View style={styles.chartScrollWrap}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={true}
        style={styles.chartViewport}
      >
        <View
          ref={captureTargetRef}
          collapsable={false}
          style={[
            styles.chartCaptureContainer,
            {
              width: chartWidth,
            },
          ]}
        >
          <BarChart
            data={{
              labels:
                displayLabels,

              datasets: [
                {
                  data:
                    safeValues,
                },
              ],
            }}
            width={chartWidth}
            height={chartHeight}
            fromZero
            showValuesOnTopOfBars={
              showValues
            }
            withInnerLines
            chartConfig={
              CHART_CONFIG
            }
            style={
              styles.chart
            }
            yAxisLabel=""
            yAxisSuffix=""
            verticalLabelRotation={50}
          />
        </View>
      </ScrollView>

      {!showValues ? (
        <Text
          style={
            styles.chartHelperText
          }
        >
          Values are available in the report
          table below. Scroll horizontally to
          view all categories.
        </Text>
      ) : null}

      <Text style={styles.chartTitle}>
        {title}
      </Text>
    </View>
  );
}

/* =========================================================
   PIE CHART
   ========================================================= */

function SafePieChart({
  labels,
  values,
  title,
  captureTargetRef,
}) {
  const data =
    labels.length
      ? labels.map(
          function (label, index) {
            return {
              name:
                cleanChartLabel(
                  label,
                  24
                ),

              population:
                asNumber(
                  values[index]
                ),

              color:
                CHART_COLORS[
                  index %
                    CHART_COLORS.length
                ],
            };
          }
        )
      : [
          {
            name: "No Data",
            population: 1,
            color: "#cbd5e1",
          },
        ];

  const total =
    data.reduce(
      function (sum, item) {
        return (
          sum +
          asNumber(
            item.population
          )
        );
      },
      0
    );

  /*
   * IMPORTANT:
   * The capture ref includes:
   * 1. Pie chart
   * 2. Complete custom legend
   *
   * So the full visible chart information is captured.
   */

  return (
    <View style={styles.chartWrap}>
      <View
        ref={captureTargetRef}
        collapsable={false}
        style={
          styles.pieCaptureContainer
        }
      >
        <PieChart
          data={data}
          width={CHART_WIDTH}
          height={220}
          chartConfig={
            CHART_CONFIG
          }
          accessor="population"
          backgroundColor="transparent"
          paddingLeft="20"
          center={[
            0,
            0,
          ]}
          absolute={false}
          hasLegend={false}
        />

        <View
          style={
            styles.pieLegend
          }
        >
          {data.map(
            function (
              item,
              index
            ) {
              const percent =
                total > 0
                  ? (
                      (asNumber(
                        item.population
                      ) /
                        total) *
                      100
                    ).toFixed(1)
                  : "0.0";

              return (
                <View
                  key={
                    item.name +
                    "_" +
                    index
                  }
                  style={
                    styles.pieLegendRow
                  }
                >
                  <View
                    style={[
                      styles.pieDot,
                      {
                        backgroundColor:
                          item.color,
                      },
                    ]}
                  />

                  <Text
                    style={
                      styles.pieLegendText
                    }
                  >
                    {
                      item.name
                    }
                  </Text>

                  <Text
                    style={
                      styles.pieLegendValue
                    }
                  >
                    {
                      asNumber(
                        item.population
                      )
                    }{" "}
                    (
                    {percent}
                    %)
                  </Text>
                </View>
              );
            }
          )}
        </View>
      </View>

      <Text style={styles.chartTitle}>
        {title}
      </Text>
    </View>
  );
}

/* =========================================================
   REPORTS SCREEN
   ========================================================= */

export default function ReportsScreen({
  navigation,
}) {
  const { user } =
    useAuth();

  /*
   * This ref points to the ACTUAL chart content,
   * not the chart card or viewport.
   */
  const chartCaptureRef =
    useRef(null);

  const [
    reportData,
    setReportData,
  ] = useState(null);

  const [
    activeReport,
    setActiveReport,
  ] = useState(
    "pendingFollowup"
  );

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState("");

  const [
    emailSending,
    setEmailSending,
  ] = useState(false);

  const [
    chartDownloading,
    setChartDownloading,
  ] = useState(false);

  const role =
    user?.role || "User";

  const userZone =
    user?.zone || "";

  const assignedHospital =
    user?.assignedHospital ||
    user?.assignedPHC ||
    "";

  const isSuperAdmin =
    role === "Super Admin";

  const isAdmin =
    role === "Admin" ||
    role === "Super Admin";

  const reportingScope =
    isSuperAdmin
      ? "All Zones"
      : isAdmin
      ? userZone ||
        "Assigned Zone"
      : assignedHospital ||
        userZone ||
        "Assigned Facility";

  /* =====================================================
     LOAD REPORTS
     ===================================================== */

  const loadReports =
    useCallback(
      async (
        showLoader = true
      ) => {
        if (showLoader) {
          setLoading(true);
        }

        setError("");

        try {
          /*
           * Super Admin -> All
           * Admin -> Own Zone
           * User -> Own Zone
           */

          const requestZone =
            isSuperAdmin
              ? "All"
              : userZone;

          console.log(
            "REPORTS USER:",
            user?.username
          );

          console.log(
            "REPORTS ROLE:",
            role
          );

          console.log(
            "REPORTS ZONE:",
            requestZone
          );

          console.log(
            "REPORTS ASSIGNED FACILITY:",
            assignedHospital
          );

          const response =
            await getReportSummary(
              requestZone,
              role,
              assignedHospital
            );

          console.log(
            "REPORTS RAW RESPONSE:",
            response
          );

          const result =
            response?.data ??
            response;

          let data =
            result?.data ||
            result;

          if (
            typeof data ===
            "string"
          ) {
            try {
              data =
                JSON.parse(data);
            } catch (
              parseError
            ) {
              throw new Error(
                "Unable to parse report data from server."
              );
            }
          }

          if (
            data &&
            data.data &&
            typeof data.data ===
              "object"
          ) {
            data =
              data.data;
          }

          if (
            !data ||
            typeof data !==
              "object"
          ) {
            throw new Error(
              "No report data received from server."
            );
          }

          if (
            data.success ===
              false
          ) {
            throw new Error(
              data.message ||
                "Unable to load reports."
            );
          }

          setReportData(
            data
          );
        } catch (
          apiError
        ) {
          console.log(
            "REPORTS LOAD ERROR:",
            apiError
          );

          setError(
            apiError?.message ||
              "Unable to load reports."
          );
        } finally {
          if (showLoader) {
            setLoading(false);
          }

          setRefreshing(false);
        }
      },
      [
        isSuperAdmin,
        role,
        userZone,
        assignedHospital,
        user?.username,
      ]
    );

  useFocusEffect(
    useCallback(
      function () {
        loadReports(true);
      },
      [loadReports]
    )
  );

  function refreshReports() {
    setRefreshing(true);
    loadReports(false);
  }

  /* =====================================================
     SUMMARY
     ===================================================== */

  const summary =
    useMemo(
      function () {
        const summaryObject =
          getReportObject(
            reportData,
            [
              "summary",
            ]
          );

        const highRisk =
          getReportObject(
            reportData,
            [
              "highRiskNormal",
            ]
          );

        const upcoming =
          getReportObject(
            reportData,
            [
              "upcomingEddReport",
            ]
          );

        return {
          totalRegistered:
            asNumber(
              getObjectValue(
                summaryObject,
                [
                  "totalRegistered",
                  "totalANC",
                  "total",
                ],
                getObjectValue(
                  reportData,
                  [
                    "totalRegistered",
                    "totalANC",
                    "total",
                  ],
                  0
                )
              )
            ),

          pending:
            asNumber(
              getObjectValue(
                summaryObject,
                [
                  "activePendingFollowups",
                  "pending",
                  "pendingFollowup",
                ],
                0
              )
            ),

          highRisk:
            asNumber(
              getObjectValue(
                summaryObject,
                [
                  "highRiskCount",
                  "highRisk",
                ],
                getObjectValue(
                  highRisk,
                  [
                    "highRisk",
                  ],
                  0
                )
              )
            ),

          completed:
            asNumber(
              getObjectValue(
                summaryObject,
                [
                  "completedOutcomes",
                  "completed",
                ],
                0
              )
            ),

          upcoming7:
            asNumber(
              getObjectValue(
                upcoming,
                [
                  "within7DaysCount",
                  "within7Days",
                ],
                0
              )
            ),

          upcoming15:
            asNumber(
              getObjectValue(
                upcoming,
                [
                  "within15DaysCount",
                  "within15Days",
                ],
                0
              )
            ),

          upcoming30:
            asNumber(
              getObjectValue(
                upcoming,
                [
                  "within30DaysCount",
                  "within30Days",
                ],
                0
              )
            ),
        };
      },
      [reportData]
    );

  /* =====================================================
     REPORT ROWS
     ===================================================== */

  const reportRows =
    useMemo(
      function () {
        if (!reportData) {
          return [];
        }

        switch (
          activeReport
        ) {
          case "pendingFollowup": {
            const data =
              getReportObject(
                reportData,
                [
                  "pendingList",
                  "pendingFollowup",
                  "pendingFollowupReport",
                  "report1",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "staffPerformance": {
            const data =
              getReportObject(
                reportData,
                [
                  "anmPerf",
                  "staffPerf",
                  "staffPerformance",
                  "staffPerformanceReport",
                  "report2",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "highRisk": {
            const data =
              getReportObject(
                reportData,
                [
                  "highRisk",
                  "highRiskReport",
                  "report3",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "uphcPerformance": {
            const data =
              getReportObject(
                reportData,
                [
                  "phcPerf",
                  "uphcPerf",
                  "uphcPerformance",
                  "uphcPerformanceReport",
                  "report4",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "upcomingEdd": {
            const object =
              getReportObject(
                reportData,
                [
                  "upcomingEddReport",
                  "upcomingEdd",
                  "report5",
                ]
              );

            const seven =
              normalizeRows(
                object?.within7DaysList
              );

            const fifteen =
              normalizeRows(
                object?.within15DaysList
              );

            const thirty =
              normalizeRows(
                object?.within30DaysList
              );

            const samePatient =
              function (
                a,
                b
              ) {
                return (
                  (
                    a.name ||
                    a.patientName ||
                    ""
                  ) ===
                    (
                      b.name ||
                      b.patientName ||
                      ""
                    ) &&
                  (
                    a.edd ||
                    ""
                  ) ===
                    (
                      b.edd ||
                      ""
                    )
                );
              };

            return [
              ...seven.map(
                function (x) {
                  return {
                    ...x,
                    window:
                      "Within 7 Days",
                  };
                }
              ),

              ...fifteen
                .filter(
                  function (x) {
                    return !seven.some(
                      function (y) {
                        return samePatient(
                          y,
                          x
                        );
                      }
                    );
                  }
                )
                .map(
                  function (x) {
                    return {
                      ...x,
                      window:
                        "Within 15 Days",
                    };
                  }
                ),

              ...thirty
                .filter(
                  function (x) {
                    return (
                      !seven.some(
                        function (y) {
                          return samePatient(
                            y,
                            x
                          );
                        }
                      ) &&
                      !fifteen.some(
                        function (y) {
                          return samePatient(
                            y,
                            x
                          );
                        }
                      )
                    );
                  }
                )
                .map(
                  function (x) {
                    return {
                      ...x,
                      window:
                        "Within 30 Days",
                    };
                  }
                ),
            ];
          }

          case "trimester": {
            const object =
              getReportObject(
                reportData,
                [
                  "trimesterReport",
                  "trimester",
                  "report6",
                ]
              );

            return [
              {
                trimester:
                  "First Trimester",
                count:
                  asNumber(
                    object?.firstTrimester
                  ),
              },
              {
                trimester:
                  "Second Trimester",
                count:
                  asNumber(
                    object?.secondTrimester
                  ),
              },
              {
                trimester:
                  "Third Trimester",
                count:
                  asNumber(
                    object?.thirdTrimester
                  ),
              },
            ];
          }

          case "registrationTrend": {
            const data =
              getReportObject(
                reportData,
                [
                  "registrationTrend",
                  "registrationTrendReport",
                  "report7",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "highRiskNormal": {
            const object =
              getReportObject(
                reportData,
                [
                  "highRiskNormal",
                  "highRiskVsNormal",
                  "highRiskNormalReport",
                  "report8",
                ]
              );

            return [
              {
                category:
                  "High Risk",
                count:
                  asNumber(
                    object?.highRisk
                  ),
              },
              {
                category:
                  "Normal",
                count:
                  asNumber(
                    object?.normal
                  ),
              },
            ];
          }

          case "outcome": {
            const data =
              getReportObject(
                reportData,
                [
                  "outcomeDistribution",
                  "outcomeReport",
                  "outcome",
                  "report9",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "zoneDistribution": {
            const data =
              getReportObject(
                reportData,
                [
                  "zoneDistribution",
                  "blockDistribution",
                  "zoneDistributionReport",
                  "report10",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "followupFrequency": {
            const data =
              getReportObject(
                reportData,
                [
                  "followupFrequency",
                  "followupFrequencyReport",
                  "report11",
                ]
              );

            return normalizeRows(
              data
            );
          }

          case "overdueEdd": {
            const object =
              getReportObject(
                reportData,
                [
                  "overdueEddReport",
                  "overdueEdd",
                  "report12",
                ]
              );

            return normalizeRows(
              object?.list
            );
          }

          case "outcomePlace": {
            const object =
              getReportObject(
                reportData,
                [
                  "outcomePlaceReport",
                  "outcomePlace",
                  "report13",
                ]
              );

            return normalizeRows(
              object?.list
            );
          }

          case "dataQuality": {
            const object =
              getReportObject(
                reportData,
                [
                  "dataQualityReport",
                  "dataQuality",
                  "report14",
                ]
              );

            return normalizeRows(
              object?.patientList
            );
          }

          default:
            return [];
        }
      },
      [
        activeReport,
        reportData,
      ]
    );

  /* =====================================================
     TABLE COLUMNS
     ===================================================== */

  const tableColumns =
    useMemo(
      function () {
        switch (
          activeReport
        ) {
          case "pendingFollowup":
            return [
              {
                key: "patient",
                label: "Patient",
                keys: [
                  "name",
                  "patientName",
                  "Patient Name",
                ],
                width: 180,
              },
              {
                key: "hospital",
                label: "Facility",
                keys: [
                  "hospitalName",
                  "phcName",
                  "Hospital Name",
                ],
                width: 180,
              },
              {
                key: "staff",
                label: "Staff",
                keys: [
                  "staffNurse",
                  "anmName",
                  "Staff Nurse",
                ],
                width: 160,
              },
              {
                key: "asha",
                label: "ASHA",
                keys: [
                  "ashaName",
                  "ASHA Name",
                ],
                width: 140,
              },
              {
                key: "risk",
                label: "High Risk",
                keys: [
                  "highRisk",
                  "High Risk",
                ],
                width: 240,
              },
              {
                key: "frequency",
                label: "Frequency",
                keys: [
                  "followupFrequency",
                  "frequency",
                ],
                width: 130,
              },
            ];

          case "staffPerformance":
            return [
              {
                key: "staff",
                label: "Staff",
                keys: [
                  "anmName",
                  "staffNurse",
                  "staff",
                  "name",
                ],
                width: 180,
              },
              {
                key: "facility",
                label: "Facility",
                keys: [
                  "phcName",
                  "hospitalName",
                ],
                width: 180,
              },
              {
                key: "total",
                label: "Total",
                keys: [
                  "total",
                ],
                width: 90,
              },
              {
                key: "pending",
                label: "Pending",
                keys: [
                  "pending",
                ],
                width: 100,
              },
            ];

          case "highRisk":
            return [
              {
                key: "factor",
                label: "Risk Factor",
                keys: [
                  "factor",
                  "highRisk",
                ],
                width: 280,
              },
              {
                key: "count",
                label: "Count",
                keys: [
                  "count",
                ],
                width: 100,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "uphcPerformance":
            return [
              {
                key: "facility",
                label: "Facility",
                keys: [
                  "phcName",
                  "hospitalName",
                ],
                width: 200,
              },
              {
                key: "total",
                label: "Total",
                keys: [
                  "total",
                ],
                width: 90,
              },
              {
                key: "risk",
                label: "High Risk",
                keys: [
                  "highRisk",
                ],
                width: 100,
              },
              {
                key: "pending",
                label: "Pending",
                keys: [
                  "pending",
                ],
                width: 100,
              },
              {
                key: "completed",
                label: "Completed",
                keys: [
                  "completed",
                ],
                width: 110,
              },
            ];

          case "upcomingEdd":
            return [
              {
                key: "patient",
                label: "Patient",
                keys: [
                  "name",
                  "patientName",
                ],
                width: 180,
              },
              {
                key: "facility",
                label: "Facility",
                keys: [
                  "phcName",
                  "hospitalName",
                ],
                width: 180,
              },
              {
                key: "edd",
                label: "EDD",
                keys: [
                  "edd",
                ],
                width: 120,
              },
              {
                key: "days",
                label: "Days",
                keys: [
                  "daysRemaining",
                ],
                width: 100,
              },
              {
                key: "window",
                label: "Window",
                keys: [
                  "window",
                ],
                width: 140,
              },
            ];

          case "trimester":
            return [
              {
                key: "trimester",
                label: "Trimester",
                keys: [
                  "trimester",
                ],
                width: 180,
              },
              {
                key: "count",
                label: "Active ANC",
                keys: [
                  "count",
                ],
                width: 110,
              },
            ];

          case "registrationTrend":
            return [
              {
                key: "month",
                label: "Month",
                keys: [
                  "month",
                ],
                width: 150,
              },
              {
                key: "count",
                label: "Registrations",
                keys: [
                  "count",
                ],
                width: 120,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "highRiskNormal":
            return [
              {
                key: "category",
                label: "Category",
                keys: [
                  "category",
                ],
                width: 180,
              },
              {
                key: "count",
                label: "Count",
                keys: [
                  "count",
                ],
                width: 100,
              },
            ];

          case "outcome":
            return [
              {
                key: "outcome",
                label: "Outcome",
                keys: [
                  "outcome",
                ],
                width: 220,
              },
              {
                key: "count",
                label: "Count",
                keys: [
                  "count",
                ],
                width: 100,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "zoneDistribution":
            return [
              {
                key: "zone",
                label: "Zone",
                keys: [
                  "block",
                  "zone",
                ],
                width: 180,
              },
              {
                key: "count",
                label: "ANC Count",
                keys: [
                  "count",
                ],
                width: 110,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "followupFrequency":
            return [
              {
                key: "frequency",
                label: "Frequency",
                keys: [
                  "frequency",
                ],
                width: 180,
              },
              {
                key: "count",
                label: "Count",
                keys: [
                  "count",
                ],
                width: 100,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "overdueEdd":
            return [
              {
                key: "patient",
                label: "Patient",
                keys: [
                  "name",
                  "patientName",
                ],
                width: 180,
              },
              {
                key: "facility",
                label: "Facility",
                keys: [
                  "phcName",
                  "hospitalName",
                ],
                width: 180,
              },
              {
                key: "edd",
                label: "EDD",
                keys: [
                  "edd",
                ],
                width: 120,
              },
              {
                key: "days",
                label: "Days Overdue",
                keys: [
                  "daysOverdue",
                ],
                width: 120,
              },
            ];

          case "outcomePlace":
            return [
              {
                key: "place",
                label: "Outcome Place",
                keys: [
                  "place",
                ],
                width: 200,
              },
              {
                key: "count",
                label: "Count",
                keys: [
                  "count",
                ],
                width: 100,
              },
              {
                key: "percentage",
                label: "%",
                keys: [
                  "percentage",
                ],
                width: 100,
              },
            ];

          case "dataQuality":
            return [
              {
                key: "patient",
                label: "Patient",
                keys: [
                  "name",
                  "patientName",
                ],
                width: 180,
              },
              {
                key: "facility",
                label: "Facility",
                keys: [
                  "phcName",
                  "hospitalName",
                ],
                width: 180,
              },
              {
                key: "missing",
                label: "Missing Fields",
                keys: [
                  "missingFields",
                ],
                width: 360,
              },
            ];

          default:
            return [];
        }
      },
      [activeReport]
    );

  /* =====================================================
     CHART DATA
     ===================================================== */

  const chartData =
    useMemo(
      function () {
        const rows =
          reportRows || [];

        switch (
          activeReport
        ) {
          case "pendingFollowup": {
            const map = {};

            rows.forEach(
              function (row) {
                const facility =
                  getObjectValue(
                    row,
                    [
                      "phcName",
                      "hospitalName",
                    ],
                    "Unknown"
                  );

                map[facility] =
                  (
                    map[facility] ||
                    0
                  ) + 1;
              }
            );

            return {
              type: "bar",
              labels:
                Object.keys(map),
              values:
                Object.values(map),
              title:
                "Pending ANC by Facility",
            };
          }

          case "staffPerformance":
            return {
              type: "bar",
              labels:
                rows.map(
                  function (row) {
                    return getObjectValue(
                      row,
                      [
                        "anmName",
                        "staffNurse",
                        "name",
                      ],
                      "Staff"
                    );
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.total
                    );
                  }
                ),

              title:
                "Total ANC by Staff",
            };

          case "highRisk":
            return {
              type: "pie",
              labels:
                rows.map(
                  function (row) {
                    return getObjectValue(
                      row,
                      [
                        "factor",
                      ],
                      "Risk"
                    );
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "High-Risk Factor Distribution",
            };

          case "uphcPerformance":
            return {
              type: "bar",

              labels:
                rows.map(
                  function (row) {
                    return getObjectValue(
                      row,
                      [
                        "phcName",
                        "hospitalName",
                      ],
                      "Facility"
                    );
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.total
                    );
                  }
                ),

              title:
                "Total ANC by Facility",
            };

          case "upcomingEdd":
            return {
              type: "bar",

              labels: [
                "<= 7 Days",
                "<= 15 Days",
                "<= 30 Days",
              ],

              values: [
                summary.upcoming7,
                summary.upcoming15,
                summary.upcoming30,
              ],

              title:
                "Upcoming EDD Windows",
            };

          case "trimester":
            return {
              type: "pie",

              labels:
                rows.map(
                  function (row) {
                    return row.trimester;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "Active ANC by Trimester",
            };

          case "registrationTrend":
            return {
              type: "bar",

              labels:
                rows.map(
                  function (row) {
                    return row.month;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "ANC Registration Trend",
            };

          case "highRiskNormal":
            return {
              type: "pie",

              labels:
                rows.map(
                  function (row) {
                    return row.category;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "High-Risk vs Normal",
            };

          case "outcome":
            return {
              type: "pie",

              labels:
                rows.map(
                  function (row) {
                    return row.outcome;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "Pregnancy Outcome Distribution",
            };

          case "zoneDistribution":
            return {
              type: "bar",

              labels:
                rows.map(
                  function (row) {
                    return getObjectValue(
                      row,
                      [
                        "block",
                        "zone",
                      ],
                      "Zone"
                    );
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "ANC Distribution by Zone",
            };

          case "followupFrequency":
            return {
              type: "pie",

              labels:
                rows.map(
                  function (row) {
                    return row.frequency;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "Follow-up Frequency Distribution",
            };

          case "overdueEdd":
            return {
              type: "bar",

              labels:
                rows
                  .slice(
                    0,
                    10
                  )
                  .map(
                    function (row) {
                      return (
                        row.name ||
                        row.patientName ||
                        "Patient"
                      );
                    }
                  ),

              values:
                rows
                  .slice(
                    0,
                    10
                  )
                  .map(
                    function (row) {
                      return asNumber(
                        row.daysOverdue
                      );
                    }
                  ),

              title:
                "Top Overdue EDD Cases",
            };

          case "outcomePlace":
            return {
              type: "pie",

              labels:
                rows.map(
                  function (row) {
                    return row.place;
                  }
                ),

              values:
                rows.map(
                  function (row) {
                    return asNumber(
                      row.count
                    );
                  }
                ),

              title:
                "Outcome Place Distribution",
            };

          case "dataQuality": {
            const map = {};

            rows.forEach(
              function (row) {
                const fields =
                  String(
                    row.missingFields ||
                      ""
                  )
                    .split("|")
                    .map(
                      function (x) {
                        return x.trim();
                      }
                    )
                    .filter(
                      Boolean
                    );

                fields.forEach(
                  function (
                    field
                  ) {
                    map[field] =
                      (
                        map[field] ||
                        0
                      ) + 1;
                  }
                );
              }
            );

            return {
              type: "bar",
              labels:
                Object.keys(map),
              values:
                Object.values(map),
              title:
                "Missing Information by Field",
            };
          }

          default:
            return {
              type: "bar",
              labels: [],
              values: [],
              title: "",
            };
        }
      },
      [
        activeReport,
        reportRows,
        summary,
      ]
    );

  /* =====================================================
     CSV HELPERS
     ===================================================== */

  function csvEscape(
    value
  ) {
    const text =
      value === undefined ||
      value === null
        ? ""
        : String(value);

    return (
      '"' +
      text
        .replace(
          /"/g,
          '""'
        )
        .replace(
          /\r?\n/g,
          " "
        ) +
      '"'
    );
  }

  function buildCsv(
    rows,
    columns
  ) {
    const header =
      columns
        .map(
          function (column) {
            return csvEscape(
              column.label
            );
          }
        )
        .join(",");

    const lines =
      rows.map(
        function (row) {
          return columns
            .map(
              function (column) {
                return csvEscape(
                  getObjectValue(
                    row,
                    column.keys ||
                      [column.key],
                    ""
                  )
                );
              }
            )
            .join(",");
        }
      );

    return [
      header,
      ...lines,
    ].join("\n");
  }

  function base64EncodeUtf8(
    text
  ) {
    try {
      return btoa(
        unescape(
          encodeURIComponent(
            text
          )
        )
      );
    } catch (
      error
    ) {
      return btoa(text);
    }
  }

  /* =====================================================
     DOWNLOAD PENDING CSV
     ===================================================== */

  async function downloadPendingCsv() {
    if (
      !reportRows ||
      reportRows.length === 0
    ) {
      Alert.alert(
        "No Data",
        "There are no pending follow-up records to download."
      );
      return;
    }

    try {
      const csv =
        buildCsv(
          reportRows,
          tableColumns
        );

      const fileName =
        "ANC_Pending_Followup_List_" +
        new Date()
          .toISOString()
          .slice(0, 10) +
        ".csv";

      if (
        Platform.OS ===
        "web"
      ) {
        const blob =
          new Blob(
            [csv],
            {
              type:
                "text/csv;charset=utf-8;",
            }
          );

        const url =
          URL.createObjectURL(
            blob
          );

        const link =
          document.createElement(
            "a"
          );

        link.href =
          url;

        link.download =
          fileName;

        document.body.appendChild(
          link
        );

        link.click();

        document.body.removeChild(
          link
        );

        URL.revokeObjectURL(
          url
        );

        Alert.alert(
          "Downloaded",
          "Pending follow-up CSV has been downloaded."
        );

        return;
      }

      const directory =
        FileSystem.cacheDirectory;

      const fileUri =
        directory +
        fileName;

      await FileSystem.writeAsStringAsync(
        fileUri,
        csv,
        {
          encoding:
            FileSystem.EncodingType
              .UTF8,
        }
      );

      const canShare =
        await Sharing.isAvailableAsync();

      if (canShare) {
        await Sharing.shareAsync(
          fileUri,
          {
            mimeType:
              "text/csv",

            dialogTitle:
              "Download / Share Pending Follow-up CSV",

            UTI:
              "public.comma-separated-values-text",
          }
        );
      } else {
        Alert.alert(
          "CSV Created",
          "CSV file was created successfully at:\n" +
            fileUri
        );
      }
    } catch (
      error
    ) {
      Alert.alert(
        "CSV Download Failed",
        error?.message ||
          "Unable to create CSV file."
      );
    }
  }

  /* =====================================================
     EMAIL PENDING CSV
     ===================================================== */

  async function emailPendingCsv() {
    if (emailSending) {
      return;
    }

    if (
      !reportRows ||
      reportRows.length === 0
    ) {
      Alert.alert(
        "No Data",
        "There are no pending follow-up records to email."
      );
      return;
    }

    const email =
      user?.email || "";

    const cc =
      user?.cc || "";

    if (!email) {
      Alert.alert(
        "Email Not Configured",
        "No email address is configured for the logged-in user."
      );
      return;
    }

    try {
      setEmailSending(
        true
      );

      const csv =
        buildCsv(
          reportRows,
          tableColumns
        );

      const base64Data =
        base64EncodeUtf8(
          csv
        );

      const requestZone =
        isSuperAdmin
          ? "All"
          : userZone;

      const response =
        await sendPendingFollowupEmailV2(
          base64Data,
          requestZone,
          role,
          email,
          cc
        );

      const result =
        response?.data ??
        response;

      if (
        result &&
        result.success ===
          false
      ) {
        throw new Error(
          result.message ||
            "Unable to send pending follow-up email."
        );
      }

      Alert.alert(
        "Email Sent",
        result?.message ||
          "Pending follow-up CSV has been emailed successfully."
      );
    } catch (
      error
    ) {
      Alert.alert(
        "Email Failed",
        error?.message ||
          "Unable to send pending follow-up email."
      );
    } finally {
      setEmailSending(
        false
      );
    }
  }

  /* =====================================================
     DOWNLOAD WHOLE CHART PNG
     ===================================================== */

  async function downloadCurrentChart() {
    if (
      chartDownloading
    ) {
      return;
    }

    if (
      !chartCaptureRef.current
    ) {
      Alert.alert(
        "Chart Not Ready",
        "Please wait for the chart to finish rendering."
      );
      return;
    }

    const labels =
      Array.isArray(
        chartData?.labels
      )
        ? chartData.labels
        : [];

    const values =
      Array.isArray(
        chartData?.values
      )
        ? chartData.values
        : [];

    if (
      labels.length === 0
    ) {
      Alert.alert(
        "No Chart Data",
        "There is no chart data available for the selected report."
      );
      return;
    }

    try {
      setChartDownloading(
        true
      );

      /*
       * Capture the actual chart content container.
       *
       * The ref is NOT attached to the visible card.
       * For bar charts it is attached to the full-width
       * inner content.
       *
       * Therefore the complete chart is captured even
       * when the chart is horizontally scrollable.
       */

      const uri =
        await captureRef(
          chartCaptureRef,
          {
            format: "png",
            quality: 1,
          }
        );

      if (!uri) {
        throw new Error(
          "Chart image was not created."
        );
      }

      const reportInfo =
        REPORTS.find(
          function (item) {
            return (
              item.id ===
              activeReport
            );
          }
        );

      const safeTitle =
        String(
          reportInfo?.title ||
            "ANC_Chart"
        )
          .replace(
            /[^a-zA-Z0-9]+/g,
            "_"
          )
          .replace(
            /^_+|_+$/g,
            ""
          );

      const fileName =
        safeTitle +
        "_" +
        new Date()
          .toISOString()
          .slice(0, 10) +
        ".png";

      /*
       * Native mobile:
       * Share the generated PNG.
       */

      if (
        Platform.OS !==
        "web"
      ) {
        const canShare =
          await Sharing.isAvailableAsync();

        if (canShare) {
          await Sharing.shareAsync(
            uri,
            {
              mimeType:
                "image/png",

              dialogTitle:
                "Download / Share Full Chart PNG",

              UTI:
                "public.png",
            }
          );

          Alert.alert(
            "Chart Ready",
            "The complete chart has been captured and is ready to save or share."
          );
        } else {
          Alert.alert(
            "Chart PNG Created",
            "The complete chart PNG was created successfully at:\n" +
              uri
          );
        }

        return;
      }

      /*
       * Web:
       * Download the full captured image.
       */

      const link =
        document.createElement(
          "a"
        );

      link.href =
        uri;

      link.download =
        fileName;

      document.body.appendChild(
        link
      );

      link.click();

      document.body.removeChild(
        link
      );

      Alert.alert(
        "Downloaded",
        "The complete chart PNG has been downloaded."
      );
    } catch (
      error
    ) {
      console.log(
        "CHART PNG ERROR:",
        error
      );

      Alert.alert(
        "Chart Download Failed",
        error?.message ||
          "Unable to capture the complete chart."
      );
    } finally {
      setChartDownloading(
        false
      );
    }
  }

  /* =====================================================
     ACTION BUTTONS
     ===================================================== */

  function renderPendingActions() {
    if (
      activeReport !==
      "pendingFollowup"
    ) {
      return null;
    }

    return (
      <View
        style={
          styles.actionRow
        }
      >
        <Pressable
          style={
            styles.downloadButton
          }
          onPress={
            downloadPendingCsv
          }
        >
          <Text
            style={
              styles.downloadButtonText
            }
          >
            Download CSV
          </Text>
        </Pressable>

        <Pressable
          style={[
            styles.emailButton,
            emailSending &&
              styles.disabledButton,
          ]}
          onPress={
            emailPendingCsv
          }
          disabled={
            emailSending
          }
        >
          {emailSending ? (
            <View
              style={
                styles.actionButtonInner
              }
            >
              <ActivityIndicator
                color="#ffffff"
                size="small"
              />

              <Text
                style={
                  styles.emailButtonText
                }
              >
                Sending...
              </Text>
            </View>
          ) : (
            <Text
              style={
                styles.emailButtonText
              }
            >
              Email CSV
            </Text>
          )}
        </Pressable>
      </View>
    );
  }

  function renderChartActions() {
    return (
      <View
        style={
          styles.chartActionRow
        }
      >
        <Pressable
          style={[
            styles.chartDownloadButton,
            chartDownloading &&
              styles.disabledButton,
          ]}
          onPress={
            downloadCurrentChart
          }
          disabled={
            chartDownloading
          }
        >
          {chartDownloading ? (
            <View
              style={
                styles.actionButtonInner
              }
            >
              <ActivityIndicator
                color="#ffffff"
                size="small"
              />

              <Text
                style={
                  styles.chartDownloadText
                }
              >
                Preparing PNG...
              </Text>
            </View>
          ) : (
            <Text
              style={
                styles.chartDownloadText
              }
            >
              Download Chart PNG
            </Text>
          )}
        </Pressable>
      </View>
    );
  }

  /* =====================================================
     REPORT SELECTOR
     ===================================================== */

  function renderReportButton({
    item,
  }) {
    const selected =
      item.id ===
      activeReport;

    return (
      <Pressable
        onPress={
          function () {
            setActiveReport(
              item.id
            );

            /*
             * Clear old capture ref before
             * new report chart mounts.
             */
            chartCaptureRef.current =
              null;
          }
        }
        style={[
          styles.reportButton,
          selected &&
            styles.reportButtonSelected,
        ]}
      >
        <View
          style={[
            styles.reportNumber,
            selected &&
              styles.reportNumberSelected,
          ]}
        >
          <Text
            style={[
              styles.reportNumberText,
              selected &&
                styles.reportNumberTextSelected,
            ]}
          >
            {item.number}
          </Text>
        </View>

        <View
          style={
            styles.reportButtonTextWrap
          }
        >
          <Text
            style={[
              styles.reportButtonTitle,
              selected &&
                styles.reportButtonTitleSelected,
            ]}
            numberOfLines={1}
          >
            {item.title}
          </Text>

          <Text
            style={
              styles.reportButtonSubtitle
            }
            numberOfLines={1}
          >
            {item.subtitle}
          </Text>
        </View>
      </Pressable>
    );
  }

  /* =====================================================
     LOADING
     ===================================================== */

  if (loading) {
    return (
      <View
        style={
          styles.loadingContainer
        }
      >
        <View
          style={
            styles.loadingCard
          }
        >
          <ActivityIndicator
            size="large"
            color="#2563eb"
          />

          <Text
            style={
              styles.loadingTitle
            }
          >
            Loading Reports
          </Text>

          <Text
            style={
              styles.loadingText
            }
          >
            Connecting to PCMC ANC data...
          </Text>
        </View>
      </View>
    );
  }

  /* =====================================================
     SCREEN
     ===================================================== */

  return (
    <View
      style={
        styles.container
      }
    >
      {/* HEADER */}

      <View
        style={
          styles.header
        }
      >
        <Pressable
          style={
            styles.backButton
          }
          onPress={
            function () {
              navigation.goBack();
            }
          }
        >
          <Text
            style={
              styles.backText
            }
          >
            ‹
          </Text>
        </Pressable>

        <View
          style={
            styles.headerText
          }
        >
          <Text
            style={
              styles.headerTitle
            }
          >
            ANC Reports
          </Text>

          <Text
            style={
              styles.headerSubtitle
            }
          >
            PCMC High Risk ANC Tracking System
          </Text>
        </View>

        <Pressable
          style={
            styles.refreshButton
          }
          onPress={
            refreshReports
          }
          disabled={
            refreshing
          }
        >
          {refreshing ? (
            <ActivityIndicator
              color="#ffffff"
              size="small"
            />
          ) : (
            <Text
              style={
                styles.refreshText
              }
            >
              ↻
            </Text>
          )}
        </Pressable>
      </View>

      {/* SCOPE */}

      <View
        style={
          styles.scopeBanner
        }
      >
        <View>
          <Text
            style={
              styles.scopeLabel
            }
          >
            REPORTING AREA
          </Text>

          <Text
            style={
              styles.scopeValue
            }
          >
            {reportingScope}
          </Text>
        </View>

        <View
          style={
            styles.scopeRoleBadge
          }
        >
          <Text
            style={
              styles.scopeRoleText
            }
          >
            {role}
          </Text>
        </View>
      </View>

      {/* ERROR */}

      {error ? (
        <View
          style={
            styles.errorBanner
          }
        >
          <Text
            style={
              styles.errorText
            }
          >
            {error}
          </Text>

          <Pressable
            onPress={
              function () {
                loadReports(
                  true
                );
              }
            }
          >
            <Text
              style={
                styles.retryText
              }
            >
              Retry
            </Text>
          </Pressable>
        </View>
      ) : null}

      {/* REPORT SELECTOR */}

      <FlatList
        data={REPORTS}
        renderItem={
          renderReportButton
        }
        keyExtractor={
          function (item) {
            return item.id;
          }
        }
        horizontal
        showsHorizontalScrollIndicator={
          false
        }
        contentContainerStyle={
          styles.reportSelector
        }
        style={
          styles.reportSelectorList
        }
      />

      {/* REPORT CONTENT */}

      <FlatList
        data={[
          activeReport,
        ]}
        keyExtractor={
          function (item) {
            return item;
          }
        }
        refreshControl={
          <RefreshControl
            refreshing={
              refreshing
            }
            onRefresh={
              refreshReports
            }
          />
        }
        renderItem={
          function () {
            const activeReportInfo =
              REPORTS.find(
                function (
                  item
                ) {
                  return (
                    item.id ===
                    activeReport
                  );
                }
              );

            return (
              <View
                style={
                  styles.mainContent
                }
              >
                {/* REPORT HEADER */}

                <View
                  style={
                    styles.reportHeading
                  }
                >
                  <View
                    style={
                      styles.reportHeadingTextWrap
                    }
                  >
                    <Text
                      style={
                        styles.reportHeadingNumber
                      }
                    >
                      REPORT{" "}
                      {
                        activeReportInfo?.number
                      }
                    </Text>

                    <Text
                      style={
                        styles.reportHeadingTitle
                      }
                    >
                      {
                        activeReportInfo?.title
                      }
                    </Text>

                    <Text
                      style={
                        styles.reportHeadingSubtitle
                      }
                    >
                      {
                        activeReportInfo?.subtitle
                      }
                    </Text>
                  </View>

                  <View
                    style={
                      styles.dataCountBadge
                    }
                  >
                    <Text
                      style={
                        styles.dataCountNumber
                      }
                    >
                      {
                        reportRows.length
                      }
                    </Text>

                    <Text
                      style={
                        styles.dataCountLabel
                      }
                    >
                      Rows
                    </Text>
                  </View>
                </View>

                {/* SUMMARY */}

                <View
                  style={
                    styles.summaryGrid
                  }
                >
                  <SummaryCard
                    label="Total Registered"
                    value={
                      summary.totalRegistered
                    }
                    detail="ANC registrations"
                  />

                  <SummaryCard
                    label="Pending"
                    value={
                      summary.pending
                    }
                    detail="Current follow-up"
                  />

                  <SummaryCard
                    label="High Risk"
                    value={
                      summary.highRisk
                    }
                    detail="High-risk ANC"
                  />

                  <SummaryCard
                    label="Completed"
                    value={
                      summary.completed
                    }
                    detail="Pregnancy outcomes"
                  />
                </View>

                {/* PENDING ACTIONS */}

                {renderPendingActions()}

                {/* CHART CARD */}

                <View
                  style={
                    styles.chartCard
                  }
                >
                  <SectionTitle
                    title="Visual Summary"
                    subtitle="Report data presented as a chart"
                  />

                  {chartData.type ===
                  "pie" ? (
                    <SafePieChart
                      labels={
                        chartData.labels
                      }
                      values={
                        chartData.values
                      }
                      title={
                        chartData.title
                      }
                      captureTargetRef={
                        chartCaptureRef
                      }
                    />
                  ) : (
                    <SafeBarChart
                      labels={
                        chartData.labels
                      }
                      values={
                        chartData.values
                      }
                      title={
                        chartData.title
                      }
                      captureTargetRef={
                        chartCaptureRef
                      }
                    />
                  )}

                  {renderChartActions()}
                </View>

                {/* UPCOMING EDD */}

                {activeReport ===
                "upcomingEdd" ? (
                  <View
                    style={
                      styles.insightCard
                    }
                  >
                    <Text
                      style={
                        styles.insightTitle
                      }
                    >
                      Upcoming EDD Monitor
                    </Text>

                    <View
                      style={
                        styles.insightRow
                      }
                    >
                      <View
                        style={
                          styles.insightBox
                        }
                      >
                        <Text
                          style={
                            styles.insightNumber
                          }
                        >
                          {
                            summary.upcoming7
                          }
                        </Text>

                        <Text
                          style={
                            styles.insightLabel
                          }
                        >
                          Within 7 Days
                        </Text>
                      </View>

                      <View
                        style={
                          styles.insightBox
                        }
                      >
                        <Text
                          style={
                            styles.insightNumber
                          }
                        >
                          {
                            summary.upcoming15
                          }
                        </Text>

                        <Text
                          style={
                            styles.insightLabel
                          }
                        >
                          Within 15 Days
                        </Text>
                      </View>

                      <View
                        style={
                          styles.insightBox
                        }
                      >
                        <Text
                          style={
                            styles.insightNumber
                          }
                        >
                          {
                            summary.upcoming30
                          }
                        </Text>

                        <Text
                          style={
                            styles.insightLabel
                          }
                        >
                          Within 30 Days
                        </Text>
                      </View>
                    </View>
                  </View>
                ) : null}

                {/* DATA QUALITY */}

                {activeReport ===
                "dataQuality" ? (
                  <View
                    style={
                      styles.insightCard
                    }
                  >
                    <Text
                      style={
                        styles.insightTitle
                      }
                    >
                      Data Quality Monitor
                    </Text>

                    <Text
                      style={
                        styles.insightBigText
                      }
                    >
                      {
                        reportRows.length
                      }
                    </Text>

                    <Text
                      style={
                        styles.insightSmallText
                      }
                    >
                      patients have one or more
                      missing information fields.
                    </Text>
                  </View>
                ) : null}

                {/* REPORT TABLE */}

                <View
                  style={
                    styles.tableCard
                  }
                >
                  <SectionTitle
                    title="Report Data"
                    subtitle="Live data from the Google Sheet backend"
                  />

                  <ReportTable
                    rows={
                      reportRows
                    }
                    columns={
                      tableColumns
                    }
                  />
                </View>

                {/* FOOTER */}

                <View
                  style={
                    styles.footerNote
                  }
                >
                  <Text
                    style={
                      styles.footerNoteText
                    }
                  >
                    Report loaded for{" "}
                    {reportingScope}.
                    {" "}
                    Pull down or press refresh to
                    load the latest backend data.
                  </Text>
                </View>

                <View
                  style={
                    styles.bottomSpace
                  }
                />
              </View>
            );
          }
        }
        contentContainerStyle={
          styles.listContent
        }
        showsVerticalScrollIndicator={
          false
        }
      />
    </View>
  );
}

/* =========================================================
   STYLES
   ========================================================= */

const styles =
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor:
        "#f0f4f8",
    },

    loadingContainer: {
      flex: 1,
      backgroundColor:
        "#f0f4f8",
      justifyContent:
        "center",
      alignItems:
        "center",
      padding: 24,
    },

    loadingCard: {
      width: "100%",
      maxWidth: 380,
      backgroundColor:
        "#ffffff",
      borderRadius: 22,
      padding: 30,
      alignItems:
        "center",
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    loadingTitle: {
      marginTop: 16,
      color: "#1e293b",
      fontSize: 18,
      fontWeight: "800",
    },

    loadingText: {
      marginTop: 6,
      color: "#64748b",
      fontSize: 13,
    },

    header: {
      backgroundColor:
        "#1a365d",
      paddingTop:
        Platform.OS ===
        "android"
          ? 36
          : 54,
      paddingHorizontal: 18,
      paddingBottom: 18,
      flexDirection:
        "row",
      alignItems:
        "center",
      borderBottomLeftRadius:
        24,
      borderBottomRightRadius:
        24,
    },

    backButton: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor:
        "rgba(255,255,255,0.14)",
      justifyContent:
        "center",
      alignItems:
        "center",
      marginRight: 12,
    },

    backText: {
      color: "#ffffff",
      fontSize: 32,
      lineHeight: 34,
    },

    headerText: {
      flex: 1,
    },

    headerTitle: {
      color: "#ffffff",
      fontSize: 21,
      fontWeight: "800",
    },

    headerSubtitle: {
      color: "#dbeafe",
      fontSize: 12,
      marginTop: 3,
    },

    refreshButton: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor:
        "rgba(255,255,255,0.14)",
      justifyContent:
        "center",
      alignItems:
        "center",
    },

    refreshText: {
      color: "#ffffff",
      fontSize: 25,
      lineHeight: 28,
    },

    scopeBanner: {
      margin: 12,
      marginBottom: 4,
      padding: 12,
      borderRadius: 15,
      backgroundColor:
        "#ffffff",
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
      flexDirection:
        "row",
      alignItems:
        "center",
      justifyContent:
        "space-between",
    },

    scopeLabel: {
      color: "#64748b",
      fontSize: 9,
      fontWeight: "900",
      letterSpacing: 0.5,
    },

    scopeValue: {
      marginTop: 3,
      color: "#1e293b",
      fontSize: 13,
      fontWeight: "800",
    },

    scopeRoleBadge: {
      paddingVertical: 6,
      paddingHorizontal: 10,
      borderRadius: 10,
      backgroundColor:
        "#eff6ff",
    },

    scopeRoleText: {
      color: "#2563eb",
      fontSize: 10,
      fontWeight: "800",
    },

    errorBanner: {
      marginHorizontal: 12,
      marginTop: 8,
      backgroundColor:
        "#fee2e2",
      borderWidth: 1,
      borderColor:
        "#fecaca",
      borderRadius: 12,
      padding: 11,
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    errorText: {
      flex: 1,
      color: "#991b1b",
      fontSize: 12,
      lineHeight: 17,
    },

    retryText: {
      marginLeft: 10,
      color: "#b91c1c",
      fontSize: 12,
      fontWeight: "800",
    },

    reportSelectorList: {
      flexGrow: 0,
    },

    reportSelector: {
      paddingHorizontal: 12,
      paddingVertical: 10,
    },

    reportButton: {
      width: 190,
      minHeight: 66,
      marginRight: 8,
      backgroundColor:
        "#ffffff",
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
      borderRadius: 15,
      padding: 9,
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    reportButtonSelected: {
      backgroundColor:
        "#eff6ff",
      borderColor:
        "#2563eb",
    },

    reportNumber: {
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor:
        "#f1f5f9",
      justifyContent:
        "center",
      alignItems:
        "center",
      marginRight: 9,
    },

    reportNumberSelected: {
      backgroundColor:
        "#2563eb",
    },

    reportNumberText: {
      color: "#64748b",
      fontSize: 12,
      fontWeight: "800",
    },

    reportNumberTextSelected: {
      color: "#ffffff",
    },

    reportButtonTextWrap: {
      flex: 1,
    },

    reportButtonTitle: {
      color: "#1e293b",
      fontSize: 12,
      fontWeight: "800",
    },

    reportButtonTitleSelected: {
      color: "#1d4ed8",
    },

    reportButtonSubtitle: {
      marginTop: 3,
      color: "#94a3b8",
      fontSize: 9,
      lineHeight: 13,
    },

    listContent: {
      paddingBottom: 30,
    },

    mainContent: {
      paddingHorizontal: 12,
      paddingTop: 3,
    },

    reportHeading: {
      backgroundColor:
        "#ffffff",
      borderRadius: 19,
      padding: 17,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    reportHeadingTextWrap: {
      flex: 1,
    },

    reportHeadingNumber: {
      color: "#2563eb",
      fontSize: 10,
      fontWeight: "900",
    },

    reportHeadingTitle: {
      color: "#1e293b",
      fontSize: 20,
      fontWeight: "900",
      marginTop: 3,
    },

    reportHeadingSubtitle: {
      color: "#64748b",
      fontSize: 12,
      marginTop: 4,
    },

    dataCountBadge: {
      marginLeft: 10,
      minWidth: 55,
      paddingVertical: 8,
      paddingHorizontal: 9,
      borderRadius: 13,
      backgroundColor:
        "#eff6ff",
      alignItems:
        "center",
    },

    dataCountNumber: {
      color: "#1d4ed8",
      fontSize: 16,
      fontWeight: "900",
    },

    dataCountLabel: {
      color: "#60a5fa",
      fontSize: 9,
      fontWeight: "700",
    },

    summaryGrid: {
      flexDirection:
        "row",
      flexWrap:
        "wrap",
      justifyContent:
        "space-between",
      marginTop: 12,
    },

    summaryCard: {
      width: "48.5%",
      backgroundColor:
        "#ffffff",
      borderRadius: 16,
      padding: 14,
      marginBottom: 10,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    summaryLabel: {
      color: "#64748b",
      fontSize: 10,
      fontWeight: "700",
    },

    summaryValue: {
      marginTop: 5,
      color: "#1e293b",
      fontSize: 24,
      fontWeight: "900",
    },

    summaryDetail: {
      color: "#94a3b8",
      fontSize: 9,
      marginTop: 2,
    },

    actionRow: {
      flexDirection:
        "row",
      gap: 9,
      marginBottom: 12,
    },

    downloadButton: {
      flex: 1,
      minHeight: 49,
      borderRadius: 13,
      backgroundColor:
        "#2563eb",
      justifyContent:
        "center",
      alignItems:
        "center",
      paddingHorizontal: 10,
    },

    downloadButtonText: {
      color: "#ffffff",
      fontSize: 12,
      fontWeight: "800",
    },

    emailButton: {
      flex: 1,
      minHeight: 49,
      borderRadius: 13,
      backgroundColor:
        "#15803d",
      justifyContent:
        "center",
      alignItems:
        "center",
      paddingHorizontal: 10,
    },

    emailButtonText: {
      color: "#ffffff",
      fontSize: 12,
      fontWeight: "800",
    },

    actionButtonInner: {
      flexDirection:
        "row",
      alignItems:
        "center",
    },

    chartCard: {
      backgroundColor:
        "#ffffff",
      borderRadius: 18,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    sectionHeading: {
      marginBottom: 6,
    },

    sectionHeadingTitle: {
      color: "#1e293b",
      fontSize: 15,
      fontWeight: "800",
    },

    sectionHeadingSubtitle: {
      color: "#94a3b8",
      fontSize: 10,
      marginTop: 3,
    },

    chartScrollWrap: {
      marginTop: 5,
      alignItems:
        "center",
    },

    chartViewport: {
      width: "100%",
    },

    chartCaptureContainer: {
      backgroundColor:
        "#ffffff",
      paddingHorizontal: 6,
      paddingVertical: 3,
    },

    chartWrap: {
      marginTop: 5,
      alignItems:
        "center",
    },

    pieCaptureContainer: {
      width: CHART_WIDTH,
      backgroundColor:
        "#ffffff",
      paddingHorizontal: 4,
      paddingBottom: 6,
    },

    chart: {
      marginVertical: 5,
      borderRadius: 16,
    },

    chartTitle: {
      color: "#475569",
      fontSize: 11,
      fontWeight: "800",
      marginTop: 7,
      textAlign:
        "center",
    },

    chartHelperText: {
      color: "#94a3b8",
      fontSize: 10,
      lineHeight: 15,
      textAlign:
        "center",
      marginTop: 2,
      paddingHorizontal: 10,
    },

    chartActionRow: {
      marginTop: 12,
    },

    chartDownloadButton: {
      minHeight: 47,
      borderRadius: 13,
      backgroundColor:
        "#7c3aed",
      justifyContent:
        "center",
      alignItems:
        "center",
      paddingHorizontal: 12,
    },

    chartDownloadText: {
      color: "#ffffff",
      fontSize: 12,
      fontWeight: "800",
    },

    pieLegend: {
      width: "100%",
      marginTop: 6,
      paddingHorizontal: 5,
    },

    pieLegendRow: {
      flexDirection:
        "row",
      alignItems:
        "center",
      paddingVertical: 5,
      borderBottomWidth: 1,
      borderBottomColor:
        "#f1f5f9",
    },

    pieDot: {
      width: 9,
      height: 9,
      borderRadius: 5,
      marginRight: 8,
    },

    pieLegendText: {
      flex: 1,
      color: "#475569",
      fontSize: 10,
    },

    pieLegendValue: {
      color: "#1e293b",
      fontSize: 10,
      fontWeight: "800",
      marginLeft: 8,
    },

    insightCard: {
      backgroundColor:
        "#ffffff",
      borderRadius: 18,
      padding: 15,
      marginBottom: 12,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    insightTitle: {
      color: "#1e293b",
      fontSize: 14,
      fontWeight: "800",
    },

    insightRow: {
      flexDirection:
        "row",
      marginTop: 12,
      gap: 8,
    },

    insightBox: {
      flex: 1,
      paddingVertical: 13,
      borderRadius: 13,
      backgroundColor:
        "#eff6ff",
      alignItems:
        "center",
    },

    insightNumber: {
      color: "#2563eb",
      fontSize: 22,
      fontWeight: "900",
    },

    insightLabel: {
      marginTop: 3,
      color: "#64748b",
      fontSize: 9,
      textAlign:
        "center",
      fontWeight: "700",
    },

    insightBigText: {
      marginTop: 8,
      color: "#dc2626",
      fontSize: 30,
      fontWeight: "900",
    },

    insightSmallText: {
      color: "#64748b",
      fontSize: 11,
      lineHeight: 17,
      marginTop: 2,
    },

    tableCard: {
      backgroundColor:
        "#ffffff",
      borderRadius: 18,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor:
        "#e2e8f0",
    },

    tableHeader: {
      flexDirection:
        "row",
      backgroundColor:
        "#f1f5f9",
    },

    tableRow: {
      flexDirection:
        "row",
      borderBottomWidth: 1,
      borderBottomColor:
        "#e2e8f0",
    },

    tableCell: {
      paddingHorizontal: 10,
      paddingVertical: 10,
      color: "#475569",
      fontSize: 11,
      borderRightWidth: 1,
      borderRightColor:
        "#f1f5f9",
    },

    tableHeaderCell: {
      color: "#334155",
      fontWeight: "800",
    },

    noDataBox: {
      padding: 22,
      alignItems:
        "center",
    },

    noDataText: {
      color: "#94a3b8",
      fontSize: 12,
      textAlign:
        "center",
    },

    footerNote: {
      paddingHorizontal: 7,
      paddingVertical: 7,
    },

    footerNoteText: {
      color: "#94a3b8",
      fontSize: 10,
      lineHeight: 15,
      textAlign:
        "center",
    },

    bottomSpace: {
      height: 35,
    },

    disabledButton: {
      opacity: 0.65,
    },
  });