import React, {
useEffect,
useState,
} from "react";

import {
View,
Text,
TextInput,
TouchableOpacity,
StyleSheet,
SafeAreaView,
KeyboardAvoidingView,
Platform,
ScrollView,
ActivityIndicator,
StatusBar,
} from "react-native";

import {
MaterialCommunityIcons,
} from "@expo/vector-icons";

import {
resetUserPassword,
} from "../api/api";

import {
COLORS,
APP_INFO,
} from "../constants/theme";

export default function ForgotPasswordScreen({
navigation,
}) {

const [
username,
setUsername,
] = useState("");

const [
oldPassword,
setOldPassword,
] = useState("");

const [
newPassword,
setNewPassword,
] = useState("");

const [
confirmPassword,
setConfirmPassword,
] = useState("");

const [
showOldPassword,
setShowOldPassword,
] = useState(false);

const [
showNewPassword,
setShowNewPassword,
] = useState(false);

const [
showConfirmPassword,
setShowConfirmPassword,
] = useState(false);

const [
loading,
setLoading,
] = useState(false);

const [
message,
setMessage,
] = useState("");

const [
messageType,
setMessageType,
] = useState("error");

/* =======================================================
CLEAR MESSAGE WHEN USER TYPES
======================================================= */

useEffect(() => {
  if (!message) {
    return undefined;
  }

  const timer = setTimeout(() => {
    setMessage("");
  }, 4000);

  return () => clearTimeout(timer);
}, [message]);

/* =======================================================
VALIDATION
======================================================= */

const validateForm =
() => {

 
  const cleanUsername =
    String(
      username || ""
    ).trim();

  if (!cleanUsername) {
    return "Username is required.";
  }

  if (!oldPassword) {
    return "Old Password is required.";
  }

  if (!newPassword) {
    return "New Password is required.";
  }

  if (
    newPassword.length < 4
  ) {
    return (
      "New Password must contain at least 4 characters."
    );
  }

  if (!confirmPassword) {
    return (
      "Confirm New Password is required."
    );
  }

  if (
    newPassword !==
    confirmPassword
  ) {
    return (
      "New Password and Confirm New Password do not match."
    );
  }

  if (
    oldPassword ===
    newPassword
  ) {
    return (
      "New Password must be different from Old Password."
    );
  }

  return "";
};
 

/* =======================================================
RESET PASSWORD
======================================================= */

const handleReset =
async () => {

 
  const validationError =
    validateForm();

  if (validationError) {

    setMessageType(
      "error"
    );

    setMessage(
      validationError
    );

    return;
  }


  setLoading(true);
  setMessage("");


  try {

    const response =
      await resetUserPassword(

        String(
          username || ""
        ).trim(),

        oldPassword,

        newPassword
      );


    /*
     * API Bridge response:
     *
     * {
     *   success: true,
     *   data: {
     *      success: true,
     *      message: "..."
     *   }
     * }
     */

    const result =
      response?.data;


    if (
      !result ||
      !result.success
    ) {

      setMessageType(
        "error"
      );

      setMessage(
        result?.message ||
        response?.message ||
        "Password update failed."
      );

      return;
    }


    /* ---------------------------------------------------
       SUCCESS
       --------------------------------------------------- */

    setMessageType(
      "success"
    );

    setMessage(
      result.message ||
      "Password changed successfully!"
    );


    setOldPassword("");
    setNewPassword("");
    setConfirmPassword("");


    /*
     * After successful reset return
     * to Login screen.
     */

    setTimeout(
      () => {

        navigation.replace(
          "Login"
        );

      },
      1600
    );


  } catch (error) {

    console.log(
      "RESET PASSWORD ERROR:",
      error
    );

    setMessageType(
      "error"
    );

    setMessage(
      error?.message ||
      "Unable to reset password. Please check your internet connection."
    );


  } finally {

    setLoading(false);

  }

};
 

/* =======================================================
PASSWORD INPUT COMPONENT
======================================================= */

const PasswordInput = ({
value,
onChangeText,
placeholder,
showPassword,
setShowPassword,
}) => {

 
return (

  <View
    style={
      styles.inputWrapper
    }
  >

    <MaterialCommunityIcons
      name="lock-outline"
      size={21}
      color="#64748b"
      style={
        styles.inputIcon
      }
    />

    <TextInput
      style={
        styles.passwordInput
      }
      value={value}
      onChangeText={
        onChangeText
      }
      placeholder={
        placeholder
      }
      placeholderTextColor=
        "#94a3b8"
      secureTextEntry={
        !showPassword
      }
      editable={
        !loading
      }
      autoCapitalize=
        "none"
      autoCorrect={
        false
    }
    />

    <TouchableOpacity
      style={
        styles.eyeButton
      }
      onPress={() =>
        setShowPassword(
          !showPassword
        )
      }
      disabled={
        loading
      }
    >

      <MaterialCommunityIcons
        name={
          showPassword
            ? "eye-off-outline"
            : "eye-outline"
        }
        size={21}
        color="#64748b"
      />

    </TouchableOpacity>

  </View>

);
 

};

return (

 
<SafeAreaView
  style={
    styles.container
  }
>

  <StatusBar
    barStyle="light-content"
    backgroundColor=
      {COLORS.secondary}
  />


  <KeyboardAvoidingView
    style={
      styles.flex
    }
    behavior={
      Platform.OS ===
      "ios"
        ? "padding"
        : undefined
    }
  >

    <ScrollView
      contentContainerStyle=
        {styles.scrollContent}
      keyboardShouldPersistTaps=
        "handled"
      showsVerticalScrollIndicator=
        {false}
    >

      {/* =================================================
          HEADER
          ================================================= */}

      <View
        style={
          styles.header
        }
      >

        <View
          style={
            styles.iconCircle
          }
        >

          <MaterialCommunityIcons
            name="key-change"
            size={38}
            color="#ffffff"
          />

        </View>


        <Text
          style={
            styles.title
          }
        >
          Reset Password
        </Text>


        <Text
          style={
            styles.subtitle
          }
        >
          {APP_INFO.subtitle}
        </Text>

      </View>


      {/* =================================================
          CARD
          ================================================= */}

      <View
        style={
          styles.card
        }
      >

        <Text
          style={
            styles.cardTitle
          }
        >
          Forgot / Reset Password
        </Text>


        <Text
          style={
            styles.cardDescription
          }
        >
          Enter your registered username and current password
          to create a new password.
        </Text>


        {/* =================================================
            MESSAGE
            ================================================= */}

        {message ? (

          <View
            style={[
              styles.messageBox,
              messageType ===
                "success"
                ? styles.successBox
                : styles.errorBox,
            ]}
          >

            <MaterialCommunityIcons
              name={
                messageType ===
                "success"
                  ? "check-circle"
                  : "alert-circle"
              }
              size={20}
              color={
                messageType ===
                "success"
                  ? COLORS.success
                  : COLORS.danger
              }
            />

            <Text
              style={[
                styles.messageText,
                messageType ===
                  "success"
                  ? styles.successText
                  : styles.errorText,
              ]}
            >
              {message}
            </Text>

          </View>

        ) : null}


        {/* =================================================
            USERNAME
            ================================================= */}

        <Text
          style={
            styles.label
          }
        >
          Username
        </Text>


        <View
          style={
            styles.inputWrapper
          }
        >

          <MaterialCommunityIcons
            name="account-outline"
            size={21}
            color="#64748b"
            style={
              styles.inputIcon
            }
          />

          <TextInput
            style={
              styles.textInput
            }
            value={
              username
            }
            onChangeText={
              setUsername
            }
            placeholder=
              "Enter your registered username"
            placeholderTextColor=
              "#94a3b8"
            autoCapitalize=
              "none"
            autoCorrect={
              false
            }
            editable={
              !loading
            }
          />

        </View>


        {/* =================================================
            OLD PASSWORD
            ================================================= */}

        <Text
          style={
            styles.label
          }
        >
          Old Password
        </Text>


        <PasswordInput
          value={
            oldPassword
          }
          onChangeText={
            setOldPassword
          }
          placeholder=
            "Enter current password"
          showPassword={
            showOldPassword
          }
          setShowPassword={
            setShowOldPassword
          }
        />


        {/* =================================================
            NEW PASSWORD
            ================================================= */}

        <Text
          style={
            styles.label
          }
        >
          New Password
        </Text>


        <PasswordInput
          value={
            newPassword
          }
          onChangeText={
            setNewPassword
          }
          placeholder=
            "Enter new password"
          showPassword={
            showNewPassword
          }
          setShowPassword={
            setShowNewPassword
          }
        />


        {/* =================================================
            PASSWORD RULE
            ================================================= */}

        <View
          style={
            styles.ruleBox
          }
        >

          <MaterialCommunityIcons
            name="information-outline"
            size={18}
            color={
              COLORS.primary
            }
          />

          <Text
            style={
              styles.ruleText
            }
          >
            New password must contain at least 4 characters
            and must be different from the old password.
          </Text>

        </View>


        {/* =================================================
            CONFIRM PASSWORD
            ================================================= */}

        <Text
          style={
            styles.label
          }
        >
          Confirm New Password
        </Text>


        <PasswordInput
          value={
            confirmPassword
          }
          onChangeText={
            setConfirmPassword
          }
          placeholder=
            "Re-enter new password"
          showPassword={
            showConfirmPassword
          }
          setShowPassword={
            setShowConfirmPassword
          }
        />


        {/* =================================================
            RESET BUTTON
            ================================================= */}

        <TouchableOpacity
          activeOpacity={
            0.85
          }
          style={[
            styles.resetButton,
            loading &&
              styles.disabledButton,
          ]}
          onPress={
            handleReset
          }
          disabled={
            loading
          }
        >

          {loading ? (

            <ActivityIndicator
              size="small"
              color="#ffffff"
            />

          ) : (

            <>

              <MaterialCommunityIcons
                name="lock-reset"
                size={22}
                color="#ffffff"
              />

              <Text
                style={
                  styles.resetButtonText
                }
              >
                Update Password
              </Text>

            </>

          )}

        </TouchableOpacity>


        {/* =================================================
            BACK BUTTON
            ================================================= */}

        <TouchableOpacity
          style={
            styles.backButton
          }
          onPress={() =>
            navigation.replace(
              "Login"
            )
          }
          disabled={
            loading
          }
        >

          <MaterialCommunityIcons
            name="arrow-left"
            size={19}
            color={
              COLORS.textLight
            }
          />

          <Text
            style={
              styles.backButtonText
            }
          >
            Back to Login
          </Text>

        </TouchableOpacity>

      </View>


      {/* =================================================
          FOOTER
          ================================================= */}

      <View
        style={
          styles.footer
        }
      >

        <Text
          style={
            styles.footerText
          }
        >
          Pimpri Chinchwad Municipal Corporation
        </Text>

        <Text
          style={
            styles.footerSubText
          }
        >
          Health Department
        </Text>

        <Text
          style={
            styles.footerVersion
          }
        >
          {APP_INFO.title} · v
          {APP_INFO.version}
        </Text>

      </View>

    </ScrollView>

  </KeyboardAvoidingView>

</SafeAreaView>
 

);

}

/* =========================================================
STYLES
========================================================= */

const styles =
StyleSheet.create({

 
flex: {
  flex: 1,
},

container: {
  flex: 1,
  backgroundColor:
    COLORS.secondary,
},

scrollContent: {
  flexGrow: 1,
  padding:
    20,
  justifyContent:
    "center",
},


/* -------------------------------------------------------
   HEADER
   ------------------------------------------------------- */

header: {
  alignItems:
    "center",
  marginBottom:
    22,
},

iconCircle: {
  width:
    76,
  height:
    76,
  borderRadius:
    38,
  backgroundColor:
    "rgba(255,255,255,0.14)",
  borderWidth:
    1,
  borderColor:
    "rgba(255,255,255,0.28)",
  alignItems:
    "center",
  justifyContent:
    "center",
  marginBottom:
    13,
},

title: {
  fontSize:
    25,
  fontWeight:
    "800",
  color:
    "#ffffff",
  textAlign:
    "center",
},

subtitle: {
  fontSize:
    14,
  fontWeight:
    "600",
  color:
    "#dbeafe",
  marginTop:
    5,
},


/* -------------------------------------------------------
   CARD
   ------------------------------------------------------- */

card: {
  backgroundColor:
    "#ffffff",
  borderRadius:
    18,
  padding:
    22,
  borderTopWidth:
    5,
  borderTopColor:
    COLORS.primary,

  shadowColor:
    "#000",

  shadowOffset: {
    width: 0,
    height: 5,
  },

  shadowOpacity:
    0.14,

  shadowRadius:
    12,

  elevation:
    8,
},

cardTitle: {
  fontSize:
    21,
  fontWeight:
    "800",
  color:
    COLORS.textDark,
  textAlign:
    "center",
},

cardDescription: {
  fontSize:
    13,
  lineHeight:
    19,
  color:
    "#64748b",
  textAlign:
    "center",
  marginTop:
    7,
  marginBottom:
    5,
},


/* -------------------------------------------------------
   MESSAGE
   ------------------------------------------------------- */

messageBox: {
  flexDirection:
    "row",
  alignItems:
    "flex-start",
  borderRadius:
    10,
  padding:
    12,
  marginTop:
    16,
  borderWidth:
    1,
},

errorBox: {
  backgroundColor:
    "#fef2f2",
  borderColor:
    "#fecaca",
},

successBox: {
  backgroundColor:
    "#f0fdf4",
  borderColor:
    "#bbf7d0",
},

messageText: {
  flex: 1,
  marginLeft:
    8,
  fontSize:
    13,
  lineHeight:
    19,
  fontWeight:
    "600",
},

errorText: {
  color:
    COLORS.danger,
},

successText: {
  color:
    COLORS.success,
},


/* -------------------------------------------------------
   INPUT
   ------------------------------------------------------- */

label: {
  fontSize:
    14,
  fontWeight:
    "700",
  color:
    COLORS.textLight,
  marginTop:
    17,
  marginBottom:
    7,
},

inputWrapper: {
  minHeight:
    52,
  flexDirection:
    "row",
  alignItems:
    "center",
  borderWidth:
    1,
  borderColor:
    COLORS.border,
  borderRadius:
    10,
  backgroundColor:
    "#f8fafc",
},

inputIcon: {
  marginLeft:
    13,
},

textInput: {
  flex: 1,
  fontSize:
    15,
  color:
    COLORS.textDark,
  paddingHorizontal:
    11,
  paddingVertical:
    12,
},

passwordInput: {
  flex: 1,
  fontSize:
    15,
  color:
    COLORS.textDark,
  paddingLeft:
    11,
  paddingRight:
    4,
  paddingVertical:
    12,
},

eyeButton: {
  padding:
    12,
},


/* -------------------------------------------------------
   RULE
   ------------------------------------------------------- */

ruleBox: {
  flexDirection:
    "row",
  alignItems:
    "flex-start",
  backgroundColor:
    "#eff6ff",
  borderWidth:
    1,
  borderColor:
    "#bfdbfe",
  borderRadius:
    9,
  padding:
    10,
  marginTop:
    11,
},

ruleText: {
  flex: 1,
  marginLeft:
    7,
  fontSize:
    12,
  lineHeight:
    18,
  color:
    "#1d4ed8",
  fontWeight:
    "500",
},


/* -------------------------------------------------------
   BUTTONS
   ------------------------------------------------------- */

resetButton: {
  minHeight:
    54,
  marginTop:
    24,
  borderRadius:
    10,
  backgroundColor:
    COLORS.primary,
  flexDirection:
    "row",
  alignItems:
    "center",
  justifyContent:
    "center",

  shadowColor:
    COLORS.primary,

  shadowOffset: {
    width: 0,
    height: 4,
  },

  shadowOpacity:
    0.22,

  shadowRadius:
    7,

  elevation:
    4,
},

disabledButton: {
  opacity:
    0.65,
},

resetButtonText: {
  color:
    "#ffffff",
  fontSize:
    16,
  fontWeight:
    "800",
  marginLeft:
    8,
},

backButton: {
  flexDirection:
    "row",
  alignItems:
    "center",
  justifyContent:
    "center",
  paddingVertical:
    16,
},

backButtonText: {
  color:
    COLORS.textLight,
  fontSize:
    14,
  fontWeight:
    "700",
  marginLeft:
    6,
},


/* -------------------------------------------------------
   FOOTER
   ------------------------------------------------------- */

footer: {
  alignItems:
    "center",
  paddingTop:
    22,
  paddingBottom:
    5,
},

footerText: {
  fontSize:
    11,
  fontWeight:
    "600",
  color:
    "#dbeafe",
  textAlign:
    "center",
},

footerSubText: {
  fontSize:
    11,
  color:
    "#bfdbfe",
  marginTop:
    3,
  textAlign:
    "center",
},

footerVersion: {
  fontSize:
    10,
  color:
    "#94a3b8",
  marginTop:
    7,
  textAlign:
    "center",
},
 

});
