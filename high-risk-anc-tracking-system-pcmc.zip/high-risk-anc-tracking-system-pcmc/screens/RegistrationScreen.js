// screens/RegistrationScreen.js

import React, {
  useCallback,
  useMemo,
  useState,
} from "react";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import {
  MaterialCommunityIcons,
} from "@expo/vector-icons";

import {
  useFocusEffect,
} from "@react-navigation/native";

import {
  checkMobileExists,
  getStaffDropdownData,
  saveANCRegistration,
} from "../api/api";

import {
  COLORS,
} from "../constants/theme";

import {
  HIGH_RISK_FACTORS,
} from "../constants/highRiskFactors";

import {
  useAuth,
} from "../App";


/* =========================================================
   CONSTANTS
   ========================================================= */

const OTHER_OPTION =
  "__OTHER__";


/* =========================================================
   DATE HELPERS
   ========================================================= */

function pad(value) {
  return String(value).padStart(2, "0");
}


function formatDateForApi(date) {
  if (!(date instanceof Date)) {
    return "";
  }

  if (isNaN(date.getTime())) {
    return "";
  }

  return (
    date.getFullYear() +
    "-" +
    pad(date.getMonth() + 1) +
    "-" +
    pad(date.getDate())
  );
}


function formatDateForDisplay(value) {
  if (!value) {
    return "Select Date";
  }

  const parts =
    String(value).split("-");

  if (parts.length !== 3) {
    return value;
  }

  return (
    parts[2] +
    "-" +
    parts[1] +
    "-" +
    parts[0]
  );
}


function monthName(date) {
  const names = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  return names[
    date.getMonth()
  ];
}


/* =========================================================
   CALENDAR HELPERS
   ========================================================= */

function getDaysInMonth(
  year,
  monthIndex
) {
  return new Date(
    year,
    monthIndex + 1,
    0
  ).getDate();
}


function getFirstDayOfMonth(
  year,
  monthIndex
) {
  return new Date(
    year,
    monthIndex,
    1
  ).getDay();
}


function dateToNumber(date) {
  if (!(date instanceof Date)) {
    return 0;
  }

  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate()
  ).getTime();
}


function isDateAllowed(
  date,
  minimumDate,
  maximumDate
) {
  const value =
    dateToNumber(date);

  if (
    minimumDate &&
    value <
      dateToNumber(
        minimumDate
      )
  ) {
    return false;
  }

  if (
    maximumDate &&
    value >
      dateToNumber(
        maximumDate
      )
  ) {
    return false;
  }

  return true;
}


/* =========================================================
   GENERAL DATA HELPERS
   ========================================================= */

function toArray(value) {
  if (Array.isArray(value)) {
    return value;
  }

  if (
    value &&
    typeof value === "object"
  ) {
    return Object.values(value);
  }

  return [];
}


function getHospitalName(item) {
  if (
    typeof item === "string" ||
    typeof item === "number"
  ) {
    return String(item).trim();
  }

  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return String(
    item.name ||
    item.hospitalName ||
    item["Hospital Name"] ||
    item.hospital_name ||
    item.hospital ||
    item.facilityName ||
    item.facility ||
    item.facility_name ||
    item.label ||
    item.value ||
    ""
  ).trim();
}


function getHospitalZone(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return String(
    item.zone ||
    item.Zone ||
    item.zoneName ||
    item.ZoneName ||
    item.zone_name ||
    ""
  ).trim();
}


function getStaffHospitalName(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return String(
    item.hospital ||
    item.hospitalName ||
    item["Hospital Name"] ||
    item.hospital_name ||
    item.facilityName ||
    item.facility ||
    item.label ||
    ""
  ).trim();
}


function getStaffNurseName(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return String(
    item.staffNurse ||
    item.staff ||
    item.staffName ||
    item.staff_nurse ||
    item["Staff Nurse"] ||
    ""
  ).trim();
}


function getAshaName(item) {
  if (
    !item ||
    typeof item !== "object"
  ) {
    return "";
  }

  return String(
    item.ashaName ||
    item.asha ||
    item.ashaWorker ||
    item.asha_worker ||
    item["ASHA Name"] ||
    ""
  ).trim();
}


/* =========================================================
   VALIDATION
   ========================================================= */

function isValidMobile(value) {
  return /^[0-9]{10}$/.test(
    String(value || "").trim()
  );
}


function isValidAadhaar(value) {
  const clean =
    String(value || "")
      .replace(/\s/g, "")
      .trim();

  if (!clean) {
    return true;
  }

  return /^[0-9]{12}$/.test(
    clean
  );
}


/* =========================================================
   CUSTOM DATE FIELD
   ========================================================= */

function DateField({
  label,
  value,
  onChange,
  minimumDate,
  maximumDate,
}) {
  const [
    showPicker,
    setShowPicker,
  ] = useState(false);


  const [
    calendarDate,
    setCalendarDate,
  ] = useState(
    value
      ? new Date(
          value +
          "T00:00:00"
        )
      : new Date()
  );


  const parsedDate =
    useMemo(() => {
      if (value) {
        const date =
          new Date(
            value +
            "T00:00:00"
          );

        if (
          !isNaN(
            date.getTime()
          )
        ) {
          return date;
        }
      }

      return new Date();
    }, [value]);


  const openCalendar =
    () => {
      setCalendarDate(
        parsedDate
      );

      setShowPicker(
        true
      );
    };


  const closeCalendar =
    () => {
      setShowPicker(
        false
      );
    };


  const changeMonth =
    (direction) => {
      const next =
        new Date(
          calendarDate
        );

      next.setDate(1);

      next.setMonth(
        next.getMonth() +
        direction
      );

      setCalendarDate(
        next
      );
    };


  const selectDate =
    (day) => {
      const selected =
        new Date(
          calendarDate.getFullYear(),
          calendarDate.getMonth(),
          day
        );

      if (
        !isDateAllowed(
          selected,
          minimumDate,
          maximumDate
        )
      ) {
        return;
      }

      onChange(
        formatDateForApi(
          selected
        )
      );

      setShowPicker(
        false
      );
    };


  const calendarYear =
    calendarDate.getFullYear();

  const calendarMonth =
    calendarDate.getMonth();

  const totalDays =
    getDaysInMonth(
      calendarYear,
      calendarMonth
    );

  const firstDay =
    getFirstDayOfMonth(
      calendarYear,
      calendarMonth
    );


  const days = [];

  for (
    let i = 0;
    i < firstDay;
    i++
  ) {
    days.push(null);
  }


  for (
    let day = 1;
    day <= totalDays;
    day++
  ) {
    days.push(day);
  }


  while (
    days.length % 7 !== 0
  ) {
    days.push(null);
  }


  const weekRows = [];

  for (
    let i = 0;
    i < days.length;
    i += 7
  ) {
    weekRows.push(
      days.slice(
        i,
        i + 7
      )
    );
  }


  const selectedTimestamp =
    value
      ? dateToNumber(
          parsedDate
        )
      : 0;


  return (
    <View>

      <Text
        style={
          styles.label
        }
      >
        {label}
      </Text>


      <TouchableOpacity
        activeOpacity={0.82}
        onPress={
          openCalendar
        }
        style={[
          styles.dateField,
          !value &&
            styles.dateFieldEmpty,
        ]}
      >

        <MaterialCommunityIcons
          name="calendar-month-outline"
          size={21}
          color={
            value
              ? COLORS.primary
              : "#94a3b8"
          }
        />


        <Text
          style={[
            styles.dateFieldText,
            !value &&
              styles.dateFieldPlaceholder,
          ]}
        >
          {
            formatDateForDisplay(
              value
            )
          }
        </Text>


        <MaterialCommunityIcons
          name="calendar-edit"
          size={19}
          color="#64748b"
        />

      </TouchableOpacity>


      <Modal
        visible={
          showPicker
        }
        transparent={true}
        animationType="fade"
        onRequestClose={
          closeCalendar
        }
      >

        <Pressable
          style={
            styles.calendarOverlay
          }
          onPress={
            closeCalendar
          }
        >

          <Pressable
            style={
              styles.calendarModal
            }
            onPress={
              function (event) {
                event.stopPropagation();
              }
            }
          >

            <View
              style={
                styles.calendarHeader
              }
            >

              <View
                style={
                  styles.calendarTitleBox
                }
              >

                <Text
                  style={
                    styles.calendarTitle
                  }
                >
                  {label}
                </Text>


                <Text
                  style={
                    styles.calendarSelectedDate
                  }
                >
                  {
                    value
                      ? formatDateForDisplay(
                          value
                        )
                      : "Select Date"
                  }
                </Text>

              </View>


              <TouchableOpacity
                style={
                  styles.calendarCloseButton
                }
                onPress={
                  closeCalendar
                }
              >

                <MaterialCommunityIcons
                  name="close"
                  size={20}
                  color="#64748b"
                />

              </TouchableOpacity>

            </View>


            <View
              style={
                styles.calendarMonthHeader
              }
            >

              <TouchableOpacity
                style={
                  styles.calendarNavButton
                }
                onPress={() =>
                  changeMonth(
                    -1
                  )
                }
              >

                <MaterialCommunityIcons
                  name="chevron-left"
                  size={23}
                  color={
                    COLORS.primary
                  }
                />

              </TouchableOpacity>


              <Text
                style={
                  styles.calendarMonthText
                }
              >
                {
                  monthName(
                    calendarDate
                  )
                }{" "}
                {calendarYear}
              </Text>


              <TouchableOpacity
                style={
                  styles.calendarNavButton
                }
                onPress={() =>
                  changeMonth(
                    1
                  )
                }
              >

                <MaterialCommunityIcons
                  name="chevron-right"
                  size={23}
                  color={
                    COLORS.primary
                  }
                />

              </TouchableOpacity>

            </View>


            <View
              style={
                styles.weekRow
              }
            >

              {
                [
                  "Sun",
                  "Mon",
                  "Tue",
                  "Wed",
                  "Thu",
                  "Fri",
                  "Sat",
                ].map(
                  (day) => (
                    <Text
                      key={day}
                      style={
                        styles.weekDay
                      }
                    >
                      {day}
                    </Text>
                  )
                )
              }

            </View>


            <View
              style={
                styles.calendarGrid
              }
            >

              {weekRows.map(
                (
                  week,
                  weekIndex
                ) => (

                  <View
                    key={
                      "week-" +
                      weekIndex
                    }
                    style={
                      styles.calendarWeek
                    }
                  >

                    {week.map(
                      (
                        day,
                        dayIndex
                      ) => {

                        if (
                          day === null
                        ) {
                          return (
                            <View
                              key={
                                "empty-" +
                                weekIndex +
                                "-" +
                                dayIndex
                              }
                              style={
                                styles.calendarDay
                              }
                            />
                          );
                        }


                        const current =
                          new Date(
                            calendarYear,
                            calendarMonth,
                            day
                          );


                        const timestamp =
                          dateToNumber(
                            current
                          );


                        const selected =
                          timestamp ===
                          selectedTimestamp;


                        const allowed =
                          isDateAllowed(
                            current,
                            minimumDate,
                            maximumDate
                          );


                        const todayDate =
                          new Date();


                        const isToday =
                          timestamp ===
                          dateToNumber(
                            todayDate
                          );


                        return (
                          <TouchableOpacity
                            key={
                              "day-" +
                              weekIndex +
                              "-" +
                              dayIndex
                            }
                            activeOpacity={
                              allowed
                                ? 0.72
                                : 1
                            }
                            disabled={
                              !allowed
                            }
                            onPress={() =>
                              selectDate(
                                day
                              )
                            }
                            style={[
                              styles.calendarDay,
                              isToday &&
                                styles.calendarToday,
                              selected &&
                                styles.calendarDaySelected,
                              !allowed &&
                                styles.calendarDayDisabled,
                            ]}
                          >

                            <Text
                              style={[
                                styles.calendarDayText,
                                isToday &&
                                  styles.calendarTodayText,
                                selected &&
                                  styles.calendarDaySelectedText,
                                !allowed &&
                                  styles.calendarDayDisabledText,
                              ]}
                            >
                              {day}
                            </Text>

                          </TouchableOpacity>
                        );
                      }
                    )}

                  </View>
                )
              )}

            </View>


            <View
              style={
                styles.calendarFooter
              }
            >

              <TouchableOpacity
                style={
                  styles.calendarCancelButton
                }
                onPress={
                  closeCalendar
                }
              >

                <Text
                  style={
                    styles.calendarCancelText
                  }
                >
                  Cancel
                </Text>

              </TouchableOpacity>


              <TouchableOpacity
                style={
                  styles.calendarTodayButton
                }
                onPress={() => {

                  const now =
                    new Date();

                  if (
                    isDateAllowed(
                      now,
                      minimumDate,
                      maximumDate
                    )
                  ) {

                    onChange(
                      formatDateForApi(
                        now
                      )
                    );

                    setShowPicker(
                      false
                    );
                  }

                }}
              >

                <Text
                  style={
                    styles.calendarTodayTextButton
                  }
                >
                  Today
                </Text>

              </TouchableOpacity>

            </View>

          </Pressable>

        </Pressable>

      </Modal>

    </View>
  );
}


/* =========================================================
   SECTION CARD
   ========================================================= */

function SectionCard({
  icon,
  title,
  subtitle,
  children,
}) {
  return (
    <View
      style={
        styles.sectionCard
      }
    >

      <View
        style={
          styles.sectionHeader
        }
      >

        <View
          style={
            styles.sectionIcon
          }
        >

          <MaterialCommunityIcons
            name={icon}
            size={23}
            color={
              COLORS.primary
            }
          />

        </View>


        <View
          style={
            styles.sectionHeaderText
          }
        >

          <Text
            style={
              styles.sectionTitle
            }
          >
            {title}
          </Text>


          {
            subtitle
              ? (
                <Text
                  style={
                    styles.sectionSubtitle
                  }
                >
                  {subtitle}
                </Text>
              )
              : null
          }

        </View>

      </View>


      {children}

    </View>
  );
}


/* =========================================================
   TEXT FIELD
   ========================================================= */

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  maxLength,
  multiline,
  required,
  editable = true,
  autoCapitalize = "sentences",
}) {
  return (
    <View>

      <Text
        style={
          styles.label
        }
      >

        {label}


        {
          required
            ? (
              <Text
                style={
                  styles.required
                }
              >
                {" *"}
              </Text>
            )
            : null
        }

      </Text>


      <TextInput
        style={[
          styles.input,
          multiline &&
            styles.multilineInput,
          !editable &&
            styles.disabledInput,
        ]}
        value={
          value
        }
        onChangeText={
          onChangeText
        }
        placeholder={
          placeholder
        }
        placeholderTextColor="#94a3b8"
        keyboardType={
          keyboardType ||
          "default"
        }
        maxLength={
          maxLength
        }
        multiline={
          multiline
        }
        editable={
          editable
        }
        autoCapitalize={
          autoCapitalize
        }
        autoCorrect={
          false
        }
      />

    </View>
  );
}


/* =========================================================
   CUSTOM DROPDOWN FIELD
   ========================================================= */

function PickerField({
  label,
  value,
  onValueChange,
  items,
  placeholder,
  required,
  disabled,
}) {
  const [
    visible,
    setVisible,
  ] = useState(false);


  const selectedItem =
    items.find(
      (item) =>
        String(
          item.value
        ) ===
        String(
          value
        )
    );


  const displayText =
    selectedItem
      ? String(
          selectedItem.label
        )
      : (
          placeholder ||
          "-- Select --"
        );


  const selectItem =
    (item) => {

      onValueChange(
        String(
          item.value
        )
      );

      setVisible(
        false
      );
    };


  return (
    <View>

      <Text
        style={
          styles.label
        }
      >

        {label}


        {
          required
            ? (
              <Text
                style={
                  styles.required
                }
              >
                {" *"}
              </Text>
            )
            : null
        }

      </Text>


      <TouchableOpacity
        activeOpacity={0.78}
        disabled={
          disabled
        }
        onPress={() =>
          setVisible(
            true
          )
        }
        style={[
          styles.customDropdown,
          disabled &&
            styles.customDropdownDisabled,
        ]}
      >

        <View
          style={
            styles.dropdownLeft
          }
        >

          <MaterialCommunityIcons
            name="format-list-bulleted"
            size={19}
            color={
              disabled
                ? "#94a3b8"
                : COLORS.primary
            }
          />


          <Text
            numberOfLines={1}
            style={[
              styles.dropdownText,
              !selectedItem &&
                styles.dropdownPlaceholder,
            ]}
          >
            {displayText}
          </Text>

        </View>


        <MaterialCommunityIcons
          name={
            visible
              ? "chevron-up"
              : "chevron-down"
          }
          size={22}
          color="#64748b"
        />

      </TouchableOpacity>


      <Modal
        visible={
          visible
        }
        transparent={true}
        animationType="fade"
        onRequestClose={() =>
          setVisible(
            false
          )
        }
      >

        <Pressable
          style={
            styles.dropdownOverlay
          }
          onPress={() =>
            setVisible(
              false
            )
          }
        >

          <Pressable
            style={
              styles.dropdownModal
            }
            onPress={
              function (event) {
                event.stopPropagation();
              }
            }
          >

            <View
              style={
                styles.dropdownModalHeader
              }
            >

              <View
                style={
                  styles.dropdownModalTitleBox
                }
              >

                <Text
                  style={
                    styles.dropdownModalTitle
                  }
                >
                  {label}
                </Text>


                <Text
                  style={
                    styles.dropdownModalSubtitle
                  }
                >
                  Select one option
                </Text>

              </View>


              <TouchableOpacity
                style={
                  styles.dropdownCloseButton
                }
                onPress={() =>
                  setVisible(
                    false
                  )
                }
              >

                <MaterialCommunityIcons
                  name="close"
                  size={20}
                  color="#64748b"
                />

              </TouchableOpacity>

            </View>


            <ScrollView
              style={
                styles.dropdownList
              }
              showsVerticalScrollIndicator={
                true
              }
            >

              {
                items.length === 0
                  ? (
                    <View
                      style={
                        styles.dropdownEmpty
                      }
                    >

                      <MaterialCommunityIcons
                        name="database-off-outline"
                        size={28}
                        color="#94a3b8"
                      />


                      <Text
                        style={
                          styles.dropdownEmptyText
                        }
                      >
                        No options available
                      </Text>

                    </View>
                  )
                  : (
                    items.map(
                      (
                        item,
                        index
                      ) => {

                        const isSelected =
                          String(
                            item.value
                          ) ===
                          String(
                            value
                          );


                        return (
                          <TouchableOpacity
                            key={
                              String(
                                item.value
                              ) +
                              "-" +
                              String(
                                index
                              )
                            }
                            activeOpacity={0.75}
                            style={[
                              styles.dropdownOption,
                              isSelected &&
                                styles.dropdownOptionSelected,
                            ]}
                            onPress={() =>
                              selectItem(
                                item
                              )
                            }
                          >

                            <View
                              style={[
                                styles.dropdownOptionIcon,
                                isSelected &&
                                  styles.dropdownOptionIconSelected,
                              ]}
                            >

                              <MaterialCommunityIcons
                                name={
                                  isSelected
                                    ? "check"
                                    : "circle-outline"
                                }
                                size={
                                  isSelected
                                    ? 17
                                    : 15
                                }
                                color={
                                  isSelected
                                    ? "#ffffff"
                                    : "#64748b"
                                }
                              />

                            </View>


                            <Text
                              style={[
                                styles.dropdownOptionText,
                                isSelected &&
                                  styles.dropdownOptionTextSelected,
                              ]}
                            >
                              {
                                String(
                                  item.label
                                )
                              }
                            </Text>

                          </TouchableOpacity>
                        );
                      }
                    )
                  )
              }

            </ScrollView>

          </Pressable>

        </Pressable>

      </Modal>

    </View>
  );
}


/* =========================================================
   HIGH RISK CHECKBOX
   ========================================================= */

function RiskCheckbox({
  item,
  selected,
  onPress,
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.78}
      style={[
        styles.riskRow,
        selected &&
          styles.riskRowSelected,
      ]}
      onPress={
        onPress
      }
    >

      <View
        style={[
          styles.checkbox,
          selected &&
            styles.checkboxSelected,
        ]}
      >

        {
          selected
            ? (
              <MaterialCommunityIcons
                name="check"
                size={16}
                color="#ffffff"
              />
            )
            : null
        }

      </View>


      <Text
        style={
          styles.riskLabel
        }
      >
        {item.label}
      </Text>

    </TouchableOpacity>
  );
}


/* =========================================================
   MAIN SCREEN
   ========================================================= */

export default function RegistrationScreen({
  navigation,
}) {

  const {
    user,
  } = useAuth();


  /* =======================================================
     LOADING / STATUS
     ======================================================= */

  const [
    loadingMasters,
    setLoadingMasters,
  ] = useState(false);


  const [
    submitting,
    setSubmitting,
  ] = useState(false);


  const [
    checkingMobile,
    setCheckingMobile,
  ] = useState(false);


  const [
    mobileVerified,
    setMobileVerified,
  ] = useState(false);


  const [
    statusMessage,
    setStatusMessage,
  ] = useState("");


  const [
    statusType,
    setStatusType,
  ] = useState("info");


  /* =======================================================
     MASTER DATA
     ======================================================= */

  const [
    hospitals,
    setHospitals,
  ] = useState([]);


  const [
    staffData,
    setStaffData,
  ] = useState([]);


  const [
    blocks,
    setBlocks,
  ] = useState([]);


  const [
    districts,
    setDistricts,
  ] = useState([]);


  /* =======================================================
     REGISTRATION FIELDS
     ======================================================= */

  const [
    month,
    setMonth,
  ] = useState(
    monthName(
      new Date()
    )
  );


  const [
    regDate,
    setRegDate,
  ] = useState(
    formatDateForApi(
      new Date()
    )
  );


  const [
    selectedHospital,
    setSelectedHospital,
  ] = useState("");


  const [
    selectedStaff,
    setSelectedStaff,
  ] = useState("");


  const [
    selectedAsha,
    setSelectedAsha,
  ] = useState("");


  const [
    patientName,
    setPatientName,
  ] = useState("");


  const [
    age,
    setAge,
  ] = useState("");


  const [
    address,
    setAddress,
  ] = useState("");


  const [
    village,
    setVillage,
  ] = useState("");


  const [
    taluka,
    setTaluka,
  ] = useState("");


  const [
    district,
    setDistrict,
  ] = useState("Pune");


  /* =======================================================
     CUSTOM BLOCK / DISTRICT
     ======================================================= */

  const [
    blockCustom,
    setBlockCustom,
  ] = useState("");


  const [
    districtCustom,
    setDistrictCustom,
  ] = useState("");


  const [
    contact1,
    setContact1,
  ] = useState("");


  const [
    contact2,
    setContact2,
  ] = useState("");


  const [
    aadhaar,
    setAadhaar,
  ] = useState("");


  const [
    rchNumber,
    setRchNumber,
  ] = useState("");


  const [
    lmp,
    setLmp,
  ] = useState("");


  const [
    edd,
    setEdd,
  ] = useState("");


  const [
    gpal,
    setGpal,
  ] = useState("");


  const [
    selectedHighRisk,
    setSelectedHighRisk,
  ] = useState([
    "None",
  ]);


  const [
    highRiskOther,
    setHighRiskOther,
  ] = useState("");


  const [
    pastHistory,
    setPastHistory,
  ] = useState("");


  const [
    pastHistoryOther,
    setPastHistoryOther,
  ] = useState("");


  const [
    firstVisitDate,
    setFirstVisitDate,
  ] = useState("");


  const [
    followupFrequency,
    setFollowupFrequency,
  ] = useState("");


  const [
    referredTo,
    setReferredTo,
  ] = useState("");


  /* =======================================================
     DERIVED STAFF / ASHA
     ======================================================= */

  const hospitalStaff =
    useMemo(
      () => {

        if (!selectedHospital) {
          return [];
        }


        const unique =
          new Map();


        staffData
          .filter(
            (item) =>
              getStaffHospitalName(
                item
              )
                .toLowerCase() ===
              String(
                selectedHospital
              )
                .trim()
                .toLowerCase()
          )
          .forEach(
            (item) => {

              const nurse =
                getStaffNurseName(
                  item
                );

              if (
                nurse &&
                !unique.has(
                  nurse
                )
              ) {

                unique.set(
                  nurse,
                  item
                );

              }

            }
          );


        return Array.from(
          unique.values()
        );

      },
      [
        selectedHospital,
        staffData,
      ]
    );


  const staffAshas =
    useMemo(
      () => {

        if (
          !selectedHospital ||
          !selectedStaff
        ) {
          return [];
        }


        const unique =
          new Map();


        staffData
          .filter(
            (item) =>
              getStaffHospitalName(
                item
              )
                .toLowerCase() ===
                String(
                  selectedHospital
                )
                  .trim()
                  .toLowerCase() &&

              getStaffNurseName(
                item
              )
                .toLowerCase() ===
                String(
                  selectedStaff
                )
                  .trim()
                  .toLowerCase()
          )
          .forEach(
            (item) => {

              const asha =
                getAshaName(
                  item
                );

              if (
                asha &&
                !unique.has(
                  asha
                )
              ) {

                unique.set(
                  asha,
                  item
                );

              }

            }
          );


        return Array.from(
          unique.values()
        );

      },
      [
        selectedHospital,
        selectedStaff,
        staffData,
      ]
    );


  /* =======================================================
     RESET REGISTRATION FIELDS
     ======================================================= */

  const resetRegistrationFields =
    useCallback(
      () => {

        const today =
          new Date();


        setMonth(
          monthName(today)
        );


        setRegDate(
          formatDateForApi(
            today
          )
        );


        setSelectedHospital("");
        setSelectedStaff("");
        setSelectedAsha("");

        setPatientName("");
        setAge("");
        setAddress("");
        setVillage("");
        setTaluka("");
        setDistrict("Pune");

        setBlockCustom("");
        setDistrictCustom("");

        setContact2("");
        setAadhaar("");
        setRchNumber("");

        setLmp("");
        setEdd("");
        setGpal("");

        setSelectedHighRisk([
          "None",
        ]);

        setHighRiskOther("");

        setPastHistory("");
        setPastHistoryOther("");

        setFirstVisitDate("");
        setFollowupFrequency("");
        setReferredTo("");

      },
      []
    );


  /* =======================================================
     RESET ENTIRE FORM
     ======================================================= */

  const resetForm =
    useCallback(
      () => {

        resetRegistrationFields();

        setContact1("");

        setMobileVerified(
          false
        );

        setStatusMessage(
          ""
        );

      },
      [
        resetRegistrationFields,
      ]
    );


  /* =======================================================
     LOAD MASTER DATA
     ======================================================= */

  const loadMasters =
    useCallback(
      async () => {

        if (!user) {
          return;
        }


        setLoadingMasters(
          true
        );


        try {

          const result =
            await getStaffDropdownData(
              user.role ===
                "Super Admin"
                ? "All"
                : user.zone,
              user.role,
              user.assignedHospital ||
                ""
            );


          console.log(
            "STAFF DROPDOWN RESPONSE:",
            result
          );


          const firstData =
            result?.data ||
            result ||
            {};


          const data =
            firstData?.data ||
            firstData ||
            {};


          console.log(
            "FINAL MASTER DATA:",
            data
          );


          console.log(
            "HOSPITAL DATA:",
            data.hospitals
          );


          console.log(
            "STAFF DATA:",
            data.staffData
          );


          const allHospitals =
            toArray(
              data.hospitals
            );


          const role =
            String(
              user.role ||
              ""
            )
              .trim()
              .toLowerCase();


          const userZone =
            String(
              user.zone ||
              ""
            ).trim();


          const assignedHospital =
            String(
              user.assignedHospital ||
              ""
            ).trim();


          let filteredHospitals =
            allHospitals;


          /* =================================================
             ROLE-WISE HOSPITAL FILTER
             ================================================= */

          if (
            role === "super admin"
          ) {

            filteredHospitals =
              allHospitals;

          } else if (
            role === "admin"
          ) {

            const hospitalsWithZone =
              allHospitals.filter(
                (hospital) =>
                  getHospitalZone(
                    hospital
                  ) !== ""
              );


            if (
              hospitalsWithZone.length >
              0
            ) {

              filteredHospitals =
                hospitalsWithZone.filter(
                  (hospital) =>
                    getHospitalZone(
                      hospital
                    )
                      .toLowerCase() ===
                    userZone.toLowerCase()
                );

            } else {

              filteredHospitals =
                allHospitals;

            }

          } else {

            if (
              assignedHospital
            ) {

              filteredHospitals =
                allHospitals.filter(
                  (hospital) =>
                    getHospitalName(
                      hospital
                    )
                      .toLowerCase() ===
                    assignedHospital.toLowerCase()
                );

            } else {

              filteredHospitals =
                [];

            }

          }


          console.log(
            "USER ROLE:",
            user.role
          );


          console.log(
            "USER ZONE:",
            user.zone
          );


          console.log(
            "ASSIGNED HOSPITAL:",
            user.assignedHospital
          );


          console.log(
            "FILTERED HOSPITALS:",
            filteredHospitals
          );


          setHospitals(
            filteredHospitals
          );


          setStaffData(
            toArray(
              data.staffData
            )
          );


          setBlocks(
            toArray(
              data.blocks
            )
          );


          setDistricts(
            toArray(
              data.districts
            )
          );


          if (
            role !== "admin" &&
            role !== "super admin" &&
            assignedHospital
          ) {

            const matchedHospital =
              filteredHospitals.find(
                (hospital) =>
                  getHospitalName(
                    hospital
                  )
                    .toLowerCase() ===
                  assignedHospital.toLowerCase()
              );


            if (
              matchedHospital
            ) {

              setSelectedHospital(
                getHospitalName(
                  matchedHospital
                )
              );

            }

          }

        } catch (error) {

          console.log(
            "MASTER DATA ERROR:",
            error
          );


          setStatusType(
            "error"
          );


          setStatusMessage(
            error?.message ||
            "Unable to load master data."
          );

        } finally {

          setLoadingMasters(
            false
          );

        }

      },
      [
        user,
      ]
    );


  /* =======================================================
     LOAD ON SCREEN FOCUS
     ======================================================= */

  useFocusEffect(
    useCallback(
      () => {

        loadMasters();

      },
      [
        loadMasters,
      ]
    )
  );


  /* =======================================================
     HOSPITAL CHANGE
     ======================================================= */

  const handleHospitalChange =
    (value) => {

      setSelectedHospital(
        value
      );


      setSelectedStaff(
        ""
      );


      setSelectedAsha(
        ""
      );

    };


  /* =======================================================
     STAFF CHANGE
     ======================================================= */

  const handleStaffChange =
    (value) => {

      setSelectedStaff(
        value
      );


      setSelectedAsha(
        ""
      );

    };


  /* =======================================================
     BLOCK CHANGE
     ======================================================= */

  const handleBlockChange =
    (value) => {

      setTaluka(
        value
      );


      if (
        value !==
        OTHER_OPTION
      ) {

        setBlockCustom(
          ""
        );

      }

    };


  /* =======================================================
     DISTRICT CHANGE
     ======================================================= */

  const handleDistrictChange =
    (value) => {

      setDistrict(
        value
      );


      if (
        value !==
        OTHER_OPTION
      ) {

        setDistrictCustom(
          ""
        );

      }

    };


  /* =======================================================
     HIGH RISK CHANGE
     ======================================================= */

  const handleRiskChange =
    (value) => {

      setSelectedHighRisk(
        (previous) => {

          const selected =
            new Set(
              previous
            );


          if (
            value ===
            "None"
          ) {

            selected.clear();

            selected.add(
              "None"
            );

          } else {

            selected.delete(
              "None"
            );


            if (
              selected.has(
                value
              )
            ) {

              selected.delete(
                value
              );

            } else {

              selected.add(
                value
              );

            }

          }


          return Array.from(
            selected
          );

        }
      );

    };


  /* =======================================================
     CHECK MOBILE
     ======================================================= */

  const verifyMobile =
    async () => {

      const mobile =
        contact1.trim();


      if (
        !isValidMobile(
          mobile
        )
      ) {

        setStatusType(
          "error"
        );


        setStatusMessage(
          "Please enter a valid 10-digit primary mobile number."
        );


        setMobileVerified(
          false
        );


        return;
      }


      setCheckingMobile(
        true
      );


      setMobileVerified(
        false
      );


      setStatusType(
        "info"
      );


      setStatusMessage(
        "Checking mobile number registration status..."
      );


      try {

        const response =
          await checkMobileExists(
            mobile
          );


        const firstResult =
          response?.data ??
          response;


        const result =
          firstResult?.data ??
          firstResult;


        const exists =
          typeof result ===
            "boolean"
            ? result
            : result?.exists ===
              true;


        if (exists) {

          setMobileVerified(
            false
          );


          setStatusType(
            "error"
          );


          setStatusMessage(
            "⚠️ This mobile number already exists in the system. Please use another mobile number."
          );


          return;
        }


        setMobileVerified(
          true
        );


        setStatusType(
          "success"
        );


        setStatusMessage(
          "✓ Mobile number verified successfully. You can now continue with ANC registration."
        );


      } catch (error) {

        setMobileVerified(
          false
        );


        setStatusType(
          "error"
        );


        setStatusMessage(
          error?.message ||
          "Unable to check mobile number."
        );

      } finally {

        setCheckingMobile(
          false
        );

      }

    };


  /* =======================================================
     FINAL BLOCK / DISTRICT VALUES
     ======================================================= */

  const finalBlock =
    taluka ===
    OTHER_OPTION
      ? blockCustom.trim()
      : taluka;


  const finalDistrict =
    district ===
    OTHER_OPTION
      ? districtCustom.trim()
      : district;


  /* =======================================================
     VALIDATE FORM
     ======================================================= */

  const validateForm =
    () => {

      if (!mobileVerified) {
        return "Please verify the primary mobile number first.";
      }


      if (!month) {
        return "Please select registration month.";
      }


      if (!regDate) {
        return "Please select registration date.";
      }


      if (!selectedHospital) {
        return "Please select Hospital / UPHC.";
      }


      if (!selectedStaff) {
        return "Please select Staff Nurse / ANM.";
      }


      if (!selectedAsha) {
        return "Please select ASHA Worker.";
      }


      if (!patientName.trim()) {
        return "Please enter ANC patient full name.";
      }


      const ageNumber =
        Number(age);


      if (
        !age.trim() ||
        !Number.isFinite(
          ageNumber
        ) ||
        ageNumber < 10 ||
        ageNumber > 60
      ) {
        return "Please enter a valid patient age.";
      }


      if (!village.trim()) {
        return "Please enter Village.";
      }


      if (!finalBlock) {
        return "Please select or enter Block Name.";
      }


      if (!finalDistrict) {
        return "Please select or enter District.";
      }


      if (
        !isValidMobile(
          contact1
        )
      ) {
        return "Contact Number 1 must be exactly 10 digits.";
      }


      if (
        contact2 &&
        !isValidMobile(
          contact2
        )
      ) {
        return "Contact Number 2 must be exactly 10 digits.";
      }


      if (
        !isValidAadhaar(
          aadhaar
        )
      ) {
        return "Aadhaar Number must contain exactly 12 digits.";
      }


      if (!lmp) {
        return "Please select LMP Date.";
      }


      if (!edd) {
        return "Please select EDD Date.";
      }


      if (
        selectedHighRisk.length ===
        0
      ) {
        return "Please select at least one High Risk Factor.";
      }


      if (
        selectedHighRisk.includes(
          "Other"
        ) &&
        !highRiskOther.trim()
      ) {
        return "Please specify Other High Risk Factor.";
      }


      if (!pastHistory) {
        return "Please select Past Medical History.";
      }


      if (
        pastHistory ===
          "Other" &&
        !pastHistoryOther.trim()
      ) {
        return "Please specify Other Past Medical History.";
      }


      if (!firstVisitDate) {
        return "Please select First Visit Date.";
      }


      if (!followupFrequency) {
        return "Please select Follow-up Frequency.";
      }


      if (
        lmp &&
        edd &&
        lmp > edd
      ) {
        return "LMP Date cannot be later than EDD Date.";
      }


      return "";
    };


  /* =======================================================
     SUBMIT
     ======================================================= */

  const handleSubmit =
    async () => {

      const error =
        validateForm();


      if (error) {

        setStatusType(
          "error"
        );


        setStatusMessage(
          error
        );


        return;
      }


      if (!user) {

        setStatusType(
          "error"
        );


        setStatusMessage(
          "User session not found. Please login again."
        );


        return;
      }


      const role =
        String(
          user.role ||
          ""
        )
          .trim()
          .toLowerCase();


      const isAdmin =
        role === "admin" ||
        role === "super admin";


      const selectedStaffRecord =
        staffData.find(
          (item) =>
            getStaffHospitalName(
              item
            )
              .toLowerCase() ===
            String(
              selectedHospital
            )
              .trim()
              .toLowerCase()
        );


      const finalZone =
        isAdmin
          ? (
              user.zone ===
              "All"
                ? (
                    getHospitalZone(
                      selectedStaffRecord
                    ) ||
                    user.zone
                  )
                : user.zone
            )
          : user.zone;


      const payload = {

        month:
          month,

        regDate:
          regDate,

        zone:
          finalZone || "",

        hospitalName:
          selectedHospital,

        staffNurse:
          selectedStaff,

        ashaName:
          selectedAsha,

        name:
          patientName.trim(),

        age:
          age.trim(),

        address:
          address.trim(),

        village:
          village.trim(),

        taluka:
          finalBlock,

        district:
          finalDistrict,

        contact:
          contact1.trim(),

        contact2:
          contact2.trim(),

        aadhaar:
          aadhaar
            .replace(/\s/g, "")
            .trim(),

        rchNumber:
          rchNumber.trim(),

        lmp:
          lmp,

        edd:
          edd,

        gpal:
          gpal.trim(),

        highRisk:
          selectedHighRisk.join(
            " | "
          ),

        highRiskOther:
          highRiskOther.trim(),

        pastHistory:
          pastHistory,

        pastHistoryOther:
          pastHistoryOther.trim(),

        firstVisitDate:
          firstVisitDate,

        followupFrequency:
          followupFrequency,

        referredTo:
          referredTo.trim(),

      };


      setSubmitting(
        true
      );


      setStatusType(
        "info"
      );


      setStatusMessage(
        "Submitting ANC registration..."
      );


      try {

        const response =
          await saveANCRegistration(
            payload
          );


        const firstResult =
          response?.data ??
          response;


        const result =
          firstResult?.data ??
          firstResult;


        if (
          result &&
          result.success ===
            false
        ) {

          throw new Error(
            result.message ||
            "Registration failed."
          );

        }


        const successMessage =
          typeof result ===
            "string"
            ? result
            : result?.message ||
              response?.message ||
              "ANC Registration submitted successfully!";


        setStatusType(
          "success"
        );


        setStatusMessage(
          "✓ " +
          successMessage
        );


        Alert.alert(
          "Registration Successful",
          successMessage,
          [
            {
              text: "OK",

              onPress: () => {

                resetForm();

              },
            },
          ]
        );


      } catch (error) {

        console.log(
          "ANC REGISTRATION ERROR:",
          error
        );


        setStatusType(
          "error"
        );


        setStatusMessage(
          error?.message ||
          "Unable to save ANC registration."
        );

      } finally {

        setSubmitting(
          false
        );

      }

    };


  /* =======================================================
     PICKER ITEMS
     ======================================================= */

  const hospitalItems =
    hospitals
      .map(
        (hospital) => {

          const name =
            getHospitalName(
              hospital
            );


          return {
            label:
              name,
            value:
              name,
          };

        }
      )
      .filter(
        (item) =>
          item.label &&
          item.label.trim() !== ""
      );


  const staffItems =
    hospitalStaff
      .map(
        (item) => {

          const nurse =
            getStaffNurseName(
              item
            );

          return {
            label:
              nurse,
            value:
              nurse,
          };

        }
      )
      .filter(
        (item) =>
          item.label !== ""
      );


  const ashaItems =
    staffAshas
      .map(
        (item) => {

          const asha =
            getAshaName(
              item
            );

          return {
            label:
              asha,
            value:
              asha,
          };

        }
      )
      .filter(
        (item) =>
          item.label !== ""
      );


  const blockItems =
    [
      ...blocks
        .map(
          (item) => {

            if (
              typeof item ===
                "string" ||
              typeof item ===
                "number"
            ) {

              return {
                label:
                  String(item),
                value:
                  String(item),
              };

            }


            const blockName =
              String(
                item.name ||
                item.blockName ||
                item["Block Name"] ||
                item.block_name ||
                item.label ||
                item.value ||
                ""
              );


            return {
              label:
                blockName,
              value:
                blockName,
            };

          }
        )
        .filter(
          (item) =>
            item.label &&
            item.label.trim() !== ""
        ),

      {
        label:
          "Other / Type manually",
        value:
          OTHER_OPTION,
      },
    ];


  const districtItems =
    [
      ...districts
        .map(
          (item) => {

            if (
              typeof item ===
                "string" ||
              typeof item ===
                "number"
            ) {

              return {
                label:
                  String(item),
                value:
                  String(item),
              };

            }


            const districtName =
              String(
                item.name ||
                item.districtName ||
                item["District Name"] ||
                item.district_name ||
                item.label ||
                item.value ||
                ""
              );


            return {
              label:
                districtName,
              value:
                districtName,
            };

          }
        )
        .filter(
          (item) =>
            item.label &&
            item.label.trim() !== ""
        ),

      {
        label:
          "Other / Type manually",
        value:
          OTHER_OPTION,
      },
    ];


  const pastHistoryItems =
    [
      "Tuberculosis",
      "Hypertension",
      "Heart Disease",
      "Diabetes",
      "Asthma",
      "Other",
      "None / No Past Medical History",
    ].map(
      (item) => ({
        label:
          item,
        value:
          item,
      })
    );


  const frequencyItems =
    [
      "Daily",
      "Weekly",
      "Fortnightly",
      "Monthly",
      "Not Needed",
    ].map(
      (item) => ({
        label:
          item,
        value:
          item,
      })
    );


  const today =
    new Date();


  /* =======================================================
     SCREEN
     ======================================================= */

  return (

    <KeyboardAvoidingView
      style={
        styles.container
      }
      behavior={
        Platform.OS ===
        "ios"
          ? "padding"
          : undefined
      }
    >

      <ScrollView
        contentContainerStyle={
          styles.scrollContent
        }
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={
          false
        }
      >

        {/* =================================================
            HERO
            ================================================= */}

        <View
          style={
            styles.hero
          }
        >

          <View
            style={
              styles.heroIcon
            }
          >

            <MaterialCommunityIcons
              name="clipboard-plus-outline"
              size={31}
              color="#ffffff"
            />

          </View>


          <View
            style={
              styles.heroContent
            }
          >

            <Text
              style={
                styles.heroTitle
              }
            >
              ANC Registration
            </Text>


            <Text
              style={
                styles.heroSubtitle
              }
            >
              Verify mobile number before starting registration
            </Text>

          </View>

        </View>


        {/* =================================================
            STATUS
            ================================================= */}

        {
          statusMessage
            ? (

              <View
                style={[
                  styles.statusBox,

                  statusType ===
                    "success"
                    ? styles.statusSuccess
                    : statusType ===
                      "error"
                      ? styles.statusError
                      : styles.statusInfo,
                ]}
              >

                <MaterialCommunityIcons
                  name={
                    statusType ===
                    "success"
                      ? "check-circle-outline"
                      : statusType ===
                        "error"
                        ? "alert-circle-outline"
                        : "information-outline"
                  }
                  size={20}
                  color={
                    statusType ===
                    "success"
                      ? COLORS.success
                      : statusType ===
                        "error"
                        ? COLORS.danger
                        : COLORS.primary
                  }
                />


                <Text
                  style={[
                    styles.statusText,

                    statusType ===
                      "success"
                      ? styles.statusSuccessText
                      : statusType ===
                        "error"
                        ? styles.statusErrorText
                        : styles.statusInfoText,
                  ]}
                >
                  {
                    statusMessage
                  }
                </Text>

              </View>

            )
            : null
        }


        {/* =================================================
            MOBILE VERIFICATION
            ================================================= */}

        <SectionCard
          icon="cellphone-check"
          title="Mobile Number Verification"
          subtitle="Check whether this ANC patient is already registered"
        >

          <Field
            label="Primary Contact Number"
            value={
              contact1
            }
            onChangeText={(text) => {

              const clean =
                text.replace(
                  /[^0-9]/g,
                  ""
                );


              setContact1(
                clean
              );


              setMobileVerified(
                false
              );


              if (
                statusMessage
              ) {

                setStatusMessage(
                  ""
                );

              }


              /*
                 Changing the mobile number
                 invalidates previous verification
                 and clears old registration data.
              */

              resetRegistrationFields();

            }}
            placeholder="Enter 10-digit mobile number"
            keyboardType="phone-pad"
            maxLength={10}
            required
          />


          <TouchableOpacity
            activeOpacity={0.84}
            style={[
              styles.primaryButton,
              checkingMobile &&
                styles.disabledButton,
            ]}
            onPress={
              verifyMobile
            }
            disabled={
              checkingMobile
            }
          >

            {
              checkingMobile
                ? (
                  <ActivityIndicator
                    size="small"
                    color="#ffffff"
                  />
                )
                : (
                  <MaterialCommunityIcons
                    name="shield-check-outline"
                    size={20}
                    color="#ffffff"
                  />
                )
            }


            <Text
              style={
                styles.primaryButtonText
              }
            >
              {
                checkingMobile
                  ? "Checking..."
                  : "Check Mobile Number"
              }
            </Text>

          </TouchableOpacity>


          {
            mobileVerified
              ? (

                <View
                  style={
                    styles.verifiedBadge
                  }
                >

                  <MaterialCommunityIcons
                    name="check-circle"
                    size={18}
                    color={
                      COLORS.success
                    }
                  />


                  <Text
                    style={
                      styles.verifiedText
                    }
                  >
                    Mobile number verified. Registration form unlocked.
                  </Text>

                </View>

              )
              : null
          }

        </SectionCard>


        {/* =================================================
            REGISTRATION FORM
            ================================================= */}

        {
          mobileVerified
            ? (

              <>

                {/* =================================================
                    REGISTRATION DETAILS
                    ================================================= */}

                <SectionCard
                  icon="calendar-edit"
                  title="Registration Details"
                  subtitle="Basic ANC registration information"
                >

                  <PickerField
                    label="Registration Month"
                    value={
                      month
                    }
                    onValueChange={
                      setMonth
                    }
                    required
                    placeholder="-- Select Month --"
                    items={[
                      "January",
                      "February",
                      "March",
                      "April",
                      "May",
                      "June",
                      "July",
                      "August",
                      "September",
                      "October",
                      "November",
                      "December",
                    ].map(
                      (item) => ({
                        label:
                          item,
                        value:
                          item,
                      })
                    )}
                  />


                  <DateField
                    label="Registration Date"
                    value={
                      regDate
                    }
                    onChange={
                      (value) => {

                        setRegDate(
                          value
                        );


                        const date =
                          new Date(
                            value +
                            "T00:00:00"
                          );


                        if (
                          !isNaN(
                            date.getTime()
                          )
                        ) {

                          setMonth(
                            monthName(
                              date
                            )
                          );

                        }

                      }
                    }
                    maximumDate={
                      today
                    }
                  />

                </SectionCard>


                {/* =================================================
                    FACILITY
                    ================================================= */}

                <SectionCard
                  icon="hospital-building"
                  title="Facility / Staff Assignment"
                  subtitle="Select Hospital → Staff Nurse / ANM → ASHA"
                >

                  <PickerField
                    label="Hospital / UPHC"
                    value={
                      selectedHospital
                    }
                    onValueChange={
                      handleHospitalChange
                    }
                    required
                    disabled={
                      loadingMasters ||
                      hospitalItems.length ===
                        0
                    }
                    placeholder={
                      loadingMasters
                        ? "Loading hospitals..."
                        : hospitalItems.length ===
                          0
                        ? "No hospital available"
                        : "-- Select Hospital --"
                    }
                    items={
                      hospitalItems
                    }
                  />


                  <PickerField
                    label="Staff Nurse / ANM"
                    value={
                      selectedStaff
                    }
                    onValueChange={
                      handleStaffChange
                    }
                    required
                    disabled={
                      !selectedHospital
                    }
                    placeholder={
                      !selectedHospital
                        ? "Select Hospital First"
                        : "-- Select Staff Nurse --"
                    }
                    items={
                      staffItems
                    }
                  />


                  <PickerField
                    label="ASHA Worker"
                    value={
                      selectedAsha
                    }
                    onValueChange={
                      setSelectedAsha
                    }
                    required
                    disabled={
                      !selectedStaff
                    }
                    placeholder={
                      !selectedStaff
                        ? "Select Staff Nurse First"
                        : ashaItems.length ===
                          0
                        ? "No ASHA registered"
                        : "-- Select ASHA Worker --"
                    }
                    items={
                      ashaItems
                    }
                  />

                </SectionCard>


                {/* =================================================
                    PATIENT DETAILS
                    ================================================= */}

                <SectionCard
                  icon="account-heart-outline"
                  title="Patient Details"
                  subtitle="Personal and demographic information"
                >

                  <Field
                    label="ANC Patient Full Name"
                    value={
                      patientName
                    }
                    onChangeText={
                      setPatientName
                    }
                    placeholder="Enter full name"
                    required
                  />


                  <Field
                    label="Age"
                    value={
                      age
                    }
                    onChangeText={(text) =>
                      setAge(
                        text.replace(
                          /[^0-9]/g,
                          ""
                        )
                      )
                    }
                    placeholder="Enter age"
                    keyboardType="number-pad"
                    maxLength={2}
                    required
                  />


                  <Field
                    label="Address"
                    value={
                      address
                    }
                    onChangeText={
                      setAddress
                    }
                    placeholder="Enter complete address"
                    multiline
                  />


                  <Field
                    label="Village"
                    value={
                      village
                    }
                    onChangeText={
                      setVillage
                    }
                    placeholder="Enter village name"
                    required
                  />


                  {/* BLOCK */}

                  <PickerField
                    label="Block Name"
                    value={
                      taluka
                    }
                    onValueChange={
                      handleBlockChange
                    }
                    required
                    placeholder="-- Select Block --"
                    items={
                      blockItems
                    }
                  />


                  {
                    taluka ===
                    OTHER_OPTION
                      ? (
                        <View
                          style={
                            styles.manualEntryBox
                          }
                        >

                          <View
                            style={
                              styles.manualEntryHeader
                            }
                          >

                            <MaterialCommunityIcons
                              name="pencil-outline"
                              size={17}
                              color={
                                COLORS.primary
                              }
                            />


                            <Text
                              style={
                                styles.manualEntryTitle
                              }
                            >
                              Enter Block Name Manually
                            </Text>

                          </View>


                          <Field
                            label="Block Name"
                            value={
                              blockCustom
                            }
                            onChangeText={
                              setBlockCustom
                            }
                            placeholder="Type Block Name"
                            required
                          />

                        </View>
                      )
                      : null
                  }


                  {/* DISTRICT */}

                  <PickerField
                    label="District"
                    value={
                      district
                    }
                    onValueChange={
                      handleDistrictChange
                    }
                    required
                    placeholder="-- Select District --"
                    items={
                      districtItems.length
                        ? districtItems
                        : [
                            {
                              label:
                                "Pune",
                              value:
                                "Pune",
                            },
                            {
                              label:
                                "Other / Type manually",
                              value:
                                OTHER_OPTION,
                            },
                          ]
                    }
                  />


                  {
                    district ===
                    OTHER_OPTION
                      ? (
                        <View
                          style={
                            styles.manualEntryBox
                          }
                        >

                          <View
                            style={
                              styles.manualEntryHeader
                            }
                          >

                            <MaterialCommunityIcons
                              name="pencil-outline"
                              size={17}
                              color={
                                COLORS.primary
                              }
                            />


                            <Text
                              style={
                                styles.manualEntryTitle
                              }
                            >
                              Enter District Name Manually
                            </Text>

                          </View>


                          <Field
                            label="District Name"
                            value={
                              districtCustom
                            }
                            onChangeText={
                              setDistrictCustom
                            }
                            placeholder="Type District Name"
                            required
                          />

                        </View>
                      )
                      : null
                  }


                  <Field
                    label="Contact Number 2"
                    value={
                      contact2
                    }
                    onChangeText={(text) =>
                      setContact2(
                        text.replace(
                          /[^0-9]/g,
                          ""
                        )
                      )
                    }
                    placeholder="Optional 10-digit mobile number"
                    keyboardType="phone-pad"
                    maxLength={10}
                  />


                  <Field
                    label="Aadhaar Number"
                    value={
                      aadhaar
                    }
                    onChangeText={(text) =>
                      setAadhaar(
                        text.replace(
                          /[^0-9]/g,
                          ""
                        )
                      )
                    }
                    placeholder="Enter 12-digit Aadhaar number"
                    keyboardType="number-pad"
                    maxLength={12}
                  />


                  <Field
                    label="RCH Portal Number"
                    value={
                      rchNumber
                    }
                    onChangeText={
                      setRchNumber
                    }
                    placeholder="Enter RCH ID"
                    autoCapitalize="characters"
                  />

                </SectionCard>


                {/* =================================================
                    PREGNANCY
                    ================================================= */}

                <SectionCard
                  icon="mother-nurse"
                  title="Pregnancy Details"
                  subtitle="LMP, EDD and obstetric information"
                >

                  <DateField
                    label="LMP Date"
                    value={
                      lmp
                    }
                    onChange={
                      setLmp
                    }
                  />


                  <DateField
                    label="EDD Date"
                    value={
                      edd
                    }
                    onChange={
                      setEdd
                    }
                  />


                  <Field
                    label="Parity / PRIMI (GPAL)"
                    value={
                      gpal
                    }
                    onChangeText={
                      setGpal
                    }
                    placeholder="e.g. G2 P1 A0 L1"
                  />

                </SectionCard>


                {/* =================================================
                    HIGH RISK
                    ================================================= */}

                <SectionCard
                  icon="alert-octagon-outline"
                  title="High Risk Factors"
                  subtitle="Multiple selections are allowed"
                >

                  <View
                    style={
                      styles.warningInfo
                    }
                  >

                    <MaterialCommunityIcons
                      name="information-outline"
                      size={18}
                      color={
                        COLORS.primary
                      }
                    />


                    <Text
                      style={
                        styles.warningInfoText
                      }
                    >
                      Select one or more applicable high-risk factors. "None" cannot be selected together with another factor.
                    </Text>

                  </View>


                  <View
                    style={
                      styles.riskSummary
                    }
                  >

                    <Text
                      style={
                        styles.riskSummaryTitle
                      }
                    >
                      Selected:
                    </Text>


                    <Text
                      style={
                        styles.riskSummaryText
                      }
                    >
                      {
                        selectedHighRisk.length
                          ? selectedHighRisk.join(
                              " | "
                            )
                          : "None"
                      }
                    </Text>

                  </View>


                  <View
                    style={
                      styles.riskBox
                    }
                  >

                    {
                      HIGH_RISK_FACTORS.map(
                        (item) => (

                          <RiskCheckbox
                            key={
                              item.value
                            }
                            item={
                              item
                            }
                            selected={
                              selectedHighRisk.includes(
                                item.value
                              )
                            }
                            onPress={() =>
                              handleRiskChange(
                                item.value
                              )
                            }
                          />

                        )
                      )
                    }

                  </View>


                  {
                    selectedHighRisk.includes(
                      "Other"
                    )
                      ? (

                        <Field
                          label="Other High Risk Factor"
                          value={
                            highRiskOther
                          }
                          onChangeText={
                            setHighRiskOther
                          }
                          placeholder="Specify other high-risk factor"
                          required
                        />

                      )
                      : null
                  }

                </SectionCard>


                {/* =================================================
                    PAST HISTORY
                    ================================================= */}

                <SectionCard
                  icon="history"
                  title="Past Medical History"
                  subtitle="Previous medical conditions"
                >

                  <PickerField
                    label="Past Medical History"
                    value={
                      pastHistory
                    }
                    onValueChange={(value) => {

                      setPastHistory(
                        value
                      );


                      if (
                        value !==
                        "Other"
                      ) {

                        setPastHistoryOther(
                          ""
                        );

                      }

                    }}
                    required
                    placeholder="-- Select Past Medical History --"
                    items={
                      pastHistoryItems
                    }
                  />


                  {
                    pastHistory ===
                    "Other"
                      ? (

                        <Field
                          label="Other Past History"
                          value={
                            pastHistoryOther
                          }
                          onChangeText={
                            setPastHistoryOther
                          }
                          placeholder="Specify details"
                          required
                        />

                      )
                      : null
                  }

                </SectionCard>


                {/* =================================================
                    FOLLOW-UP
                    ================================================= */}

                <SectionCard
                  icon="calendar-clock"
                  title="Follow-up Plan"
                  subtitle="Define first visit, required frequency and referral"
                >

                  <DateField
                    label="First Visit Date"
                    value={
                      firstVisitDate
                    }
                    onChange={
                      setFirstVisitDate
                    }
                  />


                  <PickerField
                    label="Follow-up Needed Frequency"
                    value={
                      followupFrequency
                    }
                    onValueChange={
                      setFollowupFrequency
                    }
                    required
                    placeholder="-- Select Frequency --"
                    items={
                      frequencyItems
                    }
                  />


                  <Field
                    label="Referred To For Follow-up"
                    value={
                      referredTo
                    }
                    onChangeText={
                      setReferredTo
                    }
                    placeholder="e.g. PCMC Hospital / Other UPHC / Govt Hospital"
                    multiline
                  />

                </SectionCard>


                {/* =================================================
                    SUBMIT
                    ================================================= */}

                <View
                  style={
                    styles.submitSection
                  }
                >

                  <TouchableOpacity
                    activeOpacity={0.85}
                    style={[
                      styles.submitButton,
                      submitting &&
                        styles.disabledButton,
                    ]}
                    onPress={
                      handleSubmit
                    }
                    disabled={
                      submitting
                    }
                  >

                    {
                      submitting
                        ? (
                          <ActivityIndicator
                            size="small"
                            color="#ffffff"
                          />
                        )
                        : (
                          <MaterialCommunityIcons
                            name="content-save-check-outline"
                            size={22}
                            color="#ffffff"
                          />
                        )
                    }


                    <Text
                      style={
                        styles.submitButtonText
                      }
                    >
                      {
                        submitting
                          ? "Submitting Registration..."
                          : "Submit ANC Registration"
                      }
                    </Text>

                  </TouchableOpacity>


                  <TouchableOpacity
                    style={
                      styles.clearButton
                    }
                    onPress={() =>
                      Alert.alert(
                        "Clear Form",
                        "Are you sure you want to clear all entered information?",
                        [
                          {
                            text:
                              "Cancel",
                            style:
                              "cancel",
                          },
                          {
                            text:
                              "Clear",
                            style:
                              "destructive",
                            onPress:
                              resetForm,
                          },
                        ]
                      )
                    }
                    disabled={
                      submitting
                    }
                  >

                    <MaterialCommunityIcons
                      name="refresh"
                      size={19}
                      color={
                        COLORS.textLight
                      }
                    />


                    <Text
                      style={
                        styles.clearButtonText
                      }
                    >
                      Clear Form
                    </Text>

                  </TouchableOpacity>

                </View>

              </>

            )
            : (

              /* =================================================
                 FORM LOCKED
                 ================================================= */

              <View
                style={
                  styles.formLockedCard
                }
              >

                <View
                  style={
                    styles.formLockedIcon
                  }
                >

                  <MaterialCommunityIcons
                    name="lock-outline"
                    size={30}
                    color={
                      COLORS.primary
                    }
                  />

                </View>


                <Text
                  style={
                    styles.formLockedTitle
                  }
                >
                  Registration Form Locked
                </Text>


                <Text
                  style={
                    styles.formLockedText
                  }
                >
                  Please enter a 10-digit mobile number and check it first. The ANC registration form will appear only when the mobile number is not already registered.
                </Text>

              </View>
            )
        }


        {/* =================================================
            FOOTER
            ================================================= */}

        <View
          style={
            styles.footer
          }
        >

          <View
            style={
              styles.footerLine
            }
          />


          <Text
            style={
              styles.footerTitle
            }
          >
            High Risk ANC Tracking System - PCMC
          </Text>


          <Text
            style={
              styles.footerText
            }
          >
            Health Department
          </Text>

        </View>


      </ScrollView>

    </KeyboardAvoidingView>
  );
}


/* =========================================================
   STYLES
   ========================================================= */

const styles =
  StyleSheet.create({

    container: {
      flex: 1,
      backgroundColor:
        COLORS.background,
    },


    scrollContent: {
      padding: 15,
      paddingBottom: 35,
      alignItems: "center",
    },


    /* =====================================================
       HERO
       ===================================================== */

    hero: {
      width: "100%",
      maxWidth: 900,

      backgroundColor:
        COLORS.secondary,

      borderRadius: 17,

      padding: 17,

      flexDirection: "row",

      alignItems: "center",

      marginBottom: 13,
    },


    heroIcon: {
      width: 55,

      height: 55,

      borderRadius: 15,

      backgroundColor:
        "rgba(255,255,255,0.12)",

      alignItems: "center",

      justifyContent: "center",
    },


    heroContent: {
      flex: 1,

      marginLeft: 12,
    },


    heroTitle: {
      color: "#ffffff",

      fontSize: 20,

      fontWeight: "800",
    },


    heroSubtitle: {
      color: "#bfdbfe",

      fontSize: 12,

      marginTop: 4,

      lineHeight: 17,
    },


    /* =====================================================
       STATUS
       ===================================================== */

    statusBox: {
      width: "100%",
      maxWidth: 900,

      flexDirection: "row",

      alignItems: "flex-start",

      padding: 11,

      borderRadius: 10,

      marginBottom: 12,

      borderWidth: 1,
    },


    statusInfo: {
      backgroundColor:
        "#eff6ff",

      borderColor:
        "#bfdbfe",
    },


    statusSuccess: {
      backgroundColor:
        "#f0fdf4",

      borderColor:
        "#bbf7d0",
    },


    statusError: {
      backgroundColor:
        "#fef2f2",

      borderColor:
        "#fecaca",
    },


    statusText: {
      flex: 1,

      marginLeft: 8,

      fontSize: 12,

      lineHeight: 18,

      fontWeight: "600",
    },


    statusInfoText: {
      color:
        "#1d4ed8",
    },


    statusSuccessText: {
      color:
        "#15803d",
    },


    statusErrorText: {
      color:
        "#991b1b",
    },


    /* =====================================================
       SECTION
       ===================================================== */

    sectionCard: {
      width: "100%",
      maxWidth: 900,

      backgroundColor: "#ffffff",

      borderRadius: 16,

      marginBottom: 12,

      padding: 15,

      borderWidth: 1,

      borderColor: "#e2e8f0",

      shadowColor: "#000",

      shadowOffset: {
        width: 0,
        height: 2,
      },

      shadowOpacity: 0.045,

      shadowRadius: 5,

      elevation: 2,
    },


    sectionHeader: {
      flexDirection: "row",

      alignItems: "center",

      marginBottom: 9,
    },


    sectionIcon: {
      width: 43,

      height: 43,

      borderRadius: 12,

      backgroundColor: "#eff6ff",

      justifyContent: "center",

      alignItems: "center",
    },


    sectionHeaderText: {
      flex: 1,

      marginLeft: 10,
    },


    sectionTitle: {
      color:
        COLORS.textDark,

      fontSize: 16,

      fontWeight: "800",
    },


    sectionSubtitle: {
      color: "#64748b",

      fontSize: 11,

      lineHeight: 15,

      marginTop: 2,
    },


    /* =====================================================
       LABEL / INPUT
       ===================================================== */

    label: {
      marginTop: 12,

      marginBottom: 6,

      fontSize: 13,

      fontWeight: "700",

      color:
        COLORS.textLight,
    },


    required: {
      color:
        COLORS.danger,
    },


    input: {
      minHeight: 50,

      borderWidth: 1,

      borderColor:
        COLORS.border,

      borderRadius: 10,

      paddingHorizontal: 12,

      paddingVertical: 11,

      fontSize: 14,

      color:
        COLORS.textDark,

      backgroundColor:
        "#f8fafc",
    },


    multilineInput: {
      minHeight: 90,

      textAlignVertical:
        "top",
    },


    disabledInput: {
      backgroundColor:
        "#f1f5f9",

      opacity: 0.75,
    },


    /* =====================================================
       MANUAL ENTRY
       ===================================================== */

    manualEntryBox: {
      marginTop: 9,

      padding: 11,

      borderRadius: 11,

      borderWidth: 1,

      borderColor:
        "#bfdbfe",

      backgroundColor:
        "#f8fbff",
    },


    manualEntryHeader: {
      flexDirection: "row",

      alignItems: "center",
    },


    manualEntryTitle: {
      marginLeft: 7,

      fontSize: 12,

      fontWeight: "800",

      color:
        COLORS.primary,
    },


    /* =====================================================
       DATE FIELD
       ===================================================== */

    dateField: {
      minHeight: 50,

      borderWidth: 1,

      borderColor:
        COLORS.border,

      borderRadius: 10,

      paddingHorizontal: 12,

      flexDirection: "row",

      alignItems: "center",

      backgroundColor:
        "#f8fafc",
    },


    dateFieldEmpty: {
      borderColor:
        "#cbd5e1",
    },


    dateFieldText: {
      flex: 1,

      marginLeft: 9,

      fontSize: 14,

      fontWeight: "600",

      color:
        COLORS.textDark,
    },


    dateFieldPlaceholder: {
      color:
        "#94a3b8",

      fontWeight: "500",
    },


    /* =====================================================
       CUSTOM DROPDOWN
       ===================================================== */

    customDropdown: {
      width: "100%",

      minHeight: 50,

      borderWidth: 1,

      borderColor:
        COLORS.border,

      borderRadius: 10,

      backgroundColor:
        "#f8fafc",

      paddingHorizontal: 12,

      flexDirection: "row",

      alignItems: "center",

      justifyContent: "space-between",
    },


    customDropdownDisabled: {
      backgroundColor:
        "#f1f5f9",

      borderColor:
        "#e2e8f0",

      opacity: 0.65,
    },


    dropdownLeft: {
      flex: 1,

      flexDirection: "row",

      alignItems: "center",

      minWidth: 0,
    },


    dropdownText: {
      flex: 1,

      marginLeft: 9,

      fontSize: 14,

      fontWeight: "600",

      color:
        "#1e293b",
    },


    dropdownPlaceholder: {
      color:
        "#94a3b8",

      fontWeight: "500",
    },


    /* =====================================================
       DROPDOWN MODAL
       ===================================================== */

    dropdownOverlay: {
      flex: 1,

      backgroundColor:
        "rgba(15,23,42,0.45)",

      justifyContent: "center",

      alignItems: "center",

      padding: 20,
    },


    dropdownModal: {
      width: "100%",

      maxWidth: 520,

      maxHeight: "78%",

      backgroundColor:
        "#ffffff",

      borderRadius: 18,

      overflow: "hidden",

      shadowColor: "#000",

      shadowOffset: {
        width: 0,
        height: 8,
      },

      shadowOpacity: 0.2,

      shadowRadius: 18,

      elevation: 10,
    },


    dropdownModalHeader: {
      flexDirection: "row",

      alignItems: "center",

      justifyContent: "space-between",

      padding: 16,

      borderBottomWidth: 1,

      borderBottomColor:
        "#e2e8f0",

      backgroundColor:
        "#f8fafc",
    },


    dropdownModalTitleBox: {
      flex: 1,
    },


    dropdownModalTitle: {
      color:
        "#1e293b",

      fontSize: 17,

      fontWeight: "800",
    },


    dropdownModalSubtitle: {
      color:
        "#64748b",

      fontSize: 11,

      marginTop: 3,
    },


    dropdownCloseButton: {
      width: 36,

      height: 36,

      borderRadius: 18,

      backgroundColor:
        "#e2e8f0",

      justifyContent: "center",

      alignItems: "center",
    },


    dropdownList: {
      padding: 10,
    },


    dropdownOption: {
      minHeight: 50,

      borderRadius: 10,

      marginBottom: 5,

      paddingHorizontal: 10,

      flexDirection: "row",

      alignItems: "center",

      backgroundColor:
        "#ffffff",
    },


    dropdownOptionSelected: {
      backgroundColor:
        "#eff6ff",
    },


    dropdownOptionIcon: {
      width: 28,

      height: 28,

      borderRadius: 14,

      backgroundColor:
        "#f1f5f9",

      justifyContent: "center",

      alignItems: "center",
    },


    dropdownOptionIconSelected: {
      backgroundColor:
        COLORS.primary,
    },


    dropdownOptionText: {
      flex: 1,

      marginLeft: 10,

      color:
        "#334155",

      fontSize: 13,

      lineHeight: 18,
    },


    dropdownOptionTextSelected: {
      color:
        COLORS.primary,

      fontWeight: "800",
    },


    dropdownEmpty: {
      padding: 35,

      alignItems: "center",

      justifyContent: "center",
    },


    dropdownEmptyText: {
      color:
        "#94a3b8",

      marginTop: 8,

      fontSize: 13,

      fontWeight: "600",
    },


    /* =====================================================
       CALENDAR MODAL
       ===================================================== */

    calendarOverlay: {
      flex: 1,

      backgroundColor:
        "rgba(15,23,42,0.48)",

      justifyContent: "center",

      alignItems: "center",

      padding: 18,
    },


    calendarModal: {
      width: "100%",

      maxWidth: 430,

      backgroundColor:
        "#ffffff",

      borderRadius: 20,

      overflow: "hidden",

      shadowColor: "#000",

      shadowOffset: {
        width: 0,
        height: 8,
      },

      shadowOpacity: 0.2,

      shadowRadius: 18,

      elevation: 10,
    },


    calendarHeader: {
      flexDirection: "row",

      alignItems: "center",

      justifyContent:
        "space-between",

      padding: 16,

      backgroundColor:
        "#f8fafc",

      borderBottomWidth: 1,

      borderBottomColor:
        "#e2e8f0",
    },


    calendarTitleBox: {
      flex: 1,
    },


    calendarTitle: {
      color:
        "#1e293b",

      fontSize: 17,

      fontWeight: "800",
    },


    calendarSelectedDate: {
      color:
        COLORS.primary,

      fontSize: 12,

      fontWeight: "700",

      marginTop: 3,
    },


    calendarCloseButton: {
      width: 36,

      height: 36,

      borderRadius: 18,

      backgroundColor:
        "#e2e8f0",

      alignItems: "center",

      justifyContent: "center",
    },


    calendarMonthHeader: {
      flexDirection: "row",

      alignItems: "center",

      justifyContent: "space-between",

      paddingHorizontal: 15,

      paddingVertical: 12,
    },


    calendarNavButton: {
      width: 38,

      height: 38,

      borderRadius: 19,

      backgroundColor:
        "#eff6ff",

      justifyContent: "center",

      alignItems: "center",
    },


    calendarMonthText: {
      color:
        "#1e293b",

      fontSize: 16,

      fontWeight: "800",
    },


    weekRow: {
      flexDirection: "row",

      paddingHorizontal: 10,
    },


    weekDay: {
      flex: 1,

      textAlign: "center",

      color:
        "#64748b",

      fontSize: 10,

      fontWeight: "800",

      paddingVertical: 7,
    },


    calendarGrid: {
      paddingHorizontal: 10,

      paddingBottom: 8,
    },


    calendarWeek: {
      flexDirection: "row",
    },


    calendarDay: {
      flex: 1,

      height: 42,

      margin: 2,

      borderRadius: 11,

      alignItems: "center",

      justifyContent: "center",
    },


    calendarDayText: {
      color:
        "#334155",

      fontSize: 13,

      fontWeight: "600",
    },


    calendarToday: {
      borderWidth: 1,

      borderColor:
        COLORS.primary,
    },


    calendarTodayText: {
      color:
        COLORS.primary,

      fontWeight: "900",
    },


    calendarDaySelected: {
      backgroundColor:
        COLORS.primary,
    },


    calendarDaySelectedText: {
      color:
        "#ffffff",

      fontWeight: "900",
    },


    calendarDayDisabled: {
      opacity: 0.35,
    },


    calendarDayDisabledText: {
      color:
        "#94a3b8",
    },


    calendarFooter: {
      flexDirection: "row",

      justifyContent: "flex-end",

      alignItems: "center",

      padding: 12,

      borderTopWidth: 1,

      borderTopColor:
        "#e2e8f0",

      backgroundColor:
        "#f8fafc",
    },


    calendarCancelButton: {
      paddingHorizontal: 16,

      paddingVertical: 9,
    },


    calendarCancelText: {
      color:
        "#64748b",

      fontSize: 13,

      fontWeight: "700",
    },


    calendarTodayButton: {
      paddingHorizontal: 16,

      paddingVertical: 9,

      borderRadius: 9,

      backgroundColor:
        COLORS.primary,
    },


    calendarTodayTextButton: {
      color:
        "#ffffff",

      fontSize: 13,

      fontWeight: "800",
    },


    /* =====================================================
       BUTTON
       ===================================================== */

    primaryButton: {
      marginTop: 12,

      minHeight: 49,

      backgroundColor:
        COLORS.primary,

      borderRadius: 10,

      alignItems: "center",

      justifyContent: "center",

      flexDirection: "row",
    },


    primaryButtonText: {
      color:
        "#ffffff",

      fontSize: 14,

      fontWeight: "800",

      marginLeft: 7,
    },


    disabledButton: {
      opacity: 0.6,
    },


    /* =====================================================
       VERIFIED
       ===================================================== */

    verifiedBadge: {
      marginTop: 10,

      backgroundColor:
        "#f0fdf4",

      borderWidth: 1,

      borderColor:
        "#bbf7d0",

      borderRadius: 9,

      padding: 9,

      flexDirection: "row",

      alignItems: "center",
    },


    verifiedText: {
      flex: 1,

      marginLeft: 7,

      color:
        "#15803d",

      fontSize: 12,

      fontWeight: "700",
    },


    /* =====================================================
       FORM LOCKED
       ===================================================== */

    formLockedCard: {
      width: "100%",

      maxWidth: 900,

      backgroundColor:
        "#ffffff",

      borderRadius: 16,

      padding: 24,

      marginBottom: 12,

      alignItems: "center",

      borderWidth: 1,

      borderColor:
        "#e2e8f0",
    },


    formLockedIcon: {
      width: 62,

      height: 62,

      borderRadius: 31,

      backgroundColor:
        "#eff6ff",

      alignItems: "center",

      justifyContent: "center",

      marginBottom: 12,
    },


    formLockedTitle: {
      fontSize: 17,

      fontWeight: "800",

      color:
        COLORS.textDark,

      textAlign: "center",
    },


    formLockedText: {
      marginTop: 7,

      fontSize: 12,

      lineHeight: 18,

      color:
        "#64748b",

      textAlign: "center",

      maxWidth: 620,
    },


    /* =====================================================
       HIGH RISK
       ===================================================== */

    warningInfo: {
      flexDirection: "row",

      alignItems: "flex-start",

      padding: 10,

      backgroundColor:
        "#eff6ff",

      borderWidth: 1,

      borderColor:
        "#bfdbfe",

      borderRadius: 9,
    },


    warningInfoText: {
      flex: 1,

      marginLeft: 7,

      color:
        "#1d4ed8",

      fontSize: 11,

      lineHeight: 17,
    },


    riskSummary: {
      marginTop: 10,

      padding: 10,

      backgroundColor:
        "#f8fafc",

      borderWidth: 1,

      borderColor:
        "#e2e8f0",

      borderRadius: 9,
    },


    riskSummaryTitle: {
      fontSize: 11,

      fontWeight: "800",

      color:
        "#64748b",
    },


    riskSummaryText: {
      marginTop: 3,

      fontSize: 12,

      lineHeight: 18,

      color:
        "#1d4ed8",

      fontWeight: "700",
    },


    riskBox: {
      marginTop: 10,

      borderWidth: 1,

      borderColor:
        "#e2e8f0",

      borderRadius: 10,

      overflow: "hidden",
    },


    riskRow: {
      flexDirection: "row",

      alignItems: "flex-start",

      padding: 11,

      borderBottomWidth: 1,

      borderBottomColor:
        "#f1f5f9",

      backgroundColor:
        "#ffffff",
    },


    riskRowSelected: {
      backgroundColor:
        "#eff6ff",
    },


    checkbox: {
      width: 22,

      height: 22,

      borderRadius: 6,

      borderWidth: 1.5,

      borderColor:
        "#94a3b8",

      alignItems: "center",

      justifyContent: "center",

      marginRight: 9,

      marginTop: 1,
    },


    checkboxSelected: {
      backgroundColor:
        COLORS.primary,

      borderColor:
        COLORS.primary,
    },


    riskLabel: {
      flex: 1,

      fontSize: 12,

      lineHeight: 18,

      color:
        COLORS.textLight,
    },


    /* =====================================================
       SUBMIT
       ===================================================== */

    submitSection: {
      width: "100%",

      maxWidth: 900,

      marginTop: 3,
    },


    submitButton: {
      minHeight: 56,

      borderRadius: 12,

      backgroundColor:
        COLORS.success,

      alignItems: "center",

      justifyContent: "center",

      flexDirection: "row",

      shadowColor:
        COLORS.success,

      shadowOffset: {
        width: 0,

        height: 4,
      },

      shadowOpacity: 0.2,

      shadowRadius: 7,

      elevation: 4,
    },


    submitButtonText: {
      color:
        "#ffffff",

      fontSize: 16,

      fontWeight: "900",

      marginLeft: 8,
    },


    clearButton: {
      minHeight: 48,

      marginTop: 9,

      borderRadius: 11,

      backgroundColor:
        "#ffffff",

      borderWidth: 1,

      borderColor:
        "#cbd5e1",

      flexDirection: "row",

      alignItems: "center",

      justifyContent: "center",
    },


    clearButtonText: {
      marginLeft: 6,

      color:
        COLORS.textLight,

      fontSize: 14,

      fontWeight: "700",
    },


    /* =====================================================
       FOOTER
       ===================================================== */

    footer: {
      width: "100%",

      maxWidth: 900,

      alignItems:
        "center",

      paddingTop: 25,
    },


    footerLine: {
      width: 50,

      height: 3,

      borderRadius: 2,

      backgroundColor:
        COLORS.primary,

      marginBottom: 9,
    },


    footerTitle: {
      fontSize: 11,

      fontWeight: "700",

      color:
        COLORS.textLight,

      textAlign: "center",
    },


    footerText: {
      marginTop: 3,

      fontSize: 10,

      color:
        "#94a3b8",
    },

  });

