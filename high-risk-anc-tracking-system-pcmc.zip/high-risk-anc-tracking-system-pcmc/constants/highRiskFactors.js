export const HIGH_RISK_FACTORS = [
{
value: "None",
label: "None / कोणताही उच्च जोखीम घटक नाही",
},
{
value: "Anemia",
label: "Anemia - ॲनिमिया (रक्तक्षय)",
},
{
value:
"Pregnancy Induced Hypertension (PIH) / Hypertension (HTN)",
label:
"Pregnancy Induced Hypertension (PIH) / Hypertension (HTN) - गर्भधारणेमुळे निर्माण झालेला उच्च रक्तदाब (PIH) / उच्च रक्तदाब (HTN)",
},
{
value:
"Gestational Diabetes Mellitus (GDM) / Diabetes Mellitus (DM)",
label:
"Gestational Diabetes Mellitus (GDM) / Diabetes Mellitus (DM) - गर्भधारणेतील मधुमेह (GDM) / मधुमेह (DM)",
},
{
value:
"Hypothyroidism / Thyroid Disorders",
label:
"Hypothyroidism / Thyroid Disorders - हायपोथायरॉईडीझम / थायरॉईड आजार",
},
{
value:
"Gestational Thrombocytopenia",
label:
"Gestational Thrombocytopenia - रक्तातील प्लेटलेट्स कमी असणे (Thrombocytopenia)",
},
{
value:
"Previous LSCS (Cesarean Section)",
label:
"Previous LSCS (Cesarean Section) - मागील सिझेरियन प्रसुती (LSCS)",
},
{
value:
"History of Recurrent Abortions or Miscarriages",
label:
"History of Recurrent Abortions or Miscarriages - वारंवार गर्भपात होण्याचा इतिहास",
},
{
value:
"History of Ectopic Pregnancy",
label:
"History of Ectopic Pregnancy - एक्टोपिक प्रेग्नेन्सीचा (गर्भाशयाबाहेर गर्भ राहणे) इतिहास",
},
{
value:
"Previous Intrauterine Death (IUD) / Stillbirth",
label:
"Previous Intrauterine Death (IUD) / Stillbirth - गर्भातच बाळ दगावणे (IUD) / मृत बाळ जन्मणे",
},
{
value:
"History of Neonatal or Infant Death",
label:
"History of Neonatal or Infant Death - जन्मानंतर बाळ दगावल्याचा इतिहास",
},
{
value:
"History of Preterm / Premature Delivery",
label:
"History of Preterm / Premature Delivery - अकाली प्रसूतीचा इतिहास",
},
{
value:
"History of Postpartum Hemorrhage (PPH)",
label:
"History of Postpartum Hemorrhage (PPH) - प्रसूतीनंतर अतिरक्तस्त्राव झाल्याचा इतिहास",
},
{
value:
"History of Home Deliveries",
label:
"History of Home Deliveries - पूर्वी घरगुती प्रसूती झालेला इतिहास",
},
{
value:
"Cervical Incompetence / Cervical Stitch",
label:
"Cervical Incompetence / Cervical Stitch - गर्भाशयाचे तोंड कमजोर असणे",
},
{
value:
"Multi-parity / Multigravida",
label:
"Multi-parity / Multigravida - अनेक वेळा गर्भवती राहणे",
},
{
value:
"Multiple Pregnancy (Twins / Triplets)",
label:
"Multiple Pregnancy (Twins / Triplets) - जुळी किंवा तिहेरी गर्भधारणा",
},
{
value:
"Low-Lying Placenta / Placenta Previa",
label:
"Low-Lying Placenta / Placenta Previa - नाळ खाली असणे",
},
{
value:
"Breech Presentation / Abnormal Lie",
label:
"Breech Presentation / Abnormal Lie - बाळ उलट किंवा तिरके असणे",
},
{
value:
"Fetal Growth Restriction (IUGR)",
label:
"Fetal Growth Restriction (IUGR) - गर्भाची वाढ अपुरी असणे",
},
{
value:
"Elderly Gravida / Elderly Primi",
label:
"Elderly Gravida / Elderly Primi - वयोवृद्ध गर्भवती (३५ वर्षांपेक्षा जास्त वय)",
},
{
value:
"Teenage Pregnancy",
label:
"Teenage Pregnancy - अल्पवयीन गर्भधारणा (१८ वर्षे किंवा त्यापेक्षा कमी वय)",
},
{
value:
"Short Stature",
label:
"Short Stature - उंची कमी असणे",
},
{
value:
"Rh Negative Blood Groups (A-, B-, AB-, O- negative)",
label:
"Rh Negative Blood Groups (A-, B-, AB-, O- negative) - आरएच निगेटिव्ह रक्तगट (A, B, AB, किंवा O निगेटिव्ह)",
},
{
value:
"Rh Incompatibility",
label:
"Rh Incompatibility - रक्तगट न जुळण्याचा धोका",
},
{
value:
"Allergy to Iron Sucrose / Medications",
label:
"Allergy to Iron Sucrose / Medications - लोह किंवा औषधांची ॲलर्जी",
},
{
value: "Other",
label: "Other",
},
];
