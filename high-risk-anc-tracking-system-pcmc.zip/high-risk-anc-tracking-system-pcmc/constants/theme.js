// constants/theme.js

export const COLORS = {
  primary: '#2563eb',      // मुख्य निळा रंग (उदा. बटन्स, हायलाईट्स)
  secondary: '#1a365d',    // गडद निळा (उदा. हेडर)
  background: '#f0f4f8',   // ॲपचा बॅकग्राउंड रंग
  white: '#ffffff',
  textDark: '#1e293b',
  textLight: '#475569',
  border: '#cbd5e1',
  success: '#16a34a',      // हिरवा रंग (Completed Outcome साठी)
  danger: '#dc2626',       // लाल रंग (High Risk केसेससाठी)
  warning: '#b45309'       // पिवळा/ऑरेंज रंग (Pending साठी)
};

export const API_CONFIG = {
  // तुमच्या Google Apps Script (Code.gs) च्या Web App ची लिंक येथे फिक्स ठेवा
  BASE_URL: 'https://script.google.com/macros/s/AKfycbz_G325_d7c8rAFPb3HtRSdEpd1_H9sducqD1GiPSTkp7ItJnqYWmEEZmud92cq32e2Wg/exec',
};

export const APP_INFO = {
  title: 'High Risk ANC Tracking System',
  subtitle: 'PCMC Health Department',
  version: '1.0.0'
};